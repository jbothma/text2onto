/*****************************************************************************
 * Copyright (c) 2009 ontoprise GmbH.
 *
 * All rights reserved.
 *
 * This program and the accompanying materials are made available under the 
 * Eclipse Public License v1.0 which accompanies this distribution, 
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 ******************************************************************************/
package com.ontoprise.ontostudio.owl.gui.properties.sections;

/**
 * @author janiko
 *
 */
public class SuperRestrictionSectionBuilder extends  SectionBuilder{

    @Override
    public void addContent() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void addText() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void initSection() {
        // TODO Auto-generated method stub
        
    }

}

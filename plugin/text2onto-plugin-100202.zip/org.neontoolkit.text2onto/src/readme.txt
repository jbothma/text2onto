
Text2Onto Plugin v1.0b

1. Install GATE 4.0 (http://gate.ac.uk/download/index.html) to <GATE-DIR> (e.g. 'c:\GATE')

2. Install WordNet 2.0 (http://wordnet.princeton.edu/) to <WN-DIR> (e.g. 'c:\WordNet')

3. Unzip 'org.neon.toolkit.text2onto_1.0.0.jar' into your Toolkit plugins directory 
	(e.g. <T2O-DIR>='c:\NeonToolkit\plugins\org.neon.toolkit.text2onto_1.0.0')
	
4. Edit '<T2O-DIR>/lib/jwnl/file_properties.xml' and replace <WN-DIR>

	<param name="file_manager" value="net.didion.jwnl.dictionary.file_manager.FileManagerImpl">
		<param name="file_type" value="net.didion.jwnl.princeton.file.PrincetonRandomAccessDictionaryFile"/>
		<param name="dictionary_path" value="<WN-DIR>\dict"/>
	</param>
	
5. Modify VM parameters in NeOn_Toolkit.ini and copy it to your Toolkit home directory.

6. Start the Toolkit and set the preferences for Text2Onto

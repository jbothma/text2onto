INFO ZUR file_properties.xml-DATEI:

In Zeile 42 den Pfad zum Wordnet2.0-Verzeichnis "dict" entsprechend neu setzen, zum Beispiel:

<param name="dictionary_path" value="C:\Programme\Entwicklung\WordNet2.0\dict"/>
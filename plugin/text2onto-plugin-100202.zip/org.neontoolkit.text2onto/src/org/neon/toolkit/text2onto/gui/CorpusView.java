package org.neon.toolkit.text2onto.gui;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.DrillDownAdapter;
import org.eclipse.ui.part.ViewPart;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.CorpusProvider;
import org.neon.toolkit.text2onto.gui.common.TreeObject;
import org.neon.toolkit.text2onto.gui.common.TreeParent;
import org.ontoware.text2onto.corpus.AbstractDocument;
import org.ontoware.text2onto.corpus.Corpus;



public class CorpusView extends ViewPart {

	private TreeViewer m_treeViewer;
	private DrillDownAdapter drillDownAdapter;
	
	private CorpusProvider m_provider;
	
	private ArrayList m_alListeners;
	
	private Action actionAdd;
	private Action actionRemove;
	private Action actionClear;
	private Action actionShow;
	private Action doubleClickAction;
	
	public class HelloJface extends Window {
			 String m_sFile;
		    public HelloJface(Shell arg0, String sFile) {
		          super(arg0);
		          m_sFile = sFile;
		          
		    }
	       @Override
		    protected Control createContents(Composite parent) {
		       
	      	 parent.setSize(500, 400); 
	      	 StyledText text = new StyledText(parent, SWT.MULTI|SWT.BORDER|SWT.WRAP|SWT.V_SCROLL);
		       text.setBounds( 10, 10, 500, 500 );
		       GridData spec = new GridData();
		       spec.horizontalAlignment = GridData.FILL;
		       spec.grabExcessHorizontalSpace = true;
		       spec.verticalAlignment = GridData.FILL;
		       spec.grabExcessVerticalSpace = true;
		       text.setLayoutData(spec);
		       text.setEditable(false);
		       
		       try {
		      	 text.setText(getText(m_sFile));
		       }catch(Exception e) {
		      	 e.printStackTrace();
		       }
		      return parent;
		    }
	       
	       private String getText( String sFile ) throws Exception {
	    		StringBuffer sb = new StringBuffer();
	    		File file = new File( sFile );
	    		BufferedReader reader = new BufferedReader( new FileReader( file ) );
	    		String sLine = null;
	    		while( ( sLine = reader.readLine() ) != null ){
	    			sb.append( sLine +"\n" );
	    		}
	    		return sb.toString();
	    	}

	}

	
	class NameSorter extends ViewerSorter {
	}
	
	class ViewLabelProvider extends LabelProvider {

		public String getText(Object obj) {
			return obj.toString();
		}
		public Image getImage(Object obj) {
			String imageKey = ISharedImages.IMG_OBJ_ELEMENT;
			if (obj instanceof TreeParent)
			   imageKey = ISharedImages.IMG_OBJ_PROJECT;
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}
	}
	
	public CorpusView() {
		this.m_alListeners = new ArrayList();
		m_alListeners.add(Activator.getDefault().getT20());
	}

	public void addListener(CorpusListener listener) {
		m_alListeners.add(listener);
	}
	
	@Override
	public void createPartControl( Composite parent ) {
		m_treeViewer = new TreeViewer( parent );
		drillDownAdapter = new DrillDownAdapter(m_treeViewer);
		m_provider = new CorpusProvider( this, getViewSite());
		m_treeViewer.setContentProvider( m_provider );
		
		m_treeViewer.setLabelProvider(new ViewLabelProvider());
		m_treeViewer.setSorter(new NameSorter());
		m_treeViewer.setInput(getViewSite());
		makeActions();
		hookContextMenu();
	}

	private void hookContextMenu() {
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager manager) {
				CorpusView.this.fillContextMenu(manager);
			}
		});
		Menu menu = menuMgr.createContextMenu(m_treeViewer.getControl());
		m_treeViewer.getControl().setMenu(menu);
		getSite().registerContextMenu(menuMgr, m_treeViewer);
	}
	
	private void fillContextMenu(IMenuManager manager) {
		IStructuredSelection selection = (IStructuredSelection) m_treeViewer
		.getSelection();
		Iterator iterator = selection.iterator(); 
		if(iterator.hasNext()) {
			TreeObject node = (TreeObject) iterator.next();
			if(node.getName().equals( "Corpus" )) {
				actionAdd.setEnabled( true );		
				actionRemove.setEnabled( false );
				actionClear.setEnabled( false );
				actionShow.setEnabled( false );
				
			}else {
				actionAdd.setEnabled( false );
				actionRemove.setEnabled( true );
				actionClear.setEnabled( true );
				actionShow.setEnabled( true );
			}	
		}
		manager.add(actionAdd);
		manager.add(actionRemove);
		manager.add(actionClear);
		manager.add(actionShow);
	}
	

	private void makeActions() {
		actionAdd = new Action() {
			public void run() {
				doAdd();
			}
		};
		actionAdd.setText("Add...");
		actionAdd.setToolTipText("Coppus add tooltip");
		actionAdd.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionRemove = new Action() {
			public void run() {
				doRemove();
			}
		};
		actionRemove.setText("Remove");
		actionRemove.setToolTipText("Remove Corpus tooltip");
		actionRemove.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionClear = new Action() {
			public void run() {
				doClear();
			}
		};
		actionClear.setText("Clear");
		actionClear.setToolTipText("Clear Corpus tooltip");
		actionClear.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionShow = new Action() {
			public void run() {
				doShow();
			}
		};
		
		actionShow.setText("Show...");
		actionShow.setToolTipText("Show Corpus tooltip");
		actionShow.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		doubleClickAction = new Action() {
			public void run() {
				ISelection selection = m_treeViewer.getSelection();
				Object obj = ((IStructuredSelection)selection).getFirstElement();
				showMessage("Double-click detected on "+obj.toString());
			}
		};
	}
	
	private void showMessage(String message) {
		MessageDialog.openInformation(
				m_treeViewer.getControl().getShell(),
			"Sample View",
			message);
	}
	
	private void doAdd() {
		
		FileDialog fDialog = new FileDialog(new Shell(), SWT.OPEN | SWT.MULTI);
		fDialog
				.setFilterExtensions(new String[] { "*.txt", "*.pdf", "*.html", "*.htm" });
		String fileName = fDialog.open();
		String[] fileNames = fDialog.getFileNames();
		String path = fDialog.getFilterPath() + File.separator;

		ArrayList alFiles = new ArrayList();
		for (int i = 0; i < fileNames.length; i++) {
			//Document d = new Document(path + fileNames[i]);
			alFiles.add(path + fileNames[i]);
			notifyListeners(CorpusListener.ADD, path + fileNames[i]);
		}
		
		m_provider.addNewObjects(alFiles.toArray());
		m_treeViewer.setSelection(null);
		m_treeViewer.refresh();
	}
	
	public void doRemove() {
		ArrayList alFiles = new ArrayList();
		IStructuredSelection selection = (IStructuredSelection) m_treeViewer
				.getSelection();
		for (Iterator iterator = selection.iterator(); iterator.hasNext();) {
			//Document d = (Document) iterator.next();
			TreeObject sFile = (TreeObject) iterator.next();
			alFiles.add( sFile );
			notifyListeners(CorpusListener.REMOVE, sFile.getName());
		}
		m_provider.remove(alFiles.toArray());
		m_treeViewer.refresh();
	   //notifyListeners(CorpusListener.ADD, sFile);
	}
	
	public void doClear() {
		m_provider.removeAll();
		m_treeViewer.refresh();
	}
	public void doShow() {
		IStructuredSelection selection = (IStructuredSelection) m_treeViewer
		.getSelection();
		Iterator iterator = selection.iterator(); 
		if(iterator.hasNext()) {
			
			TreeObject sFile = (TreeObject) iterator.next();
			HelloJface demo = new HelloJface(null, sFile.getName());
			
			demo.setBlockOnOpen(true);
			demo.open();
			//new WrapLines();
			/*//IFile file = ;
			IWorkbenchPage page = getSite().getPage();
			IEditorDescriptor desc = PlatformUI.getWorkbench(). 
			getEditorRegistry().getDefaultEditor(sFile.getName()); 
			try {                                            
				page.openEditor(new FileEditorInput(),desc.getId()); 			                                        
			} catch (PartInitException e) {                                                
				e.printStackTrace(); 
			}*/
			
			//Display.getCurrent().dispose();

		} else {
			
		}
	}
	
	private void notifyListeners( int iMessage, String sFile ) {
		
		Iterator iter = m_alListeners.iterator();
		while( iter.hasNext() ) {
			( (CorpusListener)iter.next() ).corpusChanged( iMessage, sFile );
		}
	}
	
	public void reset() {
		doClear();
	}

	public void update( Corpus m_corpus ) {
		java.util.List docs = m_corpus.getDocuments();
		ArrayList alFiles = new ArrayList();
		for( int i = 0; i < docs.size(); i++ ) {
			AbstractDocument doc = (AbstractDocument)docs.get( i );
			alFiles.add(doc.getURI().toString());
		}
		m_provider.addNewObjects(alFiles.toArray());
		m_treeViewer.setSelection(null);
		m_treeViewer.refresh();
	}
	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		m_treeViewer.getControl().setFocus();
	}
}

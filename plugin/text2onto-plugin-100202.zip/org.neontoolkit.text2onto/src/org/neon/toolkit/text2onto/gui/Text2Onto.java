package org.neon.toolkit.text2onto.gui;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IPerspectiveRegistry;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ListDialog;
import org.eclipse.ui.dialogs.PreferencesUtil;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.DataModel2FLogic;
import org.neon.toolkit.text2onto.DataModel2OWL;
import org.neon.toolkit.text2onto.gui.actions.ActionListener;
import org.neon.toolkit.text2onto.gui.preferences.PreferencePage;
import org.neon.toolkit.text2onto.ontology.T2OSimpleOWLWriter;
import org.neon.toolkit.text2onto.ontology.OWLWriter;
import org.ontoware.text2onto.algorithm.AbstractAlgorithm;
import org.ontoware.text2onto.algorithm.AbstractAuxiliaryAlgorithm;
import org.ontoware.text2onto.algorithm.AbstractCombiner;
import org.ontoware.text2onto.algorithm.AbstractComplexAlgorithm;
import org.ontoware.text2onto.algorithm.AlgorithmController;
import org.ontoware.text2onto.algorithm.ComplexAlgorithm;
import org.ontoware.text2onto.algorithm.ControllerException;
import org.ontoware.text2onto.algorithm.ProgressListener;
import org.ontoware.text2onto.algorithm.normalizer.DefaultNormalizer;
import org.ontoware.text2onto.algorithm.normalizer.Zero2OneNormalizer;
import org.ontoware.text2onto.change.Change;
import org.ontoware.text2onto.change.ChangeRequest;
import org.ontoware.text2onto.change.POMChange;
import org.ontoware.text2onto.corpus.AbstractDocument;
import org.ontoware.text2onto.corpus.Corpus;
import org.ontoware.text2onto.corpus.CorpusFactory;
import org.ontoware.text2onto.corpus.DocumentFactory;
import org.ontoware.text2onto.ontology.KAONWriter;
import org.ontoware.text2onto.ontology.OntologyWriter;
import org.ontoware.text2onto.ontology.RDFSWriter;
import org.ontoware.text2onto.persist.PersistenceManager;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMFactory;
import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMWrapper;
import org.ontoware.text2onto.util.Settings;

import com.ontoprise.ontostudio.perspectives.SchemaPerspective;


public class Text2Onto implements CorpusListener, WorkflowListener, POMListener, 
	ProgressListener, org.neon.toolkit.text2onto.gui.actions.ActionListener{

	
	//private final static String m_sVersion = "1.2b";
	
	private AlgorithmController m_controller;

	private WorkflowView m_workflowView;
	
	private PreferencePage m_preferencePage;

	private Corpus m_corpus;

	private CorpusView m_corpusView;
	
	private POMView m_pomView;

	private HashMap m_hmClass2Algorithm;

	private HashMap m_hmName2Complex;

	private HashMap m_hmURI2Document;
	
	private PersistenceManager m_persistenceManager;

	private POMWrapper m_pomWrapper;
	
	private static Text2Onto m_text2onto;
	
	private IProgressMonitor m_monitor;
	
	private boolean m_INIT_DONE; 
	
	PreferenceLinkWnd m_PreferenceLinkWnd;
	
	public class PreferenceLinkWnd extends Window {
		CLabel m_Text;
		Link   m_Link;
		PreferenceLinkWnd plw = this;
	    public PreferenceLinkWnd(Shell arg0) {
	          super(arg0);	          
	    }
      @Override
	    protected Control createContents(Composite parent) {
	       
    	 getShell().setText("Text2Onto - Warning");
    	 
    	 Rectangle rect = getShell().getDisplay().getPrimaryMonitor().getBounds();
    	 getShell().setBounds(rect.width/2-250, rect.height/2-50, 500, 100);
     	 parent.setSize(500, 150); 
     	 
     	 Composite c = new Composite( parent, SWT.BORDER );
		 c.setLayout( new GridLayout() );
		 c.setLayoutData(new GridData(GridData.FILL_BOTH) );
	   
		 
     	 m_Text = new CLabel(c, SWT.HORIZONTAL|SWT.SHADOW_NONE);
     	 Image image = getShell().getDisplay().getSystemImage(SWT.ICON_INFORMATION);
     	 m_Text.setImage(image);
     	 m_Text.setText("Plugin initialize error, please configure the preference page properly.");
     	 
     	 
     	 GridData data = new GridData(GridData.FILL);
 	     data.horizontalSpan = 5;
 	     m_Text.setLayoutData(data);
     	 
     	 m_Link = new Link(c, SWT.HORIZONTAL|SWT.SHADOW_NONE );
     	 m_Link.setText("<A>" + PreferencePage.ID + "</A>");
     	 m_Text.setLayoutData(data);
     	 m_Link.addSelectionListener(new SelectionAdapter() {		
				public void widgetSelected(SelectionEvent e) {
					plw.close();
					PreferenceDialog dialog = PreferencesUtil.createPreferenceDialogOn(null, 
					 		  PreferencePage.ID, null, null); 
					dialog.open(); 
					
				}
		 });
     	 
	      
	     return parent;
	  }

}

   public void progressChanged( String sAlgorithm, int step, int steps ) {
   	if(step>1)
   		m_monitor.worked( step-1 );
   		m_monitor.subTask( sAlgorithm );
		System.out.println( sAlgorithm + "-" + step + "-" + steps);
	}
	
	public Text2Onto() {
		m_text2onto = this;

		//getSettings();
		m_INIT_DONE = false;
		this.reset();
	}
	
	public void buttonPressed(int iMessage) {
		switch(iMessage) {
			case ActionListener.RUN :
				doRun();
				break;
			case ActionListener.NEW :
				doNew();
				break;
			case ActionListener.EXPORT :
				doExport();
				break;
			case ActionListener.TOFLOGIC :
				doToFLogicOnto();
				break;	
			case ActionListener.TOOWL :
				doToOWLOnto();
				break;	
		}
	}
	
	public PreferencePage getPereferencePage() {
		if (m_preferencePage == null) {
			IWorkbenchPage pg = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage();
			//m_preferencePage = (WorkflowView) pg
			//		.findView("org.neon.toolkit.text2onto.WorkflowView");
		}
		return m_preferencePage;
	}
	
	public WorkflowView getWorkflowView() {
		if (m_workflowView == null) {
			IWorkbenchPage pg = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage();
			m_workflowView = (WorkflowView) pg
					.findView("org.neon.toolkit.text2onto.WorkflowView");
		}
		return m_workflowView;
	}

	public CorpusView getCorpusView() {
		if (m_corpusView == null) {
			IWorkbenchPage pg = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage();
			m_corpusView = (CorpusView) pg
					.findView("org.neon.toolkit.text2onto.CorpusView");
		}
		return m_corpusView;
	}

	public POMView getPOMView() {
		if (m_pomView == null) {
			IWorkbenchPage pg = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage();
			
			m_pomView = (POMView) pg
					.findView("org.neon.toolkit.text2onto.POMView");
		}
		return m_pomView;
	}
	
	/*
	 * sComplex: complex algorithm, e.g. ConceptExtraction sAlgorithmClass: simple algorithm, e.g.
	 * PatternConceptClassification sConfigClass: combiner or auxiliary algorithm
	 */
	public void workflowChanged( int iMessage, String sComplex, Class algorithmClass, Class configClass ) {
		if( m_hmName2Complex == null || m_hmName2Complex.size() == 0 ) 
		{
			m_hmName2Complex = new HashMap<String, ComplexAlgorithm>();
			java.util.List<String> names = getWorkflowView().getComplexNames();
			for( String sName : names ) 
			{	
				ComplexAlgorithm complex = new ComplexAlgorithm( sName );
				m_hmName2Complex.put( sName, complex );
				m_controller.addAlgorithm( complex );
				
			}
		}
		ComplexAlgorithm complex = (ComplexAlgorithm)m_hmName2Complex.get( sComplex );
		if( iMessage == WorkflowListener.COMBINER ) 
		{
			// System.out.println( "Text2Onto.controllerChanged COMBINER: "+ sComplex +", "+ configClass );
			AbstractCombiner combiner = null;
			try {
				combiner = (AbstractCombiner)configClass.newInstance();
			}
			catch( Exception e ) {
				System.out.println( "Cannot instantiate combiner: " + configClass );
				return;
			}
			complex.setCombiner( combiner );
		}else if ( iMessage == WorkflowListener.RESET ) {
			m_hmClass2Algorithm.clear();
			//m_controller.resetAlgorithms();
			List<AbstractAlgorithm> al = m_controller.getAlgorithms();
			for( AbstractAlgorithm algorithm: al )
			{
				if( algorithm instanceof AbstractComplexAlgorithm ){
					for ( AbstractAlgorithm ca: algorithm.getAlgorithms())
						m_controller.removeAlgorithm( ca );
				}
				else {
					m_controller.removeAlgorithm( algorithm );
				}
			}
		ArrayList<ChangeRequest> changes = new ArrayList<ChangeRequest>();
		for( Object object: m_pomWrapper.getChangeable().getObjects()){
				changes.add( new ChangeRequest( new POMChange( Change.Type.REMOVE, this, (POMObject)object, ((POMObject)object).getProbability(), new ArrayList() ) ) );
		}
		
		m_pomWrapper.processChangeRequests( changes );
		updatePOMPanel();
			
		}else{
			AbstractAlgorithm algorithm = null;
			try {
				algorithm = (AbstractAlgorithm)m_hmClass2Algorithm.get( algorithmClass );
			}
			catch( Exception e ) {
				System.out.println( "Cannot find algorithm: " + algorithmClass );
				return;
			}
			if( iMessage == WorkflowListener.ADD ) 
			{
				// System.out.println( "Text2Onto.controllerChanged ADD: "+ sComplex +", "+ algorithmClass );
				if( algorithm == null ) {
					try {
						algorithm = (AbstractAlgorithm)algorithmClass.newInstance();
					}
					catch( Exception e ) {
						System.out.println( "Cannot instantiate algorithm: " + algorithmClass );
						return;
					}
					m_hmClass2Algorithm.put( algorithmClass, algorithm );
				}
				m_controller.addAlgorithmTo( complex, algorithm );
			}
			else if( iMessage == WorkflowListener.REMOVE ) {
				// TODO
				System.out.println( "Text2Onto.controllerChanged REMOVE: " + sComplex + ", " + algorithmClass );
			}
			else if( iMessage == WorkflowListener.AUXILIARY ) 
			{
				// System.out.println( "Text2Onto.controllerChanged AUXILIARY: "+ sComplex +", "+ algorithmClass +", "+
				// configClass );
				AbstractAuxiliaryAlgorithm auxiliary = null;
				try {
					auxiliary = (AbstractAuxiliaryAlgorithm)configClass.newInstance();
				}
				catch( Exception e ) {
					System.out.println( "Cannot instantiate auxiliary algorithm: " + configClass );
					return;
				}
				m_controller.addAlgorithmTo( algorithm, auxiliary );
			} 
		}
	}

	public void corpusChanged( int iMessage, String sFile ) {
		
		URI uri = null;
		AbstractDocument doc = null;
		try {
			uri = ( new File( sFile ) ).toURI();
			System.out.println(uri.toString());
			doc = (AbstractDocument)m_hmURI2Document.get( uri );
			if( doc == null ) {
				doc = DocumentFactory.newDocument( uri );
				m_hmURI2Document.put( uri, doc );
			}
		}
		catch( Exception e ) {
			System.out.println( "Cannot create document: " + sFile );
			return;
		}
		if( iMessage == CorpusListener.ADD ) {
			m_corpus.addDocument( doc );
		}
		else if( iMessage == CorpusListener.REMOVE ) {
			m_corpus.removeDocument( doc );
		}
	}
	
	public void pomChanged( int iMessage, java.util.List<? extends POMObject> objects ){ 
		ArrayList<ChangeRequest> changes = new ArrayList<ChangeRequest>();
		if( iMessage == POMListener.ADD ){
			for( POMObject object: objects ){
				changes.add( new ChangeRequest( new POMChange( Change.Type.ADD, this, object, object.getProbability(), new ArrayList() ) ) );
			}
		}
		else if( iMessage == POMListener.REMOVE ){
			for( POMObject object: objects ){
				changes.add( new ChangeRequest( new POMChange( Change.Type.REMOVE, this, object, object.getProbability(), new ArrayList() ) ) );
			}
		}
		m_pomWrapper.processChangeRequests( changes );
		updatePOMPanel();
		
	}
	
	
	private void updateWorkflowPanel() {
		getWorkflowView().update( m_controller.getComplexAlgorithms() );
	}

	private void updateCorpusPanel() {
		getCorpusView().reset();
		getCorpusView().update( m_corpus );
	}

	private void updatePOMPanel() {
		System.out.println( "POM:\n" + m_pomWrapper.getChangeable() );
		getPOMView().update(m_pomWrapper.getChangeable());
		//System.out.println( "POM:\n" + m_pomWrapper.getChangeable() );

	}
	
	public void doRun() {
		
		try {
			System.out.println("Corpus: " + m_corpus);
			System.out.println("Run: " + m_hmName2Complex.values());
			System.out.println("Controller: " + m_controller);
			
			m_controller.addProgressListener( getPOMView() );
			
			Job job = new Job("Online Reservation") {
		        protected IStatus run(IProgressMonitor monitor) { 
		      	  try {
		      		 Display.getDefault().asyncExec( new Runnable() {
	      				  	public void run() {
	      					// TODO Auto-generated method stub
	      				  		getPOMView().getProgressText().setVisible( true );
	      				  		getPOMView().getProgressText().setText( "Ready to run..." );
	      				  		IStatusLineManager statusline = getPOMView().getViewSite().getActionBars().getStatusLineManager();
	      				  		
	      				  		statusline.getProgressMonitor().beginTask( "Excuting: ", 8 );
	      				  		statusline.getProgressMonitor().subTask( "preprocessing..." );
	      				  		statusline.setMessage( "Ready to run..." );
	      				  		
	      				  	}
	      			 });
		      		 m_monitor = monitor;
		      		 monitor.beginTask( "Excuting Algorithms", 8 );

		        		 m_controller.execute();
		        		 monitor.worked( 8 );
		        		 monitor.done();
		      	  }catch (Exception e) {
		      		  e.printStackTrace();
		      	  }
		      	  
		      	  return Status.OK_STATUS;
		        }
		     };
		     
		     job.addJobChangeListener(new JobChangeAdapter() {
		        public void done(IJobChangeEvent event) {
		      	  if (event.getResult().isOK()) {
		      		  if(event.getJob().getName().equals( "Online Reservation" )) {
		      			  System.out.println("Job completed successfully");
		      			  System.out.println(m_pomWrapper.getChangeable());
		      			  Display.getDefault().asyncExec( new Runnable() {
		      				  	public void run() {
		      					// TODO Auto-generated method stub
		      				  		
		      				  		IStatusLineManager statusline = getPOMView().getViewSite().getActionBars().getStatusLineManager();
		      				  		statusline.getProgressMonitor().worked( 7 );
		      				  		
		      				  		statusline.getProgressMonitor().subTask( "updating view..." );
		      				  		
		      				  		getPOMView().getProgressText().setText( "Setting POM..." );
		      				  		updatePOMPanel();
		      				  		getPOMView().getProgressText().setText( 
		      				  				m_pomWrapper.getChangeable().getObjects().size() + " POM Objects are created.");
		      				  		getPOMView().getProgressText().setVisible( false );
		      				  		
		      				  		statusline.getProgressMonitor().worked( 8 );
		      				  		statusline.getProgressMonitor().done();
		      				  		statusline.setMessage( "Done" );
		      				  	}
		      			  });
		      			  
		      		  }
		      	  }
		      	  else
		         	  System.out.println("Job did not complete successfully");        }
		     });
		   job.setSystem( true );
		   job.setPriority( Job.INTERACTIVE );
		   job.schedule();
	
			System.out.println(m_pomWrapper.getChangeable());
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void doNew() {
		try {
			this.reset();
			
			getWorkflowView().setNodeAlgorithms();
			
			if(m_INIT_DONE) {
				getCorpusView().doClear();
				getWorkflowView().doReset();
				getPOMView().doReset();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Boolean doExport() {
		
		FileDialog saveDialog = new FileDialog(new Shell(), SWT.SAVE);
		saveDialog.setFilterExtensions(new String[] { "*.owl", "*.owl", "*.kaon", "*.rdfs" });
		saveDialog.setFilterNames(new String[] {"Meta OWL file (*.owl)", "OWL file (*.owl)", "KAON file (*.kaon)", "RDFS file (*.rdfs)"});
		
		saveDialog.open();
		String filename = saveDialog.getFileName();
		//System.out.println(saveDialog.getFilterPath());
		
		/*
		KAON2Connection m_connection;
		String m_sLogicalURI = "http://www.text2onto.org#";
		String m_sPhysicalURI;
		String fn;
		try {
			
			NavigatorControl control = new NavigatorControl();
			m_sLogicalURI = control.getValidModuleIdentifier( m_sLogicalURI );
			m_connection = KAON2Manager.newConnection(); 
			
			fn = "D:/aaaa.owl";
			File file=new File(fn);
			file.createNewFile();
			m_sPhysicalURI = file.toURI().toString();
			m_connection = KAON2Manager.newConnection(); 
			DefaultOntologyResolver resolver = new DefaultOntologyResolver();
			resolver.registerReplacement( m_sLogicalURI, m_sPhysicalURI );
			
			m_connection.setOntologyResolver( resolver );
			
			Ontology m_ontology = m_connection.createOntology( m_sLogicalURI, new HashMap<String,Object>() );
			
			m_ontology.saveOntology( OntologyFileFormat.OWL_RDF, file, "ISO-8859-1" );
			
		}catch( Exception e ) {
			System.out.print( "can not create conntection" );
			e.printStackTrace();
		}
		
		
		System.out.println("---------------------");
		*/
		
		POM exportPOM = getPOMView().getFilteredPOM();
		
		//POM exportPOM =  m_pomWrapper.getChangeable();
		
		if(filename.equals("")) return false;
		String sExtension;
		if(filename.indexOf(".kaon")==filename.length() - 5) {
			sExtension = "kaon";
		}else if (filename.indexOf(".rdfs")==filename.length() - 5) {
			sExtension = "rdfs";
		}else if (filename.indexOf(".owl")==filename.length() - 4) {
			sExtension = "owl";
		}else {
			sExtension = "";
		}
		if( sExtension.length() == 0 ) return false;
		
		File file = new File(saveDialog.getFilterPath(), filename);
		URI uri = file.toURI();
		String sURI = uri.toString();
		OntologyWriter writer = null;
		try {
			if( !sURI.endsWith( "."+ sExtension ) ){
				uri = new URI( sURI +"."+ sExtension );
			}
			if( sExtension.equals( "kaon" ) ) {
				writer = new KAONWriter( exportPOM );
			}
			else if( sExtension.equals( "rdfs" ) ) {
				writer = new RDFSWriter( exportPOM );
			}
			else if( sExtension.equals( "owl" ) ){
				writer = new T2OSimpleOWLWriter( exportPOM );
			}
			if( writer != null ) {
				writer.write( uri );
			}
		}
		catch( Exception e ) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void doToFLogicOnto() {
		try {
			
			DataModel2FLogic d2f = new DataModel2FLogic();
			d2f.setUp();
			d2f.testAddDataModel(getPOMView().getFilteredPOM());
			//d2f.testAddConceptView();
			
			// switch to ontoprise perspective.
			switchPerspective();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void doToOWLOnto() {
		try {
			DataModel2OWL d2o = new DataModel2OWL();
			d2o.setUp2(getPOMView().getFilteredPOM());
			
			// switch to ontoprise perspective.
			switchPerspective();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	protected IProject getCurrentProject() throws Exception {
		  IProject[] project = ResourcesPlugin.getWorkspace().getRoot().getProjects();
	     System.out.println("number of projects: "+project.length);
	     if(project.length<1)
	   	  return null;
	     
	     ListDialog ld = new ListDialog(null);
	    //	  project, new ArrayContentProvider(), new LabelProvider(), "Worksapce java projects");
	     ld.setTitle("Select Project");
	     ld.setMessage("projects in Schema");
	     
	     ld.setContentProvider( new ArrayContentProvider());
	     ld.setLabelProvider( new  LabelProvider());
	     ld.setInput( project );
	     
	     IProject prj = null;
	     if (ld.open() == ListDialog.OK) {
				Object selection[] = ld.getResult();
				prj = (IProject)selection[0];
	     }
	     
	     return prj;
	  }
	public void switchPerspective() {

		String resourcePesId = SchemaPerspective.ID;//"com.ontoprise.ontostudio.perspectives.Schema";
		//	 get Perspective Registry
		IPerspectiveRegistry registry = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getWorkbench().getPerspectiveRegistry();
		//	 find Resource Perspective with extenion Id
		IPerspectiveDescriptor pd = registry.findPerspectiveWithId(resourcePesId);
		//	 get current active perspective
		IPerspectiveDescriptor currentPerspective = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getWorkbench().getActiveWorkbenchWindow().getActivePage().getPerspective();
		//	 testing current perspective is "Resource Perspective" ,not then show
		//	 it.
		if (!resourcePesId.equals(currentPerspective.getId())) {
			PlatformUI.getWorkbench().getActiveWorkbenchWindow().getWorkbench().getActiveWorkbenchWindow().getActivePage().setPerspective(pd);
		}
		
		//IWorkbenchPage pg = PlatformUI.getWorkbench()
		//.getActiveWorkbenchWindow().getActivePage();
		//m_workflowView = (WorkflowView) pg
		//.findView("org.neon.toolkit.text2onto.WorkflowView");
		
	}
	
	
	public static Text2Onto getText2Onto() {
		if (m_text2onto == null) {
			m_text2onto = new Text2Onto();
		}
		return m_text2onto;
	}
	
	private void reset() {
		m_corpus = CorpusFactory.newCorpus();
		m_pomWrapper = new POMWrapper(POMFactory.newPOM());
		
		Properties props = getSettings();
		
		try {
			System.out.println( "getting controller" );
			
			m_controller = new AlgorithmController( m_corpus, m_pomWrapper
					.getChangeable(), props );
			
			//m_controller.init( m_corpus, m_pomWrapper.getChangeable(), getSettings() );
			
			if(Activator.getDefault().getPreferenceStore().getBoolean( "normalisation" ))
				m_controller.setNormalizer( new Zero2OneNormalizer() );
			else
				m_controller.setNormalizer( new DefaultNormalizer() ); 
			
			m_INIT_DONE = true;
			
		} catch (ControllerException  e) {
			System.out.println(e.toString());
			//m_PreferenceLinkWnd = new PreferenceLinkWnd( new Shell() );
			//m_PreferenceLinkWnd.setBlockOnOpen(true);
			//m_PreferenceLinkWnd.open();
			MessageDialog.openInformation(
			  		new Shell(),
			  		"Text2Onto",
			  		"Gate path is not set, please config preference page properly, and restart plugin.");
			
			//ActionFactory.CLOSE_PERSPECTIVE.create(Activator.getDefault().getWorkbench().getActiveWorkbenchWindow()).run();
		}
		
		
		m_hmURI2Document = new HashMap();
		m_hmClass2Algorithm = new HashMap();
		m_hmName2Complex = new HashMap();
	}
	
	public Properties getSettings() {
		
		IPreferenceStore store = Activator.getDefault().getPreferenceStore();
		Properties props = new Properties();
		if(store.getString(Settings.GATE_DIR).length()==0){
			//PlatformUI.getWorkbench().getActiveWorkbenchWindow().
			//	getActivePage().findViewReference("org.neon.toolkit.text2onto.gui.preferencePage");
			m_PreferenceLinkWnd = new PreferenceLinkWnd( new Shell() );
			m_PreferenceLinkWnd.setBlockOnOpen(true);
			m_PreferenceLinkWnd.open();
			
			
			//org.eclipse.ui.dialogs.PreferencesUtil.createPreferenceDialogOn(shell, preferencePageId, displayedIds, data)
			//MessageDialog.openInformation(
	  		//		new Shell(),
	  		//		"Text2Onto",
	  		//		"Gate path is not set, please config preference page properly");
		}
		
		if(store.getString(Settings.GATE_DIR).length()>0) {
			
			props.setProperty(Settings.TEMP_CORPUS, store.getString( Settings.TEMP_CORPUS ));
			props.setProperty(Settings.LANGUAGE, store.getString( Settings.LANGUAGE ));
			props.setProperty(Settings.GATE_DIR, store.getString( Settings.GATE_DIR ).replace( "//", "/" ));
			props.setProperty(Settings.GATE_APP, store.getString( Settings.GATE_APP ));
			props.setProperty(Settings.JWNL_PROPERTIES, store.getString( Settings.JWNL_PROPERTIES ).replace( "//", "/" ));
			props.setProperty(Settings.CREOLE_DIR, store.getString( Settings.CREOLE_DIR ).replace( "//", "/" ));
			props.setProperty(Settings.DATASTORE, store.getString( Settings.DATASTORE ));
			props.setProperty(Settings.ICONS, store.getString( Settings.ICONS ));
			props.setProperty(Settings.JAPE_MAIN, store.getString( Settings.JAPE_MAIN ));
			props.setProperty(Settings.STOP_FILE, store.getString( Settings.STOP_FILE ));
			props.setProperty(Settings.SPANISH_WORD_NET_DIR, store.getString( Settings.SPANISH_WORD_NET_DIR ));
			props.setProperty(Settings.TAGGER_DIR, store.getString( Settings.TAGGER_DIR ));
			
			String sGatehome_dir_value = store.getString("gatehome_dir");
			if(sGatehome_dir_value.length()>0) {
				System.setProperty( "gate.home", sGatehome_dir_value );
				System.setProperty( "gate.config", sGatehome_dir_value + "/gate.xml" );
				System.setProperty( "gate.plugins.home", sGatehome_dir_value + "/plugins" );
				System.setProperty( "load.plugin.path", "file:/" + sGatehome_dir_value + "/plugins/ANNIE" );
				System.setProperty( "file.encoding", "ISO-8859-1" );
			}
			
		} else {
			/*
			try {
				Settings.load("text2onto.properties");
				props = Settings.getProperties();
				store.setValue( Settings.TEMP_CORPUS, Settings.get( Settings.TEMP_CORPUS ) );
				store.setValue( Settings.LANGUAGE, Settings.get( Settings.LANGUAGE ) );
				store.setValue( Settings.GATE_DIR, Settings.get( Settings.GATE_DIR ) );
				store.setValue( Settings.GATE_APP, Settings.get( Settings.GATE_APP ) );
				store.setValue( Settings.JWNL_PROPERTIES, Settings.get( Settings.JWNL_PROPERTIES ) );
				store.setValue( Settings.CREOLE_DIR, Settings.get( Settings.CREOLE_DIR ) );
				store.setValue( Settings.DATASTORE, Settings.get( Settings.DATASTORE ) );
				store.setValue( Settings.ICONS, Settings.get( Settings.ICONS ) );
				store.setValue( Settings.JAPE_MAIN, Settings.get( Settings.JAPE_MAIN ) );
				store.setValue( Settings.STOP_FILE, Settings.get( Settings.STOP_FILE ) );
				store.setValue( Settings.SPANISH_WORD_NET_DIR, Settings.get( Settings.SPANISH_WORD_NET_DIR ) );
				store.setValue( Settings.TAGGER_DIR, Settings.get( Settings.TAGGER_DIR ) );
				
				String gate_dir = Settings.get( Settings.GATE_DIR );
				String text2onto_dir = gate_dir.substring( 0, gate_dir.indexOf( "/lib/gate" ));
				
				store.setValue( PreferencePage.sTEXT2ONTO_DIR, text2onto_dir );
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			*/
		}
		
		return props;
	}
}

package org.neon.toolkit.text2onto.gui.actions;


import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

/**
 * Our sample action implements workbench action delegate.
 * The action proxy will be created by the workbench and
 * shown in the UI. When the user tries to use the action,
 * this delegate will be created and execution will be 
 * delegated to it.
 * @see IWorkbenchWindowActionDelegate
 */
public class AboutT2OAction implements IViewActionDelegate {
	private IViewPart view;
	/**
	 * The constructor.
	 */
	public AboutT2OAction() {
	}

	/**
	 * The action has been activated. The argument of the
	 * method represents the 'real' action sitting
	 * in the workbench UI.
	 * @see IWorkbenchWindowActionDelegate#run
	 */
	public void run(IAction action) {
		try {
		MessageDialog.openInformation(
				view.getViewSite().getShell(),
				"Text2Onto Plug-in",
				"Text2Onto Plug-in\n\n" +
				"Version: 1.0b\n\n" +
				"Johanna Voelker and Hua Gao\n\n" +
				"Institute AIFB, University of Karlsruhe\n\n" +
				"http://ontoware.org/projects/text2onto/\n" 
				//+ AbstractAlgorithm.class.getProtectionDomain().getCodeSource().getLocation().toURI().toString()
				);
		}catch (Exception e){
			e.printStackTrace();
		
		}
		
	}

	/**
	 * Selection in the workbench has been changed. We 
	 * can change the state of the 'real' action here
	 * if we want, but this can only happen after 
	 * the delegate has been created.
	 * @see IWorkbenchWindowActionDelegate#selectionChanged
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * We can use this method to dispose of any system
	 * resources we previously allocated.
	 * @see IWorkbenchWindowActionDelegate#dispose
	 */
	public void dispose() {
	}

	/**
	 * We will cache window object in order to
	 * be able to provide parent shell for the message dialog.
	 * @see IWorkbenchWindowActionDelegate#init
	 */
	public void init(IViewPart viewpart) {
		this.view = viewpart;
	}
	
}
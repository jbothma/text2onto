package org.neon.toolkit.text2onto.gui;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ListDialog;
import org.eclipse.ui.dialogs.ListSelectionDialog;
import org.eclipse.ui.part.DrillDownAdapter;
import org.eclipse.ui.part.ViewPart;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.WorkflowProvider;
import org.neon.toolkit.text2onto.gui.common.MultiListDialog;
import org.neon.toolkit.text2onto.gui.common.TreeObject;
import org.neon.toolkit.text2onto.gui.common.TreeParent;
import org.ontoware.text2onto.algorithm.AbstractAlgorithm;

public class WorkflowView extends ViewPart {
	
	static IWorkbenchWindow window;

	private TreeViewer m_treeViewer;
	private DrillDownAdapter drillDownAdapter;
	
	private WorkflowProvider m_provider;
	private ArrayList m_alListeners;
	
	private Action actionAdd;
	private Action actionRemove;
	private Action actionReset;
	private Action actionCombine;
	private Action actionConfig;
	
	/* available algorithms */
	private HashMap m_hmNode2Algorithms;

	/* available combiners */
	private List m_combiners;

	/* available auxiliary algorithms */
	private List m_auxiliaries;

	private String[] m_sComplex = { "Concept", "Instance", "Similarity",	
		"SubclassOf", "InstanceOf", "Relation", "Disjoint" }; //, "Disjoint" };

	private String[] m_sPackage = { "concept", "instance", "similarity", "taxonomic.subclassOf", 
		"taxonomic.instanceOf",	"relation.general", "axiom" }; //, "axiom" };
	
	private HashMap<TreeObject, Class> m_hmNode2Class;
	
	class ViewLabelProvider extends LabelProvider {

		public String getText(Object obj) {
			return obj.toString();
		}
		public Image getImage(Object obj) {
			String imageKey = ISharedImages.IMG_OBJ_ELEMENT;
			if (obj instanceof TreeParent) {
				if(((TreeParent)obj).hasChildren() ||
						((TreeParent)obj).getParent().getName().equals( "Algorithm" ))
					imageKey = ISharedImages.IMG_OBJ_PROJECT;
				else
					imageKey = ISharedImages.IMG_OBJ_ELEMENT;
			}
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}
	}
	
	
	class NameSorter extends ViewerSorter {
	}
	
	public WorkflowView() {
		this.m_alListeners = new ArrayList();
		m_hmNode2Algorithms = new HashMap();
		m_combiners = getClasses( "combiner" );
		m_auxiliaries = getClasses( "auxiliary" );
		m_hmNode2Class = new HashMap<TreeObject, Class>();
		m_alListeners.add(Activator.getDefault().getT20());
	}

	public void addListener(CorpusListener listener) {
		m_alListeners.add(listener);
	}
	
	@Override
	public void createPartControl( Composite parent ) {
		m_treeViewer = new TreeViewer( parent );
		drillDownAdapter = new DrillDownAdapter(m_treeViewer);
		m_provider = new WorkflowProvider( this, getViewSite());
		m_treeViewer.setContentProvider( m_provider );
		
		m_treeViewer.setLabelProvider(new ViewLabelProvider());
		
		m_treeViewer.setInput(getViewSite());
		
		initAlgorithmTree();
	
		makeActions();
		hookContextMenu();
		contributeToActionBars();
	}
	
	private void hookContextMenu() {
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager manager) {
				WorkflowView.this.fillContextMenu(manager);
			}
		});
		Menu menu = menuMgr.createContextMenu(m_treeViewer.getControl());
		m_treeViewer.getControl().setMenu(menu);
		getSite().registerContextMenu(menuMgr, m_treeViewer);
	}
	
	private void fillContextMenu(IMenuManager manager) {
		IStructuredSelection selection = (IStructuredSelection) m_treeViewer
		.getSelection();
		Iterator iterator = selection.iterator(); 
		if(iterator.hasNext()) {
			TreeObject node = (TreeObject) iterator.next();
			TreeParent parent = node.getParent();
			if(parent!=null) {
				if(parent.getName().equals( "Algorithm" )) {
					actionAdd.setEnabled( true );		
					actionCombine.setEnabled( true );
					actionRemove.setEnabled( false );
				}else {
					actionAdd.setEnabled( false );
					actionCombine.setEnabled( false );
					if(node.getName().equals( "Algorithm" )) {
						actionRemove.setEnabled( false );
					}else {
						//actionRemove.setEnabled( true );
					}	
				}
				
				TreeParent grandparent = parent.getParent();
				if( grandparent!=null ) {
					if ( grandparent.getName().equals( "Algorithm" )) {
						actionConfig.setEnabled( true );
					}else {
						actionConfig.setEnabled( false );
					}
				}
			}
			
		}
		manager.add(actionAdd);
		manager.add(actionRemove);
		manager.add(actionReset);
		manager.add(actionCombine);
		manager.add(actionConfig);
		
	}
	
	private void makeActions() {
		actionAdd = new Action() {
			public void run() {
				//showMessage("Corpus add executed");
				doAdd();
			}
		};
		actionAdd.setText("Add...");
		actionAdd.setToolTipText("Algorithm add tooltip");
		actionAdd.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionRemove = new Action() {
			public void run() {
				//doRemove();
			}
		};
		actionRemove.setText("Remove...");
		actionRemove.setEnabled( false );
		actionRemove.setToolTipText("Remove algorithm tooltip");
		actionRemove.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionReset = new Action() {
			public void run() {
				doReset();
			}
		};
		actionReset.setText("Reset...");
		actionReset.setToolTipText("Reset algorithm tooltip");
		actionReset.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionCombine = new Action() {
			public void run() {
				//showMessage("Corpus remove executed");
				doCombine();
			}
		};
		actionCombine.setText("Combiner...");
		actionCombine.setToolTipText("Combine algorithm tooltip");
		actionCombine.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		actionConfig = new Action() {
			public void run() {
				//showMessage("Corpus remove executed");
				doConfigure();
			}
		};
		actionConfig.setText("Configure...");
		actionConfig.setToolTipText("Configure tooltip");
		actionConfig.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
	}

	public void doAdd() {
		IStructuredSelection selections = (IStructuredSelection) m_treeViewer
		.getSelection();
		TreeObject node = (TreeObject)selections.iterator().next();
		List algorithms = (List)m_hmNode2Algorithms.get( node );
		Map<String,Class> classNameMap = new HashMap<String,Class>();
		for(Object algoClass : algorithms ) {
			String simpleClassName = ((Class)algoClass).getSimpleName();
			classNameMap.put( simpleClassName, (Class)algoClass);
		}
		
		List names = getClassNames( algorithms );
		MultiListDialog ld = new MultiListDialog(m_treeViewer.getControl().getShell());
		//ListSelectionDialog ld = new ListSelectionDialog(m_treeViewer.getControl().getShell(),
		//		names, new ArrayContentProvider(), new LabelProvider(), "Worksapce java projects");
		//ld.getTableViewer().getTable().getStyle()
		
		ld.setTitle("Select Algorithm");
      ld.setMessage("Worksapce java projects");
		
		ld.setContentProvider(new ArrayContentProvider());
		ld.setLabelProvider(new LabelProvider());

		ld.setInput( names );
		
		if (ld.open() == ListSelectionDialog.OK) {
			Object selection[] = ld.getResult();
			for(Object item : selection) {
				if(!isItemAdded(item.toString())) {
					TreeParent tpobj = (TreeParent)node;
					TreeParent newObject = new TreeParent(item.toString());
					tpobj.addChild( newObject );
					m_hmNode2Class.put( newObject, classNameMap.get( item ) );
					m_treeViewer.refresh();
					m_treeViewer.expandAll();
					System.out.println(node.getName() + " this is a the selected treeparent");
					notifyListeners( WorkflowListener.ADD, node.toString(), classNameMap.get( item ), null );
					
				}else {
					showMessage(item + " is already added.");
				}
			}
		}
		
	}
	public void doRemove() {
		IStructuredSelection selection = (IStructuredSelection) m_treeViewer
		.getSelection();
		for (Iterator iterator = selection.iterator(); iterator.hasNext();) {
			//Document d = (Document) iterator.next();
			/*TreeObject selectedObj = (TreeObject) iterator.next();
			if(selectedObj instanceof TreeParent) {
				for(TreeObject subObj : ((TreeParent)selectedObj).getChildren()) {
					((TreeParent)selectedObj).removeChild( subObj );
					notifyListeners(WorkflowListener.REMOVE, node.toString(), classNameMap.get( item ), null);
				}
				selectedObj.getParent().removeChild( selectedObj );
				notifyListeners(WorkflowListener.REMOVE, node.toString(), classNameMap.get( item ), null);
			}else {
				selectedObj.getParent().removeChild( selectedObj );
				notifyListeners(CorpusListener.REMOVE, sFile.getName());
			}*/
		}
	}
	
	public void doReset() {
		TreeParent root = (TreeParent)m_provider.getTreeRoot();
		Set<TreeObject> nodeset = m_hmNode2Algorithms.keySet();
		for( TreeObject node : nodeset ) {
			((TreeParent)node).clearChildren();
		}
		m_treeViewer.refresh();
		m_hmNode2Class.clear();
		notifyListeners( WorkflowListener.RESET, null, null, null );
	}
	
	public void doCombine() {
		IStructuredSelection selections = (IStructuredSelection) m_treeViewer
		.getSelection();
		TreeObject node = (TreeObject)selections.iterator().next();
		//List algorithms = (List)m_hmNode2Algorithms.get( node );
		Map<String,Class> classNameMap = new HashMap<String,Class>();
		for(Object combineClass : m_combiners ) {
			String simpleClassName = ((Class)combineClass).getSimpleName();
			classNameMap.put( simpleClassName, (Class)combineClass);
		}
		
		List names = getClassNames( m_combiners );
		MultiListDialog ld = new MultiListDialog(m_treeViewer.getControl().getShell());
		
		ld.setTitle("Select Combiners");
      ld.setMessage("Worksapce Neon Text2onto plugin");
		
		ld.setContentProvider(new ArrayContentProvider());
		ld.setLabelProvider(new LabelProvider());

		ld.setInput( names );
		
		if (ld.open() == ListDialog.OK) {
			Object selection[] = ld.getResult();
			if(selection.length>0) {
				Class combinerClass = classNameMap.get( selection[0] );
				notifyListeners( WorkflowListener.COMBINER, node.toString(), null, combinerClass );
			
			}
		}
	}
	
	public void doConfigure() {
		
		IStructuredSelection selections = (IStructuredSelection) m_treeViewer
		.getSelection();
		TreeObject node = (TreeObject)selections.iterator().next();
		//List algorithms = (List)m_hmNode2Algorithms.get( node );
		Map<String,Class> classNameMap = new HashMap<String,Class>();
		for(Object auxClass : m_auxiliaries ) {
			String simpleClassName = ((Class)auxClass).getSimpleName();
			classNameMap.put( simpleClassName, (Class)auxClass);
		}
		
		List names = getClassNames( m_auxiliaries );
		ListDialog ld = new ListDialog(m_treeViewer.getControl().getShell());
	
		ld.setTitle("Select Auxiliaries");
      ld.setMessage("Worksapce java projects");
		
		ld.setContentProvider(new ArrayContentProvider());
		ld.setLabelProvider(new LabelProvider());

		ld.setInput( names );
		
		if (ld.open() == ListDialog.OK) {
			Object selection[] = ld.getResult();
			for(Object item : selection) {
				if(!isItemAdded(item.toString())) {
					TreeParent tpobj = (TreeParent)node;
					TreeObject newObject = new TreeObject(item.toString());
					tpobj.addChild( newObject );
					m_hmNode2Class.put( newObject, classNameMap.get( item ) );
					Class algorithmClass = (Class)m_hmNode2Class.get( node );
					m_treeViewer.refresh();
					m_treeViewer.expandAll();
					System.out.println(node.getName() + " this is a the selected treeparent");
					notifyListeners( WorkflowListener.ADD, node.getParent().toString(), algorithmClass, classNameMap.get( item ) );
					
				}else {
					showMessage(item + " is already added.");
				}
			}
		}
		
	}
	
	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}
	
	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(actionReset);
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		manager.add(actionReset);
		drillDownAdapter.addNavigationActions(manager);
	}
	
	private void showMessage(String message) {
		MessageDialog.openInformation(
				m_treeViewer.getControl().getShell(),
			"Workflow View",
			message);
	}
	
	private boolean isItemAdded(String strItem) {
		boolean ret = false;
		for(TreeObject obj : m_hmNode2Class.keySet()) {
			if(strItem.equals( obj.getName() ))
				ret = true;
		}
		return ret;
	}

  private void initAlgorithmTree() {
		TreeParent root = (TreeParent)m_provider.getTreeRoot();
		
		for( int i=0; i<m_sComplex.length; i++ ) {
			TreeParent tp = new TreeParent(m_sComplex[i]);
			//tp.setName( String.valueOf( i ) );
			root.addChild( tp );
			m_hmNode2Algorithms.put( tp, getClasses( m_sPackage[i] ) );
		}
		//m_treeViewer.refresh();
		m_treeViewer.expandAll();
	}
  
   public void setNodeAlgorithms() {
   	TreeParent root = (TreeParent)m_provider.getTreeRoot();
   	TreeObject[] lto =  root.getChildren();
   	for( int i=0; i<m_sComplex.length; i++ ) {
			m_hmNode2Algorithms.put( lto[i], getClasses( m_sPackage[i] ) );
		}
   }
	
	private List getClasses( String sPackageName ) {
		ArrayList alClasses = new ArrayList();
		String sPackage = new String( sPackageName );

		String sPackageSup= AbstractAlgorithm.class.getPackage().getName();
		sPackage = sPackageSup + "." + sPackage;
	
		JarFile jar;
		try {
			//String t2oPath = Activator.getDefault().getPreferenceStore().getString( "text2onto_dir" );
			//jar = new JarFile(new File(t2oPath+"/lib/", "text2onto.jar"));
			jar = new JarFile(new File(AbstractAlgorithm.class.getProtectionDomain().getCodeSource().getLocation().toURI()));
			
//			showMessage(AbstractAlgorithm.class.getProtectionDomain().getCodeSource().getLocation().toURI().toString());
//			System.out.println(AbstractAlgorithm.class.getProtectionDomain().getCodeSource().getLocation().toURI());
			
			Enumeration entries = jar.entries();
			while (entries.hasMoreElements()) {
				JarEntry entry = (JarEntry) entries.nextElement();
				
				
            String thisClassName = getClassName(entry);
            if (thisClassName.startsWith( sPackage ) && thisClassName.endsWith( ".class" ) ) {
            	thisClassName = thisClassName.substring( 0, thisClassName.length() - 6 );
               if(!thisClassName.contains( "Abstract" )&& !thisClassName.contains( "$" )) {
               	Class c = Class.forName( thisClassName );
               	alClasses.add( c );
               }
               	
            }
        }


		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		/*File directory = new File( url.getFile() );
		if( directory.exists() ) {
			
			File[] files = directory.listFiles();
			for( int i = 0; i < files.length; i++ ) {
				String sFile = files[i].toString();
				String sFileName = files[i].getName().toString();
				if( files[i].isDirectory() ) {
					String sSubPackage = sPackageName + "." + sFileName;
					alClasses.addAll( getClasses( sSubPackage ) );
				}
				else if( sFile.endsWith( ".class" ) ) {
					String sClass = sFileName.substring( 0, sFileName.length() - 6 );
					try {
						Class c = Class.forName( "org.ontoware.text2onto.algorithm." + sPackageName + "." + sClass );
						if( !sClass.startsWith( "Abstract" ) && !sClass.contains( "$" )) {
							alClasses.add( c );
						}
					}
					catch( Exception e ) {
						e.printStackTrace();
					}
				}
			}
		}*/
		
		return alClasses;
	}
	
	protected String getClassName(JarEntry entry) {
      String className = entry.getName().replace('/', '.');
     /* System.out.println(className);
      if(className.endsWith( ".class" )) {
      	className = className.substring( 0, className.length() - 6 );
      }	
      int p = className.lastIndexOf( "." );
   	className = className.substring( 0, p+1 );*/
      return className;
  }

	private List getClassNames( List classes ) {
		ArrayList names = new ArrayList();
		Iterator iter = classes.iterator();
		while( iter.hasNext() ) {
			Class c = (Class)iter.next();
			names.add( c.getSimpleName() );
		}
		return names;
	}

	public List getComplexNames() {
		ArrayList<String> names = new ArrayList<String>();
		for( int i = 0; i < m_sComplex.length; i++ ) {
			names.add( m_sComplex[i] );
		}
		return names;
	}
	
	public void update( List<AbstractAlgorithm> algos ) {
		initAlgorithmTree();
		/*
		DefaultMutableTreeNode rootNode = m_tree.getRoot();
		Enumeration enumer = rootNode.children();
		int iChildCount = 0;
		while( enumer.hasMoreElements() ) {
			DefaultMutableTreeNode childNode = (DefaultMutableTreeNode)enumer.nextElement();
			ComplexAlgorithm complexAlgo = (ComplexAlgorithm)algos.get( iChildCount );

			// add algorithms

			List<AbstractAlgorithm> lAlgos = complexAlgo.getAlgorithms();
			for( AbstractAlgorithm algo : lAlgos ) {
				DefaultMutableTreeNode child = m_tree.addObject( childNode, algo.getClass().getSimpleName() );
			}

			// show the combiner only if some algorithms were selected
			if( lAlgos.size() > 0 ) {
				AbstractCombiner combiner = complexAlgo.getCombiner();
				// add combiner
				DefaultMutableTreeNode child = m_tree.addObject( childNode, combiner.getClass().getSimpleName() );
			}
			iChildCount++;
		}
		*/
	}
	
	private void notifyListeners( int iMessage, String sComplex, Class algorithmClass, Class configClass ) {
		Iterator iter = m_alListeners.iterator();
		while( iter.hasNext() ) {
			( (WorkflowListener)iter.next() ).workflowChanged( iMessage, sComplex, algorithmClass, configClass );
		}
	}

	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
	}
}

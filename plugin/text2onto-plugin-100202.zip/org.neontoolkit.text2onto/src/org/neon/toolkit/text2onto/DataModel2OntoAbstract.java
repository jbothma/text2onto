package org.neon.toolkit.text2onto;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ListDialog;
import org.semanticweb.kaon2.api.KAON2Exception;
import org.semanticweb.kaon2.api.logic.Term;

import com.ontoprise.ontostudio.datamodel.DatamodelPlugin;
import com.ontoprise.ontostudio.datamodel.api.IOntologyContainer;
import com.ontoprise.ontostudio.datamodel.exception.InternalOntoStudioException;
import com.ontoprise.ontostudio.datamodel.statements.InstanceProperty;
import com.ontoprise.ontostudio.gui.GuiPlugin;
import com.ontoprise.ontostudio.gui.instanceview.InstanceView;
import com.ontoprise.ontostudio.gui.navigator.MTreeView;
import com.ontoprise.ontostudio.gui.properties.EntityPropertiesView;
import com.ontoprise.ontostudio.perspectives.SchemaPerspective;
import com.ontoprise.ontostudio.script.ProcedureCallLogger;

public abstract class DataModel2OntoAbstract {
	/*
	static {
      while (DatamodelPlugin.getDefault().getContainer(Constants.TEST_PROJECT_NAME) == null) {
          try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              GuiPlugin.logError(e);
          }
      }
  }*/
  
  protected IWorkbench m_workbench;
  protected MTreeView m_mtreeView;
  protected InstanceView m_instanceView;
  protected EntityPropertiesView m_entityPropertiesView;
  protected IWorkbenchPage m_activePage;
  protected IWorkbenchWindow m_activeWorkbenchWindow;
  protected IWorkspace m_workspace;
  protected IWorkspaceRoot m_workspaceRoot;
  protected Display m_display;

  public void setUp() throws Exception {
      prepareViews();
      prepareControl();
      System.out.println("set up"); //$NON-NLS-1$
  }

  protected void prepareControl() throws Exception {
      IPreferenceStore store = GuiPlugin.getDefault().getPreferenceStore();
      store.setValue(GuiPlugin.NAMESPACE_PREFERENCE, true);
  }
  
  protected void prepareWorkspace() throws Exception {
      IProject[] project = ResourcesPlugin.getWorkspace().getRoot().getProjects();
      System.out.println("number of projects: "+project.length);
      
      for (int i = 0; i < project.length; i++) {
    	  System.out.println("projects: "+project[i].getName()); 
    	  /*
    	  IProjectNature nature = project[i].getNature(OntologyProjectNature.ID);
         if (nature != null && nature instanceof OntologyProjectNature) {
              OntologyProjectNature ontologyProjectNature = (OntologyProjectNature) nature;
              String[] ontologies = ontologyProjectNature.getOntologies();
              for (int j = 0; j < ontologies.length; j++) {
                  ModuleControl.getDefault().removeModule(ontologies[j], project[i].getName(), true);
              }
          }
          */
          project[i].delete(true, null);
      }
      m_workspace = ResourcesPlugin.getWorkspace();
      m_workspaceRoot = m_workspace.getRoot();
      m_workspaceRoot.delete(true, null);
  }

  protected void prepareViews() throws Exception {
      m_workbench = PlatformUI.getWorkbench();
      m_activeWorkbenchWindow = m_workbench.getActiveWorkbenchWindow();
      m_display = m_workbench.getDisplay();
      m_activePage = m_workbench.showPerspective(SchemaPerspective.ID, m_activeWorkbenchWindow);
      m_activePage.showView(MTreeView.ID);
      
      IViewReference[] parts = m_activePage.getViewReferences();
      m_mtreeView = (MTreeView) m_activePage.findViewReference(MTreeView.ID).getView(true);
      m_instanceView = (InstanceView) m_activePage.findViewReference(InstanceView.ID).getView(true);
      m_entityPropertiesView = (EntityPropertiesView) m_activePage.findViewReference(EntityPropertiesView.ID).getView(true);
  }


	public void tearDown() throws Exception {
      closeWorkspace();
      closeDialogs();
      System.out.println("tear down"); //$NON-NLS-1$
  }

  protected void closeDialogs() {
	}

	protected void closeWorkspace() throws Exception {
  }

  /*
  protected IProject createProject(String name, String[] ontologies) throws Exception {
      ProjectControl.getDefault().createNewOntologyProject(name, ontologies);
      return ResourcesPlugin.getWorkspace().getRoot().getProject(name);
  }
  */
  
  protected String getCurrentProject() throws Exception {
	 String[] projects = DatamodelPlugin.getDefault().getOntologyProjects();
	 //IProject[] project = ResourcesPlugin.getWorkspace().getRoot().getProjects();
     System.out.println("number of projects: "+projects.length);
     if(projects.length<1)
   	  return null;
     
     ListDialog ld = new ListDialog(null);
    //	  project, new ArrayContentProvider(), new LabelProvider(), "Worksapce java projects");
     ld.setTitle("Select Project");
     ld.setMessage("projects in Schema");
     
     ld.setContentProvider( new ArrayContentProvider());
     ld.setLabelProvider( new  LabelProvider());
     ld.setInput( projects );
     
     String prj = null;
     if (ld.open() == ListDialog.OK) {
			Object selection[] = ld.getResult();
			prj = (String)selection[0];
     }
     
     return prj;
  }
  
  /*
  protected void dumpPredicates(int i) throws CoreException, DataModelException {
      Set s = DatamodelPlugin.getDefault().getContainer().getConnection().getConfig().getAllPredicates();
      System.out.println(i + " : " + s); //$NON-NLS-1$
  }
  */

  protected void createNewModule(String moduleId, String prjName) throws Exception {
	  ProcedureCallLogger.log(
   			getClass().getName(), 
				"createNewModule",  //$NON-NLS-1$
				new Class[]{String.class},
				new Object[]{moduleId});
   	
      IOntologyContainer container = DatamodelPlugin.getDefault().getContainer(prjName);
   	try {
	        Term ontoTerm = container.createTerm(moduleId);
	        container.transactionBegin();
	        container.addStatement(new InstanceProperty(ontoTerm,
	                container.createTerm("\"description\""), //$NON-NLS-1$
	                container.createTerm("\"newDescription\""), //$NON-NLS-1$
	                ontoTerm));
	        
	        container.transactionCommit();
   	} catch (Exception e) {
   		try {
				container.transactionAbort();
			} catch (KAON2Exception e1) {
				GuiPlugin.logError(e1);
			}
   		throw new InternalOntoStudioException(e);
   	}
  }

}

package org.neon.toolkit.text2onto.gui.table;



import java.util.List;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.CheckboxCellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;
import org.neon.toolkit.text2onto.gui.POMView;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMContentProvider;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMLabelProvider;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;

public class TableConcepts extends AbstractTable {
	private String[] sColumns = { "Label", "Relevance" };

	public TableConcepts(Composite parent, int style) {
		m_table = createTable(parent, sColumns);
		//m_tableViewer = createTableViewer(m_table);
		this.createTableViewer(m_table);
	}

	private TableViewer createTableViewer(Table table) {
		
		//TableViewer tableViewer = new TableViewer(table);
		m_tableViewer.setUseHashlookup(true);
		m_ContentProvider = new POMConceptContentProvider();
		m_tableViewer.setContentProvider(m_ContentProvider);
		m_tableViewer.setLabelProvider(new POMConceptLabelProvider());
		//tableViewer.setLabelProvider(new LabelProvider());
		
		m_tableViewer.setColumnProperties(sColumns);
	
		
		// Create the cell editors
		CellEditor[] editors = new CellEditor[sColumns.length];

		// Column 1 : Completed (Checkbox)
		editors[0] = new CheckboxCellEditor(table, SWT.CHECK);
		//((CheckboxCellEditor)editors[0]).getControl().
		//((CheckboxCellEditor)editors[0]).setValue( true );
		
		// Column 2 : Label (Free text)
		TextCellEditor textEditor = new TextCellEditor(table);
		((Text) textEditor.getControl()).setTextLimit(60);
		editors[1] = textEditor;

		// Column 2 : Label (Free text)
		//textEditor = new TextCellEditor(table);
		//((Text) textEditor.getControl()).setTextLimit(60);
		//editors[2] = textEditor;

		// Assign the cell editors to the viewer
		m_tableViewer.setCellEditors(editors);
		
		return m_tableViewer;
	}
	
	
	public class POMConceptLabelProvider extends AbstractPOMLabelProvider {
		public String getColumnText(Object element, int columnIndex) {
			String result = "";
			POMConcept concept = (POMConcept) element;
			switch (columnIndex) {
			//case 0: // COMPLETED_COLUMN
			//	break;
			case 0:
				result = concept.getLabel();
				break;
			case 1:
				//if(concept.getLabel().equals("people"))
				//	System.out.println(concept.getProbability());
				result = new Double(concept.getProbability()).toString();
				break;
			default:
				break;
			}
			return result;
		}
	}

	public class POMConceptContentProvider extends AbstractPOMContentProvider {

		public Object[] getElements(Object inputElement) {
			List objList = getObjects(POMView.CONCEPT);
			int pos = 0;
			for(Object obj:objList) {
				string2POMObjectMap.put( ((POMConcept)obj).toString(), ((POMConcept)obj));
				indexList.add(((POMConcept)obj).toString() );
				
				pos++;
			}
			return objList.toArray();
		}
		
	}
}

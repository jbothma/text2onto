package org.neon.toolkit.text2onto.gui.preferences;


import java.io.File;
import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.DirectoryFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.gui.common.RadioGroupFieldEditor;
import org.ontoware.text2onto.util.Settings;

public class PreferencePage extends FieldEditorPreferencePage implements
		IWorkbenchPreferencePage {
	
	public static final String ID = "org.neon.toolkit.text2onto.gui.preferencePage";
	public static final String sALGORITHMS = Settings.ALGORITHMS_XML;

	public static final String sGATE_DIR = Settings.GATE_DIR;
	
	public static final String sTEXT2ONTO_DIR = "text2onto_dir";
	
	public static final String sGATE_APP = Settings.GATE_APP;

	public static final String sJWNL_PROPERTIES = Settings.JWNL_PROPERTIES;

	public static final String sLANGUAGE = Settings.LANGUAGE;
	
	public static final String sNORMALISATION = "normalisation";

	public static final String sPATH = Settings.TEMP_CORPUS;
	
	public static final String sJAPE_MAIN = Settings.JAPE_MAIN;
	
	public static final String sSTOP_FILE = Settings.STOP_FILE;
	
	public static final String sDATASTORE = Settings.DATASTORE;
	
	public static final String sSPANISH_TAGGER_DIR = Settings.TAGGER_DIR;
	
	public static final String sSPANISH_WORDNET_DIR = Settings.SPANISH_WORD_NET_DIR;
	
	public static final String sCREOLE_DIR = Settings.CREOLE_DIR;
	
	public static final String sICONS = Settings.ICONS;
	
	private static final String sGATEHOME_DIR = "gatehome_dir";
	
	// Preference values
	private static final String sGate_dir = "/lib/gate/";
	
	private static final String sGate_app = "application.gate";
	
	private static final String sJape_main = "main.jape";
	
	private static final String sStop_file = "stopwords.txt";
	
	private static final String sCreole_dir = "/lib/gate/";
	
	private static final String sJwnl_properties = "/lib/jwnl/file_properties.xml";
	
	private static final String sIcons = "/icons/";
	
	private static final String sDatastore = "serial";
	

	public static boolean getBooleanPref(String sKey) {
		return Activator.getDefault().getPreferenceStore().getBoolean(
				sKey);
	}

	public static String getStringPref(String sKey) {
		String sTemp = Activator.getDefault().getPreferenceStore()
				.getString(sKey);
		sTemp = sTemp.replace('\\', '/');
		return sTemp;
	}

	//private DirectoryFieldEditor directoryEditor;

	//private BooleanFieldEditor disableGraphicalViewEditor;

	private DirectoryFieldEditor text2ontoEditor;
	
	private DirectoryFieldEditor gatehomeEditor;

	private DirectoryFieldEditor spanishTaggerEditor;

	private RadioGroupFieldEditor languageEditor;
	
	private BooleanFieldEditor normalisationEditor;
	
	private DirectoryFieldEditor spanishWordnetEditor;

	public PreferencePage() {
		super(GRID);
		setPreferenceStore(Activator.getDefault().getPreferenceStore());
		setDescription("Here you can set some presets for text2onto.");
	}

	/**
	 * Creates the field editors. Field editors are abstractions of the common
	 * GUI blocks needed to manipulate various types of preferences. Each field
	 * editor knows how to save and restore itself.
	 */

	public void createFieldEditors() {
		addField(languageEditor = new RadioGroupFieldEditor(sLANGUAGE,
				"select the language: ", 1, new String[][] {
						{ "english", "english" }, { "german", "german" }, { "spanish", "spanish" } },
				getFieldEditorParent()));
		addField(normalisationEditor = new BooleanFieldEditor(sNORMALISATION,
				"normalization of confidence values: ", getFieldEditorParent()));
		//addField(directoryEditor = new DirectoryFieldEditor(sPATH,
		//		"&default corpus:", getFieldEditorParent()));
		
		addField(gatehomeEditor = new DirectoryFieldEditor(sGATEHOME_DIR,
				"&gate home directory:", getFieldEditorParent()));
		
		//addField(text2ontoEditor = new DirectoryFieldEditor(sTEXT2ONTO_DIR,
		//		"&text2onto directory:", getFieldEditorParent()));

		addField(spanishTaggerEditor = new DirectoryFieldEditor(sSPANISH_TAGGER_DIR,
				"spanish &tagger directory:", getFieldEditorParent()));
		addField(spanishWordnetEditor = new DirectoryFieldEditor(sSPANISH_WORDNET_DIR,
				"spanish &wordnet directory:", getFieldEditorParent()));
		
	}

	public void init(IWorkbench workbench) {
		
	}

	/*public static Properties getSettingProperties() {
		Properties properties = null;
		IPreferenceStore store = Activator.getDefault().getPreferenceStore();
		return properties;
	}*/
	
	public boolean performOk() {
		languageEditor.store();
		normalisationEditor.store();
		//saveChangesEditor.store();
		
		String sText2onto_dir_value = getPluginPath();
		
		System.out.println(sText2onto_dir_value);
		if(sText2onto_dir_value.length()==0) 
			return false;
		//String sText2onto_dir_value = text2ontoEditor.getStringValue().replace('\\', '/');
		
		String sGatehome_dir_value = gatehomeEditor.getStringValue().replace('\\', '/');
		
		//String sTemp_Corpus_dir_value = directoryEditor.getStringValue().replace('\\', '/');
		
		String sSpanish_Wordnet_dir_value = spanishWordnetEditor.getStringValue().replace('\\', '/');
		
		String sSpanish_Tagger_dir_value = spanishTaggerEditor.getStringValue().replace('\\', '/');
		
		//Setting in Preference page
		//Activator.getDefault().getPreferenceStore().setValue(sPATH,
		//		sTemp_Corpus_dir_value);
		
		Activator.getDefault().getPreferenceStore().setValue(
				sLANGUAGE, languageEditor.getCurrentValue());
		
		Activator.getDefault().getPreferenceStore().setValue(
				sGATEHOME_DIR, sGatehome_dir_value);
		
		Activator.getDefault().getPreferenceStore().setValue(
				sTEXT2ONTO_DIR, sText2onto_dir_value);
		
		Activator.getDefault().getPreferenceStore().setValue(
				sSPANISH_TAGGER_DIR, sSpanish_Tagger_dir_value);
		
		Activator.getDefault().getPreferenceStore().setValue(
				sSPANISH_WORDNET_DIR, sSpanish_Wordnet_dir_value);
		
		//Setting in background
		Activator.getDefault().getPreferenceStore().setValue(
				sGATE_DIR, sText2onto_dir_value + sGate_dir );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sGATE_APP, sGate_app );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sJWNL_PROPERTIES, sText2onto_dir_value + sJwnl_properties);
		
		Activator.getDefault().getPreferenceStore().setValue(
				sJAPE_MAIN, sJape_main );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sSTOP_FILE, sStop_file );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sCREOLE_DIR, sText2onto_dir_value + sCreole_dir );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sICONS, sText2onto_dir_value + sIcons );
		
		Activator.getDefault().getPreferenceStore().setValue(
				sDATASTORE, sDatastore );
		
		Activator.getDefault().savePluginPreferences();

		//Settings.set(Settings.TEMP_CORPUS, sTemp_Corpus_dir_value);
		Settings.set(Settings.LANGUAGE, languageEditor.getCurrentValue());
		Settings.set(Settings.GATE_DIR, sText2onto_dir_value + sGate_dir);
		Settings.set(Settings.GATE_APP, sGate_app);
		Settings.set(Settings.JWNL_PROPERTIES, sText2onto_dir_value + sJwnl_properties);
		Settings.set(Settings.CREOLE_DIR, sText2onto_dir_value + sCreole_dir);
		Settings.set(Settings.DATASTORE, sDatastore);
		Settings.set(Settings.ICONS, sText2onto_dir_value + sIcons);
		Settings.set(Settings.JAPE_MAIN, sJape_main);
		Settings.set(Settings.STOP_FILE, sStop_file);
		Settings.set(Settings.SPANISH_WORD_NET_DIR, sSpanish_Wordnet_dir_value);
		Settings.set(Settings.TAGGER_DIR, sSpanish_Tagger_dir_value);
		
		System.out.println("Language:"+languageEditor.getCurrentValue());
		/////////
		//System.clearProperty("gate.home");
		//System.clearProperty("gate.config");
		//System.clearProperty("gate.plugins.home");
		//System.clearProperty("load.plugin.path");
		//System.clearProperty("file.encoding");
		
		
		
		File gatefile = new File(sGatehome_dir_value + "/gate.xml");
		
		if(!gatefile.exists()) {
			MessageDialog.openInformation(
	  				new Shell(),
	  				"Text2Onto Preference",
	  				"Can not find gate.xml in the given Gate path, please config the Gate path again.");
			return false;
		}else {
			System.setProperty( "gate.home", sGatehome_dir_value );
			System.setProperty( "gate.config", sGatehome_dir_value + "/gate.xml" );
			System.setProperty( "gate.plugins.home", sGatehome_dir_value + "/plugins" );
			System.setProperty( "load.plugin.path", "file:/" + sGatehome_dir_value + "/plugins/ANNIE" );
			System.setProperty( "file.encoding", "ISO-8859-1" );
		}
		
		return true;
	}
	
	private String getPluginPath() {
		URL url = FileLocator.find(Activator.getDefault().getBundle(), new Path("/"), null);
				
		String sPluginPath = "";
		try {
			System.out.println("URL=" + FileLocator.toFileURL(url).getPath());
			
			sPluginPath=FileLocator.toFileURL(url).getPath();
			if(sPluginPath.startsWith( "/" )) {
				sPluginPath = sPluginPath.substring( 1 );
			}
			if(sPluginPath.endsWith( "/" )) {
				sPluginPath = sPluginPath.substring( 0, sPluginPath.length()-1 );
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return sPluginPath;
	}
}
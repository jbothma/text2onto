package org.neon.toolkit.text2onto.gui.provider;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.neon.toolkit.text2onto.gui.POMView;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMDisjointClasses;
import org.ontoware.text2onto.pom.POMInstance;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSimilarityRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;
import org.ontoware.text2onto.util.ProbabilityComparator;

public class AbstractPOMContentProvider implements IStructuredContentProvider {

	protected POM m_pom;
	
	//protected List listObjects = new ArrayList();

	public Object[] getElements(Object inputElement) {
		// TODO Auto-generated method stub
		
		return null;
	}

	public void dispose() {
		// TODO Auto-generated method stub

	}

	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		m_pom = (POM) newInput;

	}

	public List getObjects(int iType) {
		List objects = new ArrayList();//null;
		switch (iType) {
		case POMView.CONCEPT:
			objects = m_pom.getObjects(POMConcept.class);
			break;
		case POMView.INSTANCE:
			objects = m_pom.getObjects(POMInstance.class);
			break;
		case POMView.SUBCLASSOF:
			objects = m_pom.getObjects(POMSubclassOfRelation.class);
			break;
		case POMView.INSTANCEOF:
			objects = m_pom.getObjects(POMInstanceOfRelation.class);
			break;
		case POMView.RELATION:
			objects = m_pom.getObjects(POMRelation.class);
			break;
		case POMView.SIMILARITY:
			objects = m_pom.getObjects(POMSimilarityRelation.class);
			break;
		case POMView.DISJOINT:
			objects = m_pom.getObjects(POMDisjointClasses.class);
			break;
		}
		if (objects != null) {
			Collections.sort(objects, new ProbabilityComparator());
		}
		return objects;
	}
}

package org.neon.toolkit.text2onto;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.SWT;


import org.neon.toolkit.text2onto.gui.CorpusView;
import org.neon.toolkit.text2onto.gui.common.*;



public class CorpusProvider implements IStructuredContentProvider,
											ITreeContentProvider {

	private TreeParent invisibleRoot;
	private TreeParent root;

	private CorpusView parent; 
	private IViewSite site; 
	private List fElements = new ArrayList();
	
	private TreeViewer fTreeViewer;

	public void addNewObjects(Object[] o) {
		List lNewObjects = new ArrayList();
		for (int i = 0; i < o.length; i++) {
			if (!(fElements.contains(o[i]))) {
				lNewObjects.add(o[i]);
				System.out.println();
				TreeObject to1 = new TreeObject(o[i].toString());
				root.addChild( to1 );
			}
		}
		
		fElements.addAll(lNewObjects);
		fTreeViewer.expandAll();

	}
	
	public void remove(Object o) {
		fElements.remove(o);
		fTreeViewer.remove(o);
	}

	public void remove(Object[] objs) {
		for (int i = 0; i < objs.length; i++) {
			fElements.remove(objs[i].toString());
			//fTreeViewer.remove(objs[i]);
			root.removeChild( (TreeObject)objs[i] ); 
		}
	}

	public void removeAll() {
		//fTreeViewer.remove(fElements.toArray());
		root.clearChildren();
		fElements.clear();
	}
	
	public CorpusProvider( CorpusView parent, IViewSite site ) {
		// Corpus corpus = CorpusFactory.newCorpus();
		this.parent = parent; 
		this.site = site; 
		initialize(); 
	}
	
	public void inputChanged( Viewer viewer, Object oldInput, Object newInput ) {
		// TODO Auto-generated method stub
		fTreeViewer = (TreeViewer) viewer;
		
	}

	public Object[] getChildren( Object parentElement ) {
		if (parentElement instanceof TreeParent) {
			return ((TreeParent)parentElement).getChildren();
		}
		return new Object[0];
	}

	public Object getParent( Object element ) {
		if (element instanceof TreeObject) {
			return ((TreeObject)element).getParent();
		}
		return null;
	}

	public boolean hasChildren( Object element ) {
		if (element instanceof TreeParent)
			return ((TreeParent)element).hasChildren();
		return false;
	}

	public Object[] getElements( Object inputElement ) {
		if (inputElement.equals(site)) {
			if (invisibleRoot==null) initialize();
			return getChildren(invisibleRoot);
		}
		return getChildren(inputElement);
	}

	public void dispose() {
		// TODO Auto-generated method stub
	}
	
	private void initialize() {
		//TreeObject to1 = new TreeObject("Leaf 1");
		//TreeObject to2 = new TreeObject("Leaf 2");
		//TreeObject to3 = new TreeObject("Leaf 3");
		//TreeParent p1 = new TreeParent("Parent 1");
		//p1.addChild(to1);
		//p1.addChild(to2);
		//p1.addChild(to3);
		
		//TreeObject to4 = new TreeObject("Leaf 4");
		//TreeParent p2 = new TreeParent("Parent 2");
		//p2.addChild(to4);
		
		root = new TreeParent("Corpus");
		//root.addChild(to1);
		//root.addChild(p2);
		
		invisibleRoot = new TreeParent("");
		invisibleRoot.addChild(root);
		
	}
}

package org.neon.toolkit.text2onto.gui.table;

import java.util.List;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.CheckboxCellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;
import org.neon.toolkit.text2onto.gui.POMView;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMContentProvider;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMLabelProvider;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMInstance;

public class TableInstances extends AbstractTable {
	private String[] sColumns = { "Label", "Relevance" };

	public TableInstances(Composite parent, int style) {
		m_table = createTable(parent, sColumns);
		this.createTableViewer(m_table);
		// TODO Auto-generated constructor stub
	}

	private TableViewer createTableViewer(Table table) {

		//TableViewer tableViewer = new TableViewer(table);
		m_tableViewer.setUseHashlookup(true);
		m_tableViewer.setContentProvider(new POMInstanceContentProvider());
		m_tableViewer.setLabelProvider(new POMInstanceLabelProvider());

		m_tableViewer.setColumnProperties(sColumns);

		// Create the cell editors
		CellEditor[] editors = new CellEditor[sColumns.length];
		// Column 1 : Completed (Checkbox)
		editors[0] = new CheckboxCellEditor(table);

		// Column 2 : Label (Free text)
		TextCellEditor textEditor = new TextCellEditor(table);
		((Text) textEditor.getControl()).setTextLimit(60);
		editors[1] = textEditor;

		// Assign the cell editors to the viewer
		m_tableViewer.setCellEditors(editors);
		return m_tableViewer;
	}

	public class POMInstanceLabelProvider extends AbstractPOMLabelProvider {
		public String getColumnText(Object element, int columnIndex) {
			String result = "";
			POMInstance instance = (POMInstance) element;
			switch (columnIndex) {
			case 0: // COMPLETED_COLUMN
				result = instance.getLabel();
				break;
			case 1:
				result = new Double(instance.getProbability()).toString();
				break;
			default:
				break;
			}
			return result;
		}
	}

	public class POMInstanceContentProvider extends AbstractPOMContentProvider {

		public Object[] getElements(Object inputElement) {
			List objList = getObjects(POMView.INSTANCE);
			int pos = 0;
			for(Object obj:objList) {
				string2POMObjectMap.put( ((POMInstance)obj).toString(), ((POMInstance)obj));
				indexList.add(((POMInstance)obj).toString() );
				
				pos++;
			}
			return objList.toArray();
		}
	}

}
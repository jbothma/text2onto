package org.neon.toolkit.text2onto;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.IViewSite;
import org.neon.toolkit.text2onto.gui.CorpusView;
import org.neon.toolkit.text2onto.gui.WorkflowView;
import org.neon.toolkit.text2onto.gui.common.TreeObject;
import org.neon.toolkit.text2onto.gui.common.TreeParent;


public class WorkflowProvider implements ITreeContentProvider {

	private TreeParent invisibleRoot;
	private TreeParent root;

	private WorkflowView parent; 
	private IViewSite site; 
	
	private TreeViewer fTreeViewer;
	
	
	public WorkflowProvider( WorkflowView parent, IViewSite site ) {
		// Corpus corpus = CorpusFactory.newCorpus();
		this.parent = parent; 
		this.site = site; 
		initialize(); 
		
		//fTreeViewer.expandAll();
		
	}
	
	public void inputChanged( Viewer viewer, Object oldInput, Object newInput ) {
		// TODO Auto-generated method stub
		//fTreeViewer = (TreeViewer) parent.getViewSite();
	}

	public Object[] getChildren( Object parentElement ) {
		if (parentElement instanceof TreeParent) {
			return ((TreeParent)parentElement).getChildren();
		}
		return new Object[0];
	}

	public Object getParent( Object element ) {
		if (element instanceof TreeObject) {
			return ((TreeObject)element).getParent();
		}
		return null;
	}

	public boolean hasChildren( Object element ) {
		if (element instanceof TreeParent)
			return ((TreeParent)element).hasChildren();
		return false;
	}

	public Object[] getElements( Object inputElement ) {
		if (inputElement.equals(site)) {
			if (invisibleRoot==null) initialize();
			return getChildren(invisibleRoot);
		}
		return getChildren(inputElement);
	}

	public void dispose() {
		// TODO Auto-generated method stub
	}
	
	public TreeObject getTreeRoot() {
		return root;
	}
	
	/*public void addNewObjects(Object[] o) {
		List lNewObjects = new ArrayList();
		for (int i = 0; i < o.length; i++) {
			if (!(fElements.contains(o[i]))) {
				lNewObjects.add(o[i]);
				System.out.println();
				TreeObject to1 = new TreeObject(o[i].toString());
				root.addChild( to1 );
			}
		}
		fElements.addAll(lNewObjects);
		fTreeViewer.expandAll();

	}*/
	
	public void addNewObjects(TreeParent parent, Object[] o) {
		List lNewObjects = new ArrayList();
		for (int i = 0; i < o.length; i++) {
			//if (!(fElements.contains(o[i]))) {
				lNewObjects.add(o[i]);
				//System.out.println();
				TreeObject to1 = new TreeObject(o[i].toString());
				parent.addChild( to1 );
			//}
		}
		//fElements.addAll(lNewObjects);
		fTreeViewer.expandAll();
	}
	
	private void initialize() {

		
		root = new TreeParent("Algorithm");
		
		
		invisibleRoot = new TreeParent("");
		invisibleRoot.addChild(root);
	}		
}

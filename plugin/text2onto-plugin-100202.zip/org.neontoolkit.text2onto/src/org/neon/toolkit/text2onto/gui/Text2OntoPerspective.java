package org.neon.toolkit.text2onto.gui;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.internal.FolderLayout;

import com.ontoprise.ontostudio.gui.navigator.MTreeView;
import com.ontoprise.ontostudio.gui.properties.EntityPropertiesView;

public class Text2OntoPerspective implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {

		IFolderLayout right = layout.createFolder("right", IPageLayout.RIGHT,
				1.0f, layout.getEditorArea());
		right.addView("org.neon.toolkit.text2onto.POMView");
		// right.addView( "org.neon.toolkit.text2onto.DocView" );

		layout.addView("org.neon.toolkit.text2onto.WorkflowView",
				IPageLayout.LEFT, 0.25f, "org.neon.toolkit.text2onto.POMView");
		
		layout.addView("org.neon.toolkit.text2onto.CorpusView",
				IPageLayout.BOTTOM, 0.5f,
				"org.neon.toolkit.text2onto.WorkflowView");

		layout.setEditorAreaVisible(false);

	}

}

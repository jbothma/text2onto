package org.neon.toolkit.text2onto.gui.common;

import java.util.ArrayList;

import org.eclipse.core.runtime.IAdaptable; 
import org.eclipse.ui.ISharedImages; 
 
 public class TreeObject implements IAdaptable { 
         private String name; 
         private TreeParent parent; 
         private String imageKey; 
         private String insertName; 
         private ArrayList children; 
          
         public TreeObject(String name) { 
                 this.name = name; 
                 imageKey = ISharedImages.IMG_OBJ_ELEMENT; 
         } 
         public String getName() { 
                 return name; 
         } 
         //public void addChild(TreeObject child) { 
         //   children.add(child); 
         //   child.setParent(this); 
         //} 
         public void setParent(TreeParent parent) { 
                 this.parent = parent; 
         } 
         public TreeParent getParent() { 
                 return parent; 
         } 
         public String toString() { 
                 return getName(); 
         } 
         public Object getAdapter(Class key) { 
                 return null; 
         } 
          
         public void setImageKey(String key) { 
                 imageKey = key; 
         } 
          
         public String getImageKey(){ 
                 return imageKey; 
         } 
          
         public void setName(String value) 
         { 
                 this.name = value; 
         } 
          
         public String getInsertName() 
         { 
                 if (insertName == null) 
                         return name; 
                 else return insertName; 
         } 
          
         public void setInsertName(String insertName) 
         { 
                 this.insertName = insertName; 
         } 
} 

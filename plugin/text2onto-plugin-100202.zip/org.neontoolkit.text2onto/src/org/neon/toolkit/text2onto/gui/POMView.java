package org.neon.toolkit.text2onto.gui;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.part.ViewPart;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.ImageFactory;
import org.neon.toolkit.text2onto.gui.actions.ActionListener;
import org.neon.toolkit.text2onto.gui.table.AbstractTable;
import org.neon.toolkit.text2onto.gui.table.TableConcepts;
import org.neon.toolkit.text2onto.gui.table.TableDisjoint;
import org.neon.toolkit.text2onto.gui.table.TableInstanceOf;
import org.neon.toolkit.text2onto.gui.table.TableInstances;
import org.neon.toolkit.text2onto.gui.table.TableRelations;
import org.neon.toolkit.text2onto.gui.table.TableSimilarity;
import org.neon.toolkit.text2onto.gui.table.TableSubclassOf;
import org.ontoware.text2onto.algorithm.ProgressListener;
import org.ontoware.text2onto.change.Change;
import org.ontoware.text2onto.change.ChangeRequest;
import org.ontoware.text2onto.change.POMChange;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMDisjointClasses;
import org.ontoware.text2onto.pom.POMFactory;
import org.ontoware.text2onto.pom.POMInstance;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSimilarityRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;
import org.ontoware.text2onto.pom.POMWrapper;
import org.ontoware.text2onto.util.ProbabilityComparator;

public class POMView extends ViewPart implements ProgressListener {

	private CTabFolder m_tabFolder;
	
	private CTabItem[] m_tabItem;
	
	private final String m_sTitle[] = { "Concept", "Instance", "Similarity",
			"SubclassOf", "InstanceOf", "Relation", "Disjoint"};
	
	public final static int CONCEPT = 0;		
	public final static int INSTANCE = 1;
	public final static int SIMILARITY = 2;
	public final static int SUBCLASSOF = 3;
	public final static int INSTANCEOF = 4;
	public final static int RELATION = 5;
	public final static int DISJOINT  = 6;
	
	
	private int m_iTabItems = m_sTitle.length;
	
	private Table m_table;
	private Button[] m_buttons;
	
	private POM m_pom;

	private AbstractTable[] m_tables;
	
	ProgressBar m_progressbar;
	
	CLabel m_ProgressText;
	
	private int m_step;
	
	private String m_sAlgorithm;
	
	protected Image processImage;
	
	private Action NewAction;
	private Action RunAction;
	private Action Export2OWLAction;
	private Action Export2FlogicAction;
	private Action ExportAction;
	private Action AboutAction;
	

	
	public POMView() {
		// TODO
	}

	public ProgressBar getProgressBar() {
		return m_progressbar;
	}
	
	public CLabel getProgressText() {
		return m_ProgressText;
	}
	
   public void progressChanged( String sAlgorithm, int step, int steps ) {
   	//m_progressbar.setVisible( true );
   	m_step = step;
   	m_sAlgorithm = sAlgorithm;
   	Display.getDefault().asyncExec( new Runnable() {
		  	public void run() {
			// TODO Auto-generated method stub
		  		//m_progressbar.setSelection( m_step );
		  		m_ProgressText.setText( "Excuting " +m_step + " of 7 algorithm : " + m_sAlgorithm );
		  		IStatusLineManager statusline = getViewSite().getActionBars().getStatusLineManager();
		   	statusline.setMessage( m_sAlgorithm );
		   	statusline.getProgressMonitor().worked( m_step );
		   	statusline.getProgressMonitor().subTask( m_sAlgorithm );
		  	
		  	}
	   });
   
		System.out.println( sAlgorithm + "-" + step + "-" + steps);
	}
	
	@Override
	public void createPartControl( Composite parent ) {
		
		m_tabItem = new CTabItem[m_iTabItems];
		Composite c = new Composite( parent, SWT.NONE);
		c.setLayout( new GridLayout() );
		
		m_tabFolder = new CTabFolder( c, SWT.BORDER );
		
		GridData gridData = new GridData( GridData.FILL_BOTH);
		gridData.grabExcessHorizontalSpace = true;
		gridData.grabExcessVerticalSpace = true;
		m_tabFolder.setLayoutData( gridData );
		m_tabFolder.setSimple( false );
		m_tables = new AbstractTable[m_iTabItems];
	   
		m_buttons = new Button[m_iTabItems];
		for( int i=0; i<m_iTabItems; i++ ) 
		{
			Composite page = new Composite( m_tabFolder, SWT.FILL);
		  
			m_tabItem[i] = new CTabItem( m_tabFolder, SWT.FILL );
			m_tabItem[i].setText( m_sTitle[i] );
			GridLayout layout = new GridLayout();
			page.setLayout(layout);
			m_tabItem[i].setControl( page );
			m_tables[i] = createTable(page, i);
		}	
		
		m_tabFolder.setSelection( 0 );
		
		
		//processImage = new Image(this.getViewSite().getShell().getDisplay(), "c:/05.gif");
		Composite compositePB = new Composite( c, SWT.NONE );
		compositePB.setLayout( new GridLayout() );
		compositePB.setLayoutData( new GridData(GridData.FILL_HORIZONTAL|GridData.GRAB_HORIZONTAL) );
		
		//m_progressbar = new ProgressBar( compositePB, SWT.HORIZONTAL|SWT.INDETERMINATE);
		//m_progressbar.setLayoutData( new GridData(GridData.HORIZONTAL_ALIGN_END) );
		
		m_ProgressText = new CLabel(compositePB, SWT.HORIZONTAL|SWT.SHADOW_NONE);
		m_ProgressText.setLayoutData( new GridData(GridData.FILL_HORIZONTAL) );
		//m_ProgressText.setImage( processImage );
		//m_ProgressText.setVisible( false );
		
		makeActions();
		contributeToActionBars();
		
	}

	protected AbstractTable createTable(Composite page, int i) {
		AbstractTable table = null;
		switch (i) {
		case CONCEPT:
			table = new TableConcepts(page, SWT.FILL);
			break;
		case INSTANCE:
			table = new TableInstances(page, SWT.DEFAULT);
			break;
		case SIMILARITY:
			table = new TableSimilarity(page, SWT.DEFAULT);
			break;
		case SUBCLASSOF:
			table = new TableSubclassOf(page, SWT.DEFAULT);
			break;
		case INSTANCEOF:
			table = new TableInstanceOf(page, SWT.DEFAULT);
			break;
		case RELATION:
			table = new TableRelations(page, SWT.DEFAULT);
			break;
		case DISJOINT:
			table = new TableDisjoint(page, SWT.DEFAULT);
			break;
	
		}
		return table;
	}
	
	public void update(POM pom){
		m_pom = pom;

		for( int i=0; i<m_tables.length; i++ )
		{
			TableViewer v = m_tables[i].getTableViewer();
			v.setInput(m_pom);
			//if( i>0 )
			for(int j=0; j<v.getTable().getItemCount(); j++) {
				v.getTable().getItem( j ).setChecked( true );
			}
		}
		
	}
	
	public void doReset(){
		for( int i=0; i<m_tables.length; i++ )
		{
			TableViewer v = m_tables[i].getTableViewer();
			v.getTable().removeAll();
		}
	}
	
	
	private List getObjects( int iType ){ 
		List objects = null;
		switch( iType ){
			case CONCEPT: 
				objects = m_pom.getObjects( POMConcept.class );
				break;
			case INSTANCE: 
				objects = m_pom.getObjects( POMInstance.class ); 
				break;
			case SUBCLASSOF: 
				objects = m_pom.getObjects( POMSubclassOfRelation.class ); 
				break;
			case INSTANCEOF: 
				objects = m_pom.getObjects( POMInstanceOfRelation.class ); 
				break;
			case RELATION: 
				objects = m_pom.getObjects( POMRelation.class ); 
				break;
			case SIMILARITY: 
				objects = m_pom.getObjects( POMSimilarityRelation.class ); 
				break;
			case DISJOINT: 
				objects = m_pom.getObjects( POMDisjointClasses.class ); 
				break;
		}
		if( objects != null ){
			Collections.sort( objects, new ProbabilityComparator() );
		}
		return objects;
	}
	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
	}
	
	public POM getFilteredPOM() {
		POMWrapper fpom = new POMWrapper( POMFactory.newPOM() );
		for(int i=0; i<m_iTabItems; i++) {
			addFilteredPOMObjects(i, fpom);
		}
		
	   return fpom.getChangeable();
	}
	
	private void addFilteredPOMObjects(int iTab, POMWrapper pomWrapper) {
		List objects = m_tables[iTab].getFilteredObjects();
		
		Iterator iter = objects.iterator();
		while( iter.hasNext() )
		{
	            POMObject object = (POMObject)iter.next();
	            
	            ChangeRequest changeRequest =
	                    new ChangeRequest( new  POMChange(Change.Type.ADD, this, object, object.getProbability(), new ArrayList() ) );
	            pomWrapper.processChangeRequest( changeRequest );
		}
	}
	
	private void makeActions() {
		NewAction = new Action() {
			public void run() {
				Text2Onto t2o = Activator.getDefault().getT20();
				t2o.buttonPressed(ActionListener.NEW);
			}
		};
		NewAction.setText("New");
		NewAction.setToolTipText("Initialize...");
		NewAction.setImageDescriptor(ImageFactory.NEW);
		
		//---------------------------------------------------
		RunAction = new Action() {
			public void run() {
				Text2Onto t2o = Activator.getDefault().getT20();
				t2o.buttonPressed(ActionListener.RUN);
			}
		};
		RunAction.setText("Run");
		RunAction.setToolTipText("Run algorithms...");
		RunAction.setImageDescriptor(ImageFactory.RUN);
		
		//--------------------------------------------------
		Export2OWLAction = new Action() {
			public void run() {
				//showMessage("Action 1 executed");
				Text2Onto t2o = Activator.getDefault().getT20();
				t2o.buttonPressed(ActionListener.TOOWL);
			}
		};
		Export2OWLAction.setText("Export to OWL");
		Export2OWLAction.setToolTipText("Export to OWL...");
		Export2OWLAction.setImageDescriptor(ImageFactory.EXPORT2OWL);
		
		//--------------------------------------------------
		
		Export2FlogicAction = new Action() {
			public void run() {
				Text2Onto t2o = Activator.getDefault().getT20();
				t2o.buttonPressed(ActionListener.TOFLOGIC);
			}
		};
		Export2FlogicAction.setText("Export to Flogic");
		Export2FlogicAction.setToolTipText("Export to Flogic...");
		Export2FlogicAction.setImageDescriptor(ImageFactory.EXPORT2FLOGIC);
		
		//--------------------------------------------------
		ExportAction = new Action() {
			public void run() {
				Text2Onto t2o = Activator.getDefault().getT20();
				t2o.buttonPressed(ActionListener.EXPORT);
			}
		};
		ExportAction.setText("Export");
		ExportAction.setToolTipText("Export to file...");
		ExportAction.setImageDescriptor(ImageFactory.EXPORT);
		
		//--------------------------------------------------
		AboutAction = new Action() {
			public void run() {
				MessageDialog.openInformation(
						null,
						"Text2Onto Plug-in",
						"Text2Onto Plug-in\n\n" +
						"Version: 1.0b\n\n" +
						"Johanna Voelker and Hua Gao\n\n" +
						"Institute AIFB, University of Karlsruhe\n\n" +
						"http://ontoware.org/projects/text2onto/\n"
				);
			}
		};
		AboutAction.setText("About");
		AboutAction.setToolTipText("About Text2Onto...");
		AboutAction.setImageDescriptor(ImageFactory.ABOUT);
		
		
		//ExportAction.setImageDescriptor();
		/*
		ExportAction = new Action() {
			public void run() {
				//showMessage("Export executed");
				doExport();
			}
		};
		ExportAction.setText("Export");
		ExportAction.setToolTipText("Export");
		ExportAction.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		*/
	}
	
	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		//fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		manager.add(NewAction);
		manager.add( new Separator() );
		
		manager.add(RunAction);
		manager.add( new Separator() );
		
		manager.add(Export2OWLAction);
		manager.add(Export2FlogicAction);
		manager.add(ExportAction);
		
		manager.add( new Separator() );
		manager.add(AboutAction);
		//manager.add(ExportAction);
	}
}

package org.neon.toolkit.text2onto.gui.table;

import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.TableItem;
import org.ontoware.text2onto.pom.POMObject;


public class MyCellModifier implements ICellModifier {
	private TableViewer tv;
	public MyCellModifier(TableViewer tv) {
	this.tv = tv;
	}
	
	public boolean canModify(Object element, String property) {
		return true;
	}
	
	public Object getValue(Object element, String property) {
		POMObject o = (POMObject) element;
		//if (property.equals("Label")) {
		//	return o.;
		if (property.equals("Relevance")) {
			return String.valueOf(o.getProbability());
		}
		throw new RuntimeException("Error Column : " + property);
	}
	
	public void modify(Object element, String property, Object value) {
		TableItem item = (TableItem) element;
		POMObject o = (POMObject) item.getData();
		if (property.equals("name")) {
			Integer comboIndex = (Integer) value;
			//String newName = TableViewer7.NAMES[comboIndex];
			//o.setName(newName);
		} else if (property.equals("sex")) {
			Boolean newValue = (Boolean) value;
			//o.setSex(newValue);
		} else if (property.equals("age")) {
			String newValue = (String) value;
		if (newValue.equals(""))
			return;
			int newAge = Integer.parseInt(newValue);
			//o.setAge(newAge);
		} else {
			throw new RuntimeException("error column:" + property);
		}
		tv.update(o, null);
	}
		
}

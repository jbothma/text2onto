package org.neon.toolkit.text2onto.ontology;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.eclipse.core.runtime.CoreException;
import org.neontoolkit.core.NeOnCorePlugin;
import org.neontoolkit.core.project.IOntologyProject;
import org.ontoware.text2onto.evidence.EvidenceManager;
import org.ontoware.text2onto.ontology.OntologyWriter;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMDisjointClasses;
import org.ontoware.text2onto.pom.POMInstance;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;
import org.ontoware.text2onto.reference.ReferenceManager;
import org.semanticweb.kaon2.api.Axiom;
import org.semanticweb.kaon2.api.DefaultOntologyResolver;
import org.semanticweb.kaon2.api.OntologyManager;
//import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.kaon2.api.KAON2Exception;
import org.semanticweb.kaon2.api.KAON2Factory;
import org.semanticweb.kaon2.api.KAON2Manager;
import org.semanticweb.kaon2.api.Ontology;
import org.semanticweb.kaon2.api.OntologyChangeEvent;
import org.semanticweb.kaon2.api.formatting.OntologyFileFormat;
import org.semanticweb.kaon2.api.logic.Term;
import org.semanticweb.kaon2.api.owl.axioms.ClassMember;
import org.semanticweb.kaon2.api.owl.axioms.DisjointClasses;
import org.semanticweb.kaon2.api.owl.axioms.EntityAnnotation;

import org.semanticweb.kaon2.api.owl.axioms.ObjectPropertyDomain;
import org.semanticweb.kaon2.api.owl.axioms.ObjectPropertyRange;
import org.semanticweb.kaon2.api.owl.axioms.SubClassOf;
import org.semanticweb.kaon2.api.owl.elements.Annotation;
import org.semanticweb.kaon2.api.owl.elements.AnnotationProperty;
import org.semanticweb.kaon2.api.owl.elements.Description;
import org.semanticweb.kaon2.api.owl.elements.Individual;
import org.semanticweb.kaon2.api.owl.elements.OWLClass;
import org.semanticweb.kaon2.api.owl.elements.OWLEntity;
import org.semanticweb.kaon2.api.owl.elements.ObjectProperty;

import com.ontoprise.config.IConfig;
import com.ontoprise.ontostudio.datamodel.DatamodelPlugin;
import com.ontoprise.ontostudio.datamodel.DatamodelTypes;
import com.ontoprise.ontostudio.datamodel.exception.ControlException;
import com.ontoprise.ontostudio.gui.commands.project.CreateProject;
import com.ontoprise.ontostudio.gui.navigator.module.ModuleControl;
import com.ontoprise.ontostudio.gui.navigator.project.ProjectControl;
import com.ontoprise.ontostudio.owl.model.OWLManchesterProjectFactory;

public class T2OSimpleOWLWriter implements OntologyWriter{

	
	private POM m_pom;

	private OntologyManager m_connection;

	private KAON2Factory m_factory;

	private Ontology m_ontology;
	
	
	//private final static String m_sLogicalURI = "http://www.text2onto.org/ontology";
	
	private String m_sLogicalURI = "http://www.text2onto.org";
	
	static final String m_sProjectName = "Text2OntoPrj";
	
	private static String m_sPhysicalURI;
	
	
	private HashMap m_classes = new HashMap();

	private HashMap m_individuals = new HashMap();
	
	private HashMap m_relations = new HashMap();
	
	
	private final static boolean ALL_ENTITIES = true;



	public T2OSimpleOWLWriter( POM pom ) throws KAON2Exception { 
		m_pom = pom;
	}
	
	
	public void setEvidenceManager( EvidenceManager em ){
		// TODO
	}
	
	public void setReferenceManager( ReferenceManager rm ){
		// TODO
	}
	
	private String checkForInvalidChars( String uri ){
		// returns filtered uri... 
		return uri.replaceAll( "[()\\[\\]\\^\\%\\>\\<\\&\\;]", "" );
	}
	
	void createText2ontoProject(String projectName) {
		Properties prop = new Properties();
		Boolean bHasProject = false;
		
		prop.put(IConfig.STORAGE, DatamodelTypes.getInternalName(DatamodelTypes.RAM));
		prop.put(IConfig.ONTOLOGY_LANGUAGE, IConfig.OntologyLanguage.OWL.toString());
		prop.put(IConfig.USE_INDEXER, "on");
		
		final String datamodelType = DatamodelTypes.getInternalName(DatamodelTypes.RAM);
		
		
		try {
			
			String[] projects = DatamodelPlugin.getDefault().getOntologyProjects();
			for(int i=0; i<projects.length; i++) {
				if(projectName.equalsIgnoreCase(projects[i])) {
					bHasProject = true;
				}
			}
			if(bHasProject)
				deleteText2ontoProject(projectName);
			
			new CreateProject(projectName, datamodelType, prop).run();
		}catch (CoreException e) {
            //throw new InvocationTargetException(e, e.getMessage());
			e.printStackTrace();
		} catch (ControlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	void deleteText2ontoProject(String projectName) {
		ProjectControl control = ProjectControl.getDefault();
		try  {
			control.deleteProject(projectName, true);
		}catch(Exception e) {
			control.handleException(e);
		}	
	}

public void write2Project( String sProjectName, URI physicalURI ) throws Exception {
		
		m_sPhysicalURI = physicalURI.toString();
		m_connection = DatamodelPlugin.getDefault().getContainer(sProjectName).getConnection();
//		m_connection = OWLManager.createOWLOntologyManager();
		//m_connection = KAON2Manager.newOntologyManager();
		
		DefaultOntologyResolver resolver = new DefaultOntologyResolver();
		resolver.registerReplacement( m_sLogicalURI, m_sPhysicalURI );
		m_connection.setOntologyResolver( resolver ); 
		

		Term ontoTerm = DatamodelPlugin.getDefault().getContainer(sProjectName).createTerm("text2onto");
		
		if(m_connection.getOntologyURIs().contains(m_sLogicalURI)) {
			Set<Ontology> onto_set = m_connection.getOntologies();
			Set<Ontology> delete_set = new HashSet<Ontology>();
			for(Ontology onto : onto_set) {
				if(onto.getOntologyURI().equals(m_sLogicalURI))
					delete_set.add(onto);	
			}
			
			m_connection.deleteOntologies(delete_set);
		}
		
		try {
			m_ontology = m_connection.createOntology( m_sLogicalURI, new HashMap<String,Object>() );
			ModuleControl.getDefault().addModuleToProject(ontoTerm.toString(), sProjectName);
		}			
		catch( KAON2Exception e )
		{
			System.err.println( "Could not create new ontology " + m_sLogicalURI );
			e.printStackTrace();
		}
		finally {
			//m_connection.close();
		}  
		m_factory = KAON2Manager.factory();  
		m_ontology.setDuplicateAxiomsThrowException( false );
		
		if( ALL_ENTITIES ){
			addInstances( m_pom.getObjects( POMInstance.class ) );
			addConcepts( m_pom.getObjects( POMConcept.class ) );
		}
	
//		addContextImport();
			
		addSubclassOf( m_pom.getObjects( POMSubclassOfRelation.class ) );
		addInstanceOf( m_pom.getObjects( POMInstanceOfRelation.class ) ); 
		addRelations( m_pom.getObjects( POMRelation.class ) );
		addDisjointClasses( m_pom.getObjects( POMDisjointClasses.class ) );
	} 

	public void write( URI physicalURI ) throws Exception {
		
		createText2ontoProject(m_sProjectName);
		
		m_sPhysicalURI = physicalURI.toString();
		
		Properties conn_props = DatamodelPlugin.getDefault().getConnectionProperties(m_sProjectName);
//		m_connection = KAON2Manager.newOntologyManager(conn_props);
//************		
		IOntologyProject iontoPrj = NeOnCorePlugin.getDefault().getOntologyProject(m_sProjectName);
		m_connection = iontoPrj.getAdapter(OntologyManager.class);
//**********
		DefaultOntologyResolver resolver = new DefaultOntologyResolver();
		resolver.registerReplacement( m_sLogicalURI, m_sPhysicalURI );
		m_connection.setOntologyResolver( resolver ); 
		try {
			m_ontology = m_connection.createOntology( m_sLogicalURI, new HashMap<String,Object>() );
		}			
		catch( KAON2Exception e )
		{
			System.err.println( "Could not create new ontology " + m_sLogicalURI );
			e.printStackTrace();
		}
		finally {
			m_connection.close();
		}  
		m_factory = KAON2Manager.factory();  
		m_ontology.setDuplicateAxiomsThrowException( false );
		
		if( ALL_ENTITIES ){
			addInstances( m_pom.getObjects( POMInstance.class ) );
			addConcepts( m_pom.getObjects( POMConcept.class ) );
		}
		addSubclassOf( m_pom.getObjects( POMSubclassOfRelation.class ) );
		addInstanceOf( m_pom.getObjects( POMInstanceOfRelation.class ) ); 
		addRelations( m_pom.getObjects( POMRelation.class ) );
		addDisjointClasses( m_pom.getObjects( POMDisjointClasses.class ) );

		saveRDF( new File( physicalURI ) );
		
		deleteText2ontoProject(m_sProjectName);
	} 
	
	private void addInstances( List instances ) throws KAON2Exception {
		Iterator iter = instances.iterator();
		while( iter.hasNext() )
		{ 
			POMInstance instance = (POMInstance)iter.next(); 
			createIndividual( instance );
		}
	}
	
	private void addConcepts( List concepts ) throws KAON2Exception {
		Iterator iter = concepts.iterator();
		while( iter.hasNext() )
		{ 
			POMConcept concept = (POMConcept)iter.next(); 
			
			double conf = concept.getProbability();
			createClass( concept );
		} 
	}
	
	private String checkString( String s ){
		if( s.contains( "[" ) || s.contains( "]" ) || s.contains( "%" ) 
			|| s.contains( ">" ) || s.contains( "<" ) || s.contains( "^" ) 
			|| s.contains( "&lt;" ) || s.contains( "&gt;" ) )
		{
			s = s.replace( "[", "" ); // "sq_brackets_open" );
			s = s.replace( "]", "" ); // "sq_brackets_close" );
			s = s.replace( "%", "" ); // "percent" );	
			s = s.replace( ">", "" ); // "greater_than" );	
			s = s.replace( "<", "" ); // "less_than" );
			s = s.replace( "^", "" ); // "caret" );
			s = s.replace( "&gt;", "" ); // "greater_than" );	
			s = s.replace( "&lt;", "" ); // "less_than" );
		}
		if( s.length() == 0 ){
			return null;
		}
		return s;
	}

	private OWLClass createClass( POMConcept concept ){
		
		String uri = checkForInvalidChars(concept.getLabel().replaceAll( " ", "_" ));
		// check if uri still valid or 'empty'
		if( uri.length() < 1 ){
			return null;
		}
		uri = m_sLogicalURI +"#"+ uri +"_c";
		if( m_classes.containsKey( uri ) ){
			return (OWLClass)m_classes.get( uri );
		}
		OWLClass c = m_factory.owlClass( uri );
		
		m_classes.put( uri, c );
		try {
		   SubClassOf subclassof = m_factory.subClassOf( c, m_factory.thing() );
		   EntityAnnotation conceptLabel = createAnnotation( c, concept.getLabel() );
		   EntityAnnotation conceptConf = createAnnotation( c, concept.getProbability() );

		   EntityAnnotation conceptCreator = createCreatorAnnotation( c );
		   
		   List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		   addAxiom( conceptLabel, changes );
		   addAxiom( conceptConf, changes );
		   addAxiom( conceptCreator, changes );
		   
		   if( ALL_ENTITIES ){
		   	addAxiom( subclassof, changes );
		   }
		   m_ontology.applyChanges( changes );
		}
		catch( Exception e ){ 
			e.printStackTrace(); 
		}
		return c;
	}
	
	private Individual createIndividual( POMInstance instance ){
		String uri = checkForInvalidChars( instance.getLabel().replaceAll( " ", "_" ) );
		// check if uri still valid or 'empty'
		if( uri.length() < 1 ){
			return null;
		}
		uri = m_sLogicalURI +"#"+ uri +"_i";
		if( m_individuals.containsKey( uri ) ){ 
			return (Individual)m_individuals.get( uri );
		}
		Individual i = m_factory.individual( uri );
		m_individuals.put( uri, i );
		try {
			ClassMember member = m_factory.classMember( m_factory.thing(), i );
		    EntityAnnotation instanceLabel = createAnnotation( i, instance.getLabel() );
		    EntityAnnotation instanceConf = createAnnotation( i, instance.getProbability() );
			EntityAnnotation instanceCreator = createCreatorAnnotation( i );
			   
		    
		    List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		    addAxiom( instanceLabel, changes );
		    addAxiom( instanceConf, changes );
		    addAxiom( instanceCreator, changes );
		    
			if( ALL_ENTITIES ){
				addAxiom( member, changes );
			}
		   m_ontology.applyChanges( changes );
		}
		catch( Exception e ){
			e.printStackTrace(); 
		}
		return i;
	}	
	
	private ObjectProperty createProperty( POMRelation relation ){
		String uri = checkForInvalidChars( relation.getLabel().replaceAll( " ", "_" ) );
		// check if uri still valid or 'empty'
		if( uri.length() < 1 ){
			return null;
		}
		uri = m_sLogicalURI +"#"+ uri +"_r";
		if( m_relations.containsKey( uri ) ){
			return (ObjectProperty)m_relations.get( uri );
		}
		ObjectProperty r = m_factory.objectProperty( uri );
		m_relations.put( uri, r );
		try {
			EntityAnnotation relationLabel = createAnnotation( r, relation.getLabel() );
			EntityAnnotation relationConf = createAnnotation( r, relation.getProbability() );
			EntityAnnotation relationCreator = createCreatorAnnotation( r );
			
			List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		    addAxiom( relationLabel, changes );
		    addAxiom( relationConf, changes );
		    addAxiom( relationCreator, changes );
		    
		    m_ontology.applyChanges( changes );
		}
		catch( Exception e ){ 
			e.printStackTrace(); 
		}
		return r;
	}
	
	private void addSubclassOf( List relations ) throws KAON2Exception {
		Iterator iter = relations.iterator();
		while( iter.hasNext() )
		{
			POMSubclassOfRelation rel = (POMSubclassOfRelation)iter.next();
			POMConcept domain = (POMConcept)rel.getDomain(); // returns subclass
			POMConcept range = (POMConcept)rel.getRange();  // return superclass
			String sRel = rel.getLabel().replaceAll( " ", "_" );
			try {
				OWLClass domainClass = createClass( domain );
				OWLClass rangeClass = createClass( range );
				if( domainClass == null || rangeClass == null ){
					System.out.println( "OWLWriter: abandoned sub/superclass: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )");
				}
				else {
					Double dConf = rel.getProbability();
					SubClassOf subclassof;
					
					subclassof = m_factory.subClassOf( domainClass, rangeClass );
							
					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
					addAxiom( subclassof, changes );
					
					m_ontology.applyChanges( changes );  
				} 
			}
			catch( Exception e ){
				System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				e.printStackTrace();
			}
		} 
	}
	

//	private void addContextImport() throws KAON2Exception {
//		try {
//			Annotation annotation = m_factory
//					.annotationByConstant(
//							m_factory
//									.annotationProperty("http://www.cs.man.ac.uk/EntityMetaview#import"),
//							m_factory
//									.constant("http://omv.ontoware.org/provenance"));
//
//			m_ontology.addAnnotation(annotation);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}
	
	private void addInstanceOf( List relations ) throws KAON2Exception {
		Iterator iter = relations.iterator();
		while( iter.hasNext() )
		{
			POMInstanceOfRelation rel = (POMInstanceOfRelation)iter.next();
			POMInstance domain = (POMInstance)rel.getDomain();
			POMConcept range = (POMConcept)rel.getRange();
			 
			String sRel = rel.getLabel().replaceAll( " ", "_" );
			
			try {
				Individual domainIndividual = createIndividual( domain );
				OWLClass rangeClass = createClass( range );
				if ( domainIndividual == null || rangeClass == null ){
					System.out.println( "OWLWriter: abandoned instance: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				}
				else {
					ClassMember member = m_factory.classMember( rangeClass, domainIndividual );
					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
					addAxiom( member, changes );
					m_ontology.applyChanges( changes ); 
				}
			}
			catch( Exception e ){
				System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				e.printStackTrace();
			}
		} 
	}
	
	private void addRelations( List relations ) throws KAON2Exception {
		Iterator iter = relations.iterator();
		while( iter.hasNext() )
		{
			POMRelation rel = (POMRelation)iter.next();
			POMConcept domain = (POMConcept)rel.getDomain();
			POMConcept range = (POMConcept)rel.getRange();
			String sRel = rel.getLabel().replaceAll( " ", "_" );
			try {
				
				OWLClass domainClass = createClass( domain );
				OWLClass rangeClass = createClass( range );
				ObjectProperty relation = createProperty( rel );
				if( domainClass == null || rangeClass == null ){
					System.out.println( "OWLWriter: incomplete relation: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )");
				}
				else {
					ObjectPropertyDomain propertyDomain = m_factory.objectPropertyDomain( relation, domainClass ); 
					ObjectPropertyRange propertyRange = m_factory.objectPropertyRange( relation, rangeClass ); 
					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
					addAxiom( propertyDomain, changes ); 
					addAxiom( propertyRange, changes ); 
					m_ontology.applyChanges( changes );  
				}
			}
			catch( Exception e ){
				System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				e.printStackTrace();
			}
		} 
	}
	
	private void addDisjointClasses( List<POMDisjointClasses> disjoints ) throws KAON2Exception {	
		Iterator iter = disjoints.iterator();
		while( iter.hasNext() )
		{
			Collection<Description> classes = new HashSet<Description>();
			POMDisjointClasses disjoint = (POMDisjointClasses)iter.next();
			try {
				for( POMConcept concept: disjoint.getConcepts() )
				{
					OWLClass c = createClass( concept );
					if( !classes.contains(c) ){
						classes.add(c);
					}
				}
				DisjointClasses dc = m_factory.disjointClasses( classes );
				List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
				addAxiom( dc, changes );
				m_ontology.applyChanges( changes ); 
			}
			catch( Exception e ){
				e.printStackTrace();
			}
		}
	}
	
 	private void addAxiom( Axiom a, List <OntologyChangeEvent> changes ) throws KAON2Exception {
	   if( !m_ontology.containsAxiom( a, false ) ){
	   	changes.add( new OntologyChangeEvent( a, OntologyChangeEvent.ChangeType.ADD ) ); 
		}
	}
	
	private EntityAnnotation createAnnotation( OWLEntity entity, String sLabel ) throws KAON2Exception { 	 
		AnnotationProperty annProp = m_factory.annotationProperty( "http://www.w3.org/2000/01/rdf-schema#label" );
		EntityAnnotation ann = m_factory.entityAnnotation( annProp, entity, m_factory.constant( sLabel ) );
		return ann;
	}
	
	private EntityAnnotation createAnnotation( OWLEntity entity, double dProb ) throws KAON2Exception { 	 
		AnnotationProperty annProp = m_factory.annotationProperty("http://omv.ontoware.org/provenance#confidence" );
		EntityAnnotation ann = m_factory.entityAnnotation( annProp, entity, m_factory.constant( dProb ) );
		return ann;
	}
	
	private EntityAnnotation createCreatorAnnotation( OWLEntity entity) throws KAON2Exception { 	 
		AnnotationProperty annProp = m_factory.annotationProperty( "http://omv.ontoware.org/provenance#agent" );
		EntityAnnotation ann = m_factory.entityAnnotation( annProp, entity, m_factory.constant( "Text2Onto" ) );
		return ann;
	}
	 
	private void saveXML( File file ) throws Exception { 
		file.createNewFile();
		// OWL2XMLExporter.export( file, "ISO-8859-1" , m_ontology );
		m_ontology.saveOntology( OntologyFileFormat.OWL_XML, file, "ISO-8859-1" );
	}
	
	private void saveRDF( File file ) throws Exception {	
		file.createNewFile();
		// OWL2RDFExporter.export( file, "ISO-8859-1", m_ontology );
		m_ontology.saveOntology( OntologyFileFormat.OWL_RDF, file, "ISO-8859-1" );
	}
	
}

package org.neon.toolkit.text2onto.gui.table;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMContentProvider;

public class AbstractTable {
	
	//private final int m_spinDigit = 2;
	
	protected Table m_table;                                                                                                                                
	
	protected Button m_button;
	
	protected Spinner m_spinner;

	protected static final int TABLE_COLUMN_WIDTH = 200;

	protected TableViewer m_tableViewer;
	
	private int m_lastSortColumn= -1;
	
	protected List indexList = new ArrayList();
	
	protected Map string2POMObjectMap = new HashMap();
	
	protected AbstractPOMContentProvider m_ContentProvider;
	
	public Table getTable() {

		return m_table;
	}

	protected Table createTable(Composite parent, String[] sColumns) {
		
		m_tableViewer = new TableViewer( parent, SWT.BORDER|SWT.CHECK|SWT.MULTI|SWT.FULL_SELECTION );
		m_table = m_tableViewer.getTable();
		//Table table = new Table(parent, SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI
		//		| SWT.FULL_SELECTION);
		GridData griddata = new GridData(GridData.FILL_BOTH);
		m_table.setLayoutData(griddata);

		TableLayout layout = new TableLayout();
		//table.setLayout(layout);

		m_table.setHeaderVisible(true);
		m_table.setLinesVisible(true);

		setTableColumns(m_table, sColumns);
		
		Composite composite = new Composite( parent, SWT.NONE );
		composite.setLayout( new RowLayout() );
		composite.setLayoutData( new GridData( GridData.HORIZONTAL_ALIGN_END | GridData.GRAB_HORIZONTAL ) );
		Label label = new Label( composite, SWT.NONE );
		label.setText( "Confidence threshold : " );
		m_spinner = new Spinner( composite, SWT.NONE );
		m_spinner.setValues( 0, 0, 100, 2, 10, 10 );
		m_button = new Button( composite, SWT.NONE );
		m_button.setText( "Filter" );
		m_button.addSelectionListener( new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				doButtonPressed();
			}
		});
		
		return m_table;
	}

	public void doButtonPressed() {
		
		
		//System.out.println(m_tableViewer.);
		
		TableItem[] items = m_table.getItems();
		int lastColumn = m_table.getColumnCount();
		for(int i=0; i<m_table.getItemCount(); i++) {
			if(Double.valueOf(items[i].getText(lastColumn-1)) < m_spinner.getSelection()/100.0) {
				items[i].setChecked( false );
			}else {
				items[i].setChecked( true );
			}
		}
	}
	
	
	public void setTableLayout() {
		GridData griddata = new GridData();
		griddata.horizontalAlignment = GridData.FILL;
		griddata.verticalAlignment = GridData.FILL;
		griddata.verticalSpan = 117;
		m_table.setLayoutData(griddata);

		TableLayout layout = new TableLayout();
		m_table.setLayout(layout);
	}

	public TableViewer getTableViewer() {
		return this.m_tableViewer;
	}

	
	public void setTableColumns(Table table, String[] sColumns) {
		
		for (int i = 0; i < sColumns.length; i++) {
			TableColumn tc = new TableColumn(table, SWT.FILL, i);
			if (i == 0) {
				tc.setWidth(sColumns[i].length()*20);
			} else {
				tc.setWidth(TABLE_COLUMN_WIDTH);
				tc.setResizable(true);
			}
			tc.setText(sColumns[i]);
			final int columnIndex = i;
			tc.addSelectionListener(new SelectionAdapter() {		
				public void widgetSelected(SelectionEvent e) {
					sort(columnIndex);
				}
			});
		}
		
	}
	
	private void sort(int column) {
		if(m_table.getItemCount() <= 1) return;

		TableItem[] items = m_table.getItems();
		String[][] data = new String[items.length][m_table.getColumnCount()+2];
		for(int i = 0; i < items.length; i++) {
			for(int j = 0; j < m_table.getColumnCount(); j++) {
				data[i][j] = items[i].getText(j);
			}
			if(items[i].getChecked()) 
				data[i][m_table.getColumnCount()] = "T";
			else 
				data[i][m_table.getColumnCount()] = "F";
			//data[i][m_table.getColumnCount()+1] = (String)posMap.get( i );
			data[i][m_table.getColumnCount()+1] = (String)indexList.get( i );
		}
		
		Arrays.sort(data, new RowComparator(column));
		indexList.clear();
		
		if (m_lastSortColumn != column) {
			m_table.setSortColumn(m_table.getColumn(column));
			m_table.setSortDirection(SWT.DOWN);
			for (int i = 0; i < data.length; i++) {
				items[i].setText(data[i]);
				if(data[i][m_table.getColumnCount()].equals( "T" )) {
					items[i].setChecked( true );
				}else {
					items[i].setChecked( false );
				}
				//posMap.put( i, data[i][m_table.getColumnCount()+1] );
				indexList.add( data[i][m_table.getColumnCount()+1] );
				
			}
			m_lastSortColumn = column;
		} else {
			// reverse order if the current column is selected again
			m_table.setSortDirection(SWT.UP);
			int j = data.length -1;
			for (int i = 0; i < data.length; i++) {
				items[i].setText(data[j--]);
				if(data[j+1][m_table.getColumnCount()].equals( "T" )) {
					items[i].setChecked( true );
				}else {
					items[i].setChecked( false );
				}
				//posMap.put( i, data[j+1][m_table.getColumnCount()+1] );
				indexList.add( data[j+1][m_table.getColumnCount()+1] );
			}
			m_lastSortColumn = -1;
		}
		
		System.out.println("---===---"+indexList);
		
	}
	
	/**
	 * To compare entries (rows) by the given column
	 */
	private class RowComparator implements Comparator {
		private int column;
		
		/**
		 * Constructs a RowComparator given the column index
		 * @param col The index (starting at zero) of the column
		 */
		public RowComparator(int col) {
			column = col;
		}
		
		/**
		 * Compares two rows (type String[]) using the specified
		 * column entry.
		 * @param obj1 First row to compare
		 * @param obj2 Second row to compare
		 * @return negative if obj1 less than obj2, positive if
		 * 			obj1 greater than obj2, and zero if equal.
		 */
		public int compare(Object obj1, Object obj2) {
			String[] row1 = (String[])obj1;
			String[] row2 = (String[])obj2;
			
			return row1[column].compareTo(row2[column]);
		}
	}
	
	public List getFilteredObjects() {
		TableItem[] items = m_table.getItems();
		List pomObjList = new ArrayList();
		for(int i=0; i<items.length; i++) {
			if(items[i].getChecked()) {
				pomObjList.add( string2POMObjectMap.get( indexList.get( i )));
			}
		}
		return pomObjList;
	}
}

package org.neon.toolkit.text2onto.gui;

import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.neon.toolkit.text2onto.DocProvider;

public class DocView extends ViewPart {

	TextCellEditor m_celleditor;
	StyledText m_text;
	DocProvider m_provider;
	public void createPartControl( Composite parent ) {
		//m_celleditor = new TextCellEditor( parent );
		//m_celleditor.
		StyledText text = new StyledText(parent, SWT.MULTI|SWT.BORDER|SWT.WRAP |SWT.H_SCROLL);
      text.setBounds( 10, 10, 500, 400 );
      GridData spec = new GridData();
      spec.horizontalAlignment = GridData.FILL;
      spec.grabExcessHorizontalSpace = true;
      spec.verticalAlignment = GridData.FILL;
      spec.grabExcessVerticalSpace = true;
      text.setLayoutData(spec);
      //text.addLineStyleListener(lineStyler);
      text.setEditable(false);
		m_provider = new DocProvider();
		//m_celleditor.setContentProvider( m_provider );
		
	}
	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
	}
}

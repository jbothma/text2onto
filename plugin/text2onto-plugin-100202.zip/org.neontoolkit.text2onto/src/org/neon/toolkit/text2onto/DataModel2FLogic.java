package org.neon.toolkit.text2onto;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.TreeItem;
import org.neontoolkit.gui.navigator.AbstractComplexTreeViewer;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;

import com.ontoprise.ontostudio.datamodel.api.IOntologyContainer;
import com.ontoprise.ontostudio.gui.commands.ontology.CreateOntology;
import com.ontoprise.ontostudio.gui.control.Control;
import com.ontoprise.ontostudio.gui.control.InstanceViewControl;
import com.ontoprise.ontostudio.gui.control.SchemaControl;
//import com.ontoprise.ontostudio.gui.navigator.ConfirmDeleteDialogHandler;
import com.ontoprise.ontostudio.gui.navigator.concept.ConceptControl;
import com.ontoprise.ontostudio.gui.navigator.module.ModuleControl;


public class DataModel2FLogic extends DataModel2OntoAbstract {

	private static final String MINCARD_DEFAULT_VALUE = "0"; //$NON-NLS-1$
   private static final String MAXCARD_DEFAULT_VALUE = "-1"; //$NON-NLS-1$
	
	public static final String ONTOLOGY_NAME = "T2ontology"; //$NON-NLS-1$
	public static final String PROJECT_NAME = "T2oPrj"; //$NON-NLS-1$
	public static final String CONCEPTS = "Concepts"; //$NON-NLS-1$
	
	public static final String NAME_SPACE = "http://www.text2onto.org#";
	
	public static final String MODULEID = "http://www.text2onto.org#text2onto";

	private IProject m_project;
	private IOntologyContainer m_moduleContainer;
//	private ConfirmDeleteDialogHandler m_confirmDeleteOKDeleteSubs;
//	private ConfirmDeleteDialogHandler m_confirmDeleteOKNotDeleteSubs;
//	private ConfirmDeleteDialogHandler m_confirmDeleteCancel;
	
	private Set m_sConceptSet;
	
	private String m_moduleId = "http://www.testMod.org";
   private String m_nameSpace = "http://www.testMod.org";
   private String m_prjName;
	

	public void setUp() throws Exception {
		super.setUp();
		m_prjName = getCurrentProject();
		
		if(m_prjName==null) {
			MessageDialog.openInformation( null, "Information",
				"No projects created in Schema, please create one first.");
			return;
		}
		//m_prjName = m_project.getName();
		
	   m_moduleId = Control.getValidModuleIdentifier( MODULEID );
	   m_nameSpace = NAME_SPACE; 
	   
	   
	   /* m_moduleContainer = DatamodelPlugin.getDefault().getContainer(m_prjName);
	   if( m_moduleContainer.existsModule( m_moduleContainer.createTerm( m_moduleId ))) {
	   	m_moduleContainer.removeModule(m_moduleContainer.createTerm( m_moduleId ));
	   }*/
	   
	   
	   // todo: The filename (last parameter) needs to be added
	   new CreateOntology(m_prjName, m_moduleId, m_nameSpace, null).run();
	   
	   ModuleControl.getDefault().addModuleToProject( m_moduleId, m_prjName );
   	
	   System.out.println(m_project.toString());
		//m_project = createProject(PROJECT_NAME, new String[]{ONTOLOGY_NAME});
//		m_confirmDeleteOKDeleteSubs = new ConfirmDeleteDialogHandler(Dialog.OK, true);
//		m_confirmDeleteOKNotDeleteSubs = new ConfirmDeleteDialogHandler(Dialog.OK, false);
//		m_confirmDeleteCancel = new ConfirmDeleteDialogHandler(Dialog.CANCEL, false);
		
		m_sConceptSet = new HashSet();
		
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testAddDataModel(POM pomObj) throws Exception {
		List objList = pomObj.getObjects(POMConcept.class);
		ConceptControl conceptControl = ConceptControl.getDefault();
		for(Object obj:objList) {
			 
			 String sLabel_Concept;
			 sLabel_Concept = ((POMConcept)obj).getLabel().replace( " ", "_" );
			 
			 sLabel_Concept = Control.getValidModuleIdentifier(NAME_SPACE + sLabel_Concept); 
			 
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLabel_Concept ), m_moduleContainer.createTerm( m_moduleId ) );
			 
			 conceptControl.createRootConcept(sLabel_Concept, m_moduleId, m_prjName);
			 
		 }
		 
		objList = pomObj.getObjects(POMSubclassOfRelation.class);
		for(Object obj:objList) {
			 String sLable_Sub= ((POMSubclassOfRelation)obj).getDomain().getLabel().replace( " ", "_" );
			 String sLable_Sup = ((POMSubclassOfRelation)obj).getRange().getLabel().replace( " ", "_" );
			 
			 sLable_Sub = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Sub);
			 sLable_Sup = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Sup);
				 
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Sub ), m_moduleContainer.createTerm( m_moduleId ) );
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Sup ), m_moduleContainer.createTerm( m_moduleId ) );

			 conceptControl.createSubConcept(sLable_Sub, sLable_Sup, m_moduleId, m_prjName);
			 
		}
		
		
		SchemaControl conceptPropertyControl = SchemaControl.getDefault();
		objList = pomObj.getObjects(POMRelation.class);
		for(Object obj:objList) {
			String sLable_Domain = ((POMRelation)obj).getDomain().getLabel().replace( " ", "_" );
			String sLable_Range = ((POMRelation)obj).getRange().getLabel().replace( " ", "_" );
			String sLable_Relation = ((POMRelation)obj).getLabel().replace( " ", "_" );
			
			sLable_Domain = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Domain);
			sLable_Range = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Range);
			sLable_Relation = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Relation);
			
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Domain ), m_moduleContainer.createTerm( m_moduleId ) );
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Range ), m_moduleContainer.createTerm( m_moduleId ) );

			conceptControl.createRootConcept(sLable_Domain, m_moduleId, m_prjName);
			conceptControl.createRootConcept(sLable_Range, m_moduleId, m_prjName);
			
			conceptPropertyControl.createLocalRelation(sLable_Domain, sLable_Relation, sLable_Range, "0", "N", m_moduleId, m_prjName); //$NON-NLS-1$ //$NON-NLS-2$
			
		}
		
		
		InstanceViewControl instanceViewControl = InstanceViewControl.getDefault();

		// add InstanceOf to datamodel
		objList = pomObj.getObjects(POMInstanceOfRelation.class);
		for(Object obj:objList) {
			String sLable_Inst = ((POMInstanceOfRelation)obj).getDomain().getLabel().replace( " ", "_" );
			String sLable_Concept = ((POMInstanceOfRelation)obj).getRange().getLabel().replace( " ", "_" );
			 
			sLable_Inst = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Inst);	
			sLable_Concept = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Concept);
			
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Concept ), m_moduleContainer.createTerm( m_moduleId ) );

			conceptControl.createRootConcept(sLable_Concept, m_moduleId, m_prjName);
		
			instanceViewControl.addInstance(sLable_Inst, sLable_Concept, m_moduleId, m_prjName);	
		}
		 
	}
	/*
	public void testAddConceptView() throws Exception {
		ConceptControl conceptControl = ConceptControl.getDefault();
		
		AbstractComplexTreeViewer treeViewer = m_mtreeView.getTreeViewer();
		TreeItem topItem = m_gui.expandToItem(treeViewer, new String[]{m_prjName});
		
		TreeItem ontology = m_gui.expandToItem(treeViewer, new String[]{m_prjName, m_moduleId});
		
		TreeItem concepts = m_gui.expandToItem(treeViewer, new String[]{m_prjName, m_moduleId, CONCEPTS});
		
		TreeItem[] roots = concepts.getItems();
		
		concepts = m_gui.expandToItem(treeViewer, new String[]{m_prjName, m_moduleId, CONCEPTS});
		
	} 
	*/
	
	private void showMessage(String message) {
		MessageDialog.openInformation(
				null,
			"Information",
			message);
	}

}

package org.neon.toolkit.text2onto.gui.table;

import java.util.List;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.CheckboxCellEditor;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;
import org.neon.toolkit.text2onto.gui.POMView;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMContentProvider;
import org.neon.toolkit.text2onto.gui.provider.AbstractPOMLabelProvider;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;

public class TableSubclassOf extends AbstractTable {
	private String[] sColumns = { "Domain", "Range", "Confidence" };

	public TableSubclassOf(Composite parent, int style) {
		m_table = createTable(parent, sColumns);
		this.createTableViewer(m_table);
	}

	private TableViewer createTableViewer(Table table) {

		//TableViewer tableViewer = new TableViewer(table);
		m_tableViewer.setUseHashlookup(true);
		m_tableViewer.setContentProvider(new POMSubclassOfContentProvider());
		m_tableViewer.setLabelProvider(new POMSubclassOfLabelProvider());

		m_tableViewer.setColumnProperties(sColumns);

		// Create the cell editors
		CellEditor[] editors = new CellEditor[sColumns.length];
		// Column 1 : Completed (Checkbox)
		editors[0] = new CheckboxCellEditor(table);

		// Column 2 : Label (Free text)
		TextCellEditor textEditor = new TextCellEditor(table);
		((Text) textEditor.getControl()).setTextLimit(60);
		editors[1] = textEditor;

		// Column 3 : Label (Free text)
		textEditor = new TextCellEditor(table);
		((Text) textEditor.getControl()).setTextLimit(60);
		editors[2] = textEditor;

		// Assign the cell editors to the viewer
		m_tableViewer.setCellEditors(editors);
		return m_tableViewer;
	}

	public class POMSubclassOfLabelProvider extends AbstractPOMLabelProvider {
		public String getColumnText(Object element, int columnIndex) {
			String result = "";
			POMSubclassOfRelation relation = (POMSubclassOfRelation) element;
			switch (columnIndex) {
			case 0: // COMPLETED_COLUMN
				result = relation.getDomain().getLabel();
				break;
			case 1:
				result = relation.getRange().getLabel();
				break;
			case 2:
				result = new Double(relation.getProbability()).toString();
				break;
			default:
				break;
			}
			return result;
		}
	}

	public class POMSubclassOfContentProvider extends
			AbstractPOMContentProvider {

		public Object[] getElements(Object inputElement) {
			List objList = getObjects(POMView.SUBCLASSOF);
			int pos = 0;
			for(Object obj:objList) {
				string2POMObjectMap.put( ((POMSubclassOfRelation)obj).toString(), ((POMSubclassOfRelation)obj));
				indexList.add(((POMSubclassOfRelation)obj).toString() );
				
				pos++;
			}
			return objList.toArray();
		}
	}

}
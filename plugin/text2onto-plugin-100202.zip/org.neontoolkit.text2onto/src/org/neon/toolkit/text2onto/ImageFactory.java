/*****************************************************************************
 * Copyright (c) 2007 ontoprise GmbH.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License (GPL)
 * which accompanies this distribution, and is available at
 * http://www.ontoprise.de/legal/gpl.html
 *****************************************************************************/

package org.neon.toolkit.text2onto;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Map;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;


public class ImageFactory {

    private static final String PATH_SUFFIX = "icons/"; //$NON-NLS-1$
    
    private static URL _iconBaseURL = Activator.getDefault().getBundle().getEntry(PATH_SUFFIX);;

    private static Map<ImageDescriptor, Image> _imageRegistry = new Hashtable<ImageDescriptor, Image>();

    public static final ImageDescriptor EXPORT = create("text2onto", "export.ico"); //$NON-NLS-1$ //$NON-NLS-2$
    public static final ImageDescriptor NEW = create("text2onto", "star.ico"); //$NON-NLS-1$ //$NON-NLS-2$
    public static final ImageDescriptor EXPORT2OWL = create("text2onto", "world.ico"); //$NON-NLS-1$ //$NON-NLS-2$
    public static final ImageDescriptor EXPORT2FLOGIC = create("text2onto", "gear.ico"); //$NON-NLS-1$ //$NON-NLS-2$
    public static final ImageDescriptor ABOUT = create("text2onto", "help.ico"); //$NON-NLS-1$ //$NON-NLS-2$
    public static final ImageDescriptor RUN = create("text2onto", "play.ico"); //$NON-NLS-1$ //$NON-NLS-2$

    public static Image get(ImageDescriptor descr) {
        Image im = (Image) _imageRegistry.get(descr);
        if (im == null) {
            im = descr.createImage();
            _imageRegistry.put(descr, im);
        }
        return im;
    }
    
    private static ImageDescriptor create(String prefix, String name) {
        try {
            return ImageDescriptor.createFromURL(makeIconFileURL(prefix, name));
        } catch (MalformedURLException e) {
            return ImageDescriptor.getMissingImageDescriptor();
        }
    }
    private static URL makeIconFileURL(String prefix, String name) throws MalformedURLException {
        if (_iconBaseURL == null) {
            throw new MalformedURLException();
        } else {
            StringBuffer buffer = new StringBuffer(prefix);
            buffer.append('/');
            buffer.append(name);
            return new URL(_iconBaseURL, buffer.toString());
        }
    }
}
package org.neon.toolkit.text2onto.gui;


public interface WorkflowListener {

	public final static int ADD = 0;
	
	public final static int REMOVE = 1;
	
	public final static int COMBINER = 2;
	
	public final static int AUXILIARY = 3;
	
	public final static int RESET = 4;
	

	public void workflowChanged( int iMessage, String sComplex, Class algorithmClass, Class configClass );
}


package org.neon.toolkit.text2onto.gui.provider;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.ontoware.text2onto.pom.POMObject;

public abstract class AbstractPOMLabelProvider extends LabelProvider implements
		ITableLabelProvider {
	// Names of images used to represent checkboxes
	public static final String CHECKED_IMAGE = "checked";

	public static final String UNCHECKED_IMAGE = "unchecked";

	public Image getColumnImage(Object element, int columnIndex) {
		/*return (columnIndex == 0) ? // COMPLETED_COLUMN?
				getImage(((POMObject) element).inPOM()) : null;*/
		return null;

	}

	public abstract String getColumnText(Object element, int columnIndex);

	private Image getImage(boolean isSelected) {
		String imageKey = isSelected ? CHECKED_IMAGE : UNCHECKED_IMAGE;
		if (isSelected) {
			imageKey = ISharedImages.IMG_OBJ_PROJECT;//return ISharedImages.IMG_OBJ_PROJECT;//Images.getImage("checked");
		} else {
			imageKey = ISharedImages.IMG_OBJ_ELEMENT;//return ISharedImages.IMG_OBJ_PROJECT;//Images.getImage("unchecked");
		}
		return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		
	}
}
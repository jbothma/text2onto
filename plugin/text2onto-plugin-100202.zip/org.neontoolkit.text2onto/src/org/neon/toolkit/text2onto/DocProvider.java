package org.neon.toolkit.text2onto;

import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class DocProvider implements IContentProvider{

	public void dispose() {
		// TODO Auto-generated method stub
	}

	public void inputChanged( Viewer viewer, Object oldInput, Object newInput ) {
		// TODO Auto-generated method stub
	}
}

package org.neon.toolkit.text2onto.gui.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.neon.toolkit.text2onto.Activator;
import org.neon.toolkit.text2onto.gui.Text2Onto;

public abstract class AbstractAction extends Action implements
		IWorkbenchWindowActionDelegate {

	protected AbstractAction(String sText, String sToolTip) {
		setData(sText, sToolTip);
	}

	protected void notifyT2O(int iMessage) {
		Text2Onto t2o = Activator.getDefault().getT20();
		t2o.buttonPressed(iMessage);
	}

	void setData(String sText, String sToolTip) {
		setText(sText); //$NON-NLS-1$
		setToolTipText(sToolTip); //$NON-NLS-1$
		// setImageDescriptor(Images....);
	}
}


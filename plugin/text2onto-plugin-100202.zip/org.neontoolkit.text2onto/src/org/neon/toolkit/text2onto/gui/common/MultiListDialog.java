package org.neon.toolkit.text2onto.gui.common;

import java.util.List;

import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.dialogs.ListDialog;


public class MultiListDialog extends ListDialog{

	 public MultiListDialog(Shell parent) {
       super(parent);
   }
	 
	 protected int getTableStyle() {
       return SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.BORDER;
   }

}

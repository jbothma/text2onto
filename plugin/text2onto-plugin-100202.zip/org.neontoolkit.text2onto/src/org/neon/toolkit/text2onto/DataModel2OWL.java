package org.neon.toolkit.text2onto;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.jface.dialogs.MessageDialog;
import org.neon.toolkit.text2onto.ontology.T2OSimpleOWLWriter;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMDisjointClasses;
import org.ontoware.text2onto.pom.POMInstance;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;
import org.ontoware.text2onto.reference.ReferenceManager;
import org.ontoware.text2onto.reference.document.DocumentReference;
import org.ontoware.text2onto.util.ProbabilityComparator;
import org.semanticweb.kaon2.api.Axiom;
import org.semanticweb.kaon2.api.DefaultOntologyResolver;
import org.semanticweb.kaon2.api.OntologyManager;
import org.semanticweb.kaon2.api.KAON2Exception;
import org.semanticweb.kaon2.api.KAON2Factory;
import org.semanticweb.kaon2.api.KAON2Manager;
import org.semanticweb.kaon2.api.Ontology;
import org.semanticweb.kaon2.api.OntologyChangeEvent;
import org.semanticweb.kaon2.api.formatting.OntologyFileFormat;
import org.semanticweb.kaon2.api.logic.Term;
import org.semanticweb.kaon2.api.owl.axioms.ClassMember;
import org.semanticweb.kaon2.api.owl.axioms.DataPropertyMember;
import org.semanticweb.kaon2.api.owl.axioms.Declaration;
import org.semanticweb.kaon2.api.owl.axioms.DisjointClasses;
import org.semanticweb.kaon2.api.owl.axioms.EntityAnnotation;
import org.semanticweb.kaon2.api.owl.axioms.ObjectPropertyDomain;
import org.semanticweb.kaon2.api.owl.axioms.ObjectPropertyMember;
import org.semanticweb.kaon2.api.owl.axioms.ObjectPropertyRange;
import org.semanticweb.kaon2.api.owl.axioms.SubClassOf;
import org.semanticweb.kaon2.api.owl.elements.AnnotationProperty;
import org.semanticweb.kaon2.api.owl.elements.DataProperty;
import org.semanticweb.kaon2.api.owl.elements.Individual;
import org.semanticweb.kaon2.api.owl.elements.OWLClass;
import org.semanticweb.kaon2.api.owl.elements.OWLEntity;
import org.semanticweb.kaon2.api.owl.elements.ObjectProperty;

import com.ontoprise.ontostudio.datamodel.DatamodelPlugin;
import com.ontoprise.ontostudio.datamodel.api.IOntologyContainer;
import com.ontoprise.ontostudio.gui.control.Control;
import com.ontoprise.ontostudio.gui.control.InstanceViewControl;
import com.ontoprise.ontostudio.gui.control.SchemaControl;
import com.ontoprise.ontostudio.gui.navigator.concept.ConceptControl;


public class DataModel2OWL extends DataModel2OntoAbstract {

	
	public static final String ONTOLOGY_NAME = "T2ontology"; //$NON-NLS-1$
	public static final String PROJECT_NAME = "T2oPrj"; //$NON-NLS-1$
	public static final String CONCEPTS = "Concepts"; //$NON-NLS-1$
	
	public static final String NAME_SPACE = "http://www.text2onto.org";
	
	public static final String MODULEID = "http://www.text2onto.org/text2onto";

	private IProject m_project;
	

   private String m_moduleId;
   private String m_nameSpace;
   private String m_prjName;
   
   private OntologyManager m_connection;
   
   private KAON2Factory m_factory;
   
   private Ontology m_ontology;
   
   private POM m_pom;
   
   private OWLClass m_conceptClass;
	
	private OWLClass m_instanceClass;
	
	private OWLClass m_subclassOfClass;
	
	private OWLClass m_instanceOfClass;
	
	private OWLClass m_disjointClass;
	
	private OWLClass m_relationClass;
	
	private OWLClass m_referenceClass;
	
	
	private ObjectProperty m_domainProperty;
	
	private ObjectProperty m_rangeProperty;
	
	private DataProperty m_pointsToProperty;
	
	private ObjectProperty m_refersToProperty;
		
	private final static String m_sLogicalURI = "http://www.text2onto.org/ontology";
	
	private static String m_sPhysicalURI;
	
	private ProbabilityComparator m_comparator;
	
	private final static boolean m_REFS = false;
	
   private int m_objId = 1;
	
	private int m_refId = 1;
		

	private ReferenceManager m_referenceManager;
		
	private HashMap classes = new HashMap();

	private HashMap individuals = new HashMap();
	
	private HashMap m_relations = new HashMap();
	
	public void setUp2(POM pom) throws Exception {
		super.setUp();
		m_pom = pom;
		m_prjName = getCurrentProject();
		
		if(m_prjName==null) {
			MessageDialog.openInformation( null, "Information",
				"No projects created in Schema, please create one first.");
			return;
		}
		
	    m_nameSpace = NAME_SPACE; 
	   
	    m_comparator = new ProbabilityComparator();
	   
	    T2OSimpleOWLWriter writer = new T2OSimpleOWLWriter( m_pom );
//	    OWLWriter writer = new OWLWriter( m_pom );
	    
	    IProject project = DatamodelPlugin.getDefault().getProject(m_prjName);
	    IFile newOntologyFile = project.getFile("text2onto.owl");
		System.out.println(newOntologyFile.getLocationURI().toString());
		File newOntoFile = new File(newOntologyFile.getLocationURI());
		
	    writer.write2Project(m_prjName, newOntologyFile.getLocationURI());
	    
	    m_mtreeView.getTreeViewer().refresh();
	    m_mtreeView.getTreeViewer().expandToLevel(2);
	    
	}
	

	public void setUp(POM pom) throws Exception {
		super.setUp();
		m_pom = pom;
		m_prjName = getCurrentProject();
		
		if(m_prjName==null) {
			MessageDialog.openInformation( null, "Information",
				"No projects created in Schema, please create one first.");
			return;
		}
		//m_prjName = m_project.getName();
		
	   
	    m_nameSpace = NAME_SPACE; 
	   
	    m_comparator = new ProbabilityComparator();
	   
		/*m_connection = DatamodelPlugin.getDefault().getKaon2Connection(m_prjName);
		OntologyResolver resolver =  m_connection.getOntologyResolver();
		if(resolver instanceof DefaultOntologyResolver) {
			((DefaultOntologyResolver)resolver).registerReplacement( m_sLogicalURI, "file:/c:/temp/text2onto.owl" );
		}

		try {
			m_ontology = m_connection.createOntology( m_sLogicalURI, new HashMap<String,Object>() );
		}*/
	   
		IProject project = DatamodelPlugin.getDefault().getProject(m_prjName);
		IFile newOntologyFile = project.getFile("text2onto.owl");
		System.out.println(newOntologyFile.getLocationURI().toString());
		File newOntoFile = new File(newOntologyFile.getLocationURI());
		
		System.out.println("PhysicalURI : " + newOntologyFile.getLocationURI().toString());
		//newOntoFile.createNewFile();
		try{
			IOntologyContainer container = DatamodelPlugin.getDefault().getContainer(m_prjName);	
			Term ontoTerm = container.createTerm("text2onto");
			m_connection = container.getConnection();
			
			DefaultOntologyResolver resolver = (DefaultOntologyResolver) m_connection
				.getOntologyResolver();
		

			resolver.registerReplacement(m_sLogicalURI,	newOntoFile.toURI().toString());
			
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put(OntologyManager.USE_FORMAT_NAMES, OntologyFileFormat.OWL_RDF);
			
			if(m_connection.getOntologyURIs().contains(m_sLogicalURI)) {
				Set<Ontology> onto_set = m_connection.getOntologies();
				Set<Ontology> delete_set = new HashSet<Ontology>();
				for(Ontology onto : onto_set) {
					if(onto.getOntologyURI().equals(m_sLogicalURI))
						delete_set.add(onto);	
				}
				
				m_connection.deleteOntologies(delete_set);
			}
			
			m_ontology = m_connection.createOntology(m_sLogicalURI, parameters);					
			//ModuleControl.getDefault().addModuleToProject(ontoTerm.toString(), m_prjName);
		
		}
		catch( KAON2Exception e )
		{
			System.err.println( "Could not create new ontology " + m_sLogicalURI );
			e.printStackTrace();
		}
		finally {
		}  
	   
	    m_factory = KAON2Manager.factory();  
		m_ontology.setDuplicateAxiomsThrowException( false );
		
		init();
		
		System.out.println( "pom classes : " + m_pom.getObjects( POMConcept.class ) );
		
		//addConcepts( m_pom.getObjects( POMConcept.class ) );
		addSubclassOf( m_pom.getObjects( POMSubclassOfRelation.class ) );
		//addRelations( m_pom.getObjects( POMRelation.class ) );
		//addDisjointClasses(m_pom.getObjects(POMDisjointClasses.class));
        
		
		saveRDF(newOntoFile);
		/*
		try {
			
			m_ontology.saveOntology(OntologyFileFormat.OWL_XML, newOntoFile,// "ISO-8859-1");
					SerializationConstants.ENCODING_UTF);

		} catch (KAON2Exception e) {
			System.err
					.println("Could not create new ontology " + m_sLogicalURI);
			e.printStackTrace();
			
			GuiPlugin.logError(e);
		}
		*/

//...		
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testAddDataModel(POM pomObj) throws Exception {
		List objList = pomObj.getObjects(POMConcept.class);
		ConceptControl conceptControl = ConceptControl.getDefault();
		for(Object obj:objList) {
			 
			 String sLabel_Concept;
			 sLabel_Concept = ((POMConcept)obj).getLabel().replace( " ", "_" );
			 
			 sLabel_Concept = Control.getValidModuleIdentifier(NAME_SPACE + sLabel_Concept); 
			 
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLabel_Concept ), m_moduleContainer.createTerm( m_moduleId ) );
			 
			 conceptControl.createRootConcept(sLabel_Concept, m_moduleId, m_prjName);
			 
		 }
		 
		objList = pomObj.getObjects(POMSubclassOfRelation.class);
		for(Object obj:objList) {
			 String sLable_Sub= ((POMSubclassOfRelation)obj).getDomain().getLabel().replace( " ", "_" );
			 String sLable_Sup = ((POMSubclassOfRelation)obj).getRange().getLabel().replace( " ", "_" );
			 
			 sLable_Sub = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Sub);
			 sLable_Sup = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Sup);
				 
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Sub ), m_moduleContainer.createTerm( m_moduleId ) );
			 // m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Sup ), m_moduleContainer.createTerm( m_moduleId ) );

			 //conceptControl.createSubConcept( sLable_Sub, sLable_Sup, m_moduleId, m_prjName, true );
			 conceptControl.createSubConcept(sLable_Sub, sLable_Sup, m_moduleId, m_prjName);
			 
		}
		
		
		SchemaControl conceptPropertyControl = SchemaControl.getDefault();
		objList = pomObj.getObjects(POMRelation.class);
		for(Object obj:objList) {
			String sLable_Domain = ((POMRelation)obj).getDomain().getLabel().replace( " ", "_" );
			String sLable_Range = ((POMRelation)obj).getRange().getLabel().replace( " ", "_" );
			String sLable_Relation = ((POMRelation)obj).getLabel().replace( " ", "_" );
			
			sLable_Domain = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Domain);
			sLable_Range = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Range);
			sLable_Relation = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Relation);
			
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Domain ), m_moduleContainer.createTerm( m_moduleId ) );
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Range ), m_moduleContainer.createTerm( m_moduleId ) );

			conceptControl.createRootConcept(sLable_Domain, m_moduleId, m_prjName);
			conceptControl.createRootConcept(sLable_Range, m_moduleId, m_prjName);
			
			conceptPropertyControl.createLocalRelation(sLable_Domain, sLable_Relation, sLable_Range, "0", "N", m_moduleId, m_prjName); //$NON-NLS-1$ //$NON-NLS-2$
			
		}
		
		
		InstanceViewControl instanceViewControl = InstanceViewControl.getDefault();

		// add InstanceOf to datamodel
		objList = pomObj.getObjects(POMInstanceOfRelation.class);
		for(Object obj:objList) {
			String sLable_Inst = ((POMInstanceOfRelation)obj).getDomain().getLabel().replace( " ", "_" );
			String sLable_Concept = ((POMInstanceOfRelation)obj).getRange().getLabel().replace( " ", "_" );
			 
			sLable_Inst = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Inst);	
			sLable_Concept = Control.getValidModuleIdentifier(NAME_SPACE + sLable_Concept);
			
			// m_moduleContainer.removeConcept( m_moduleContainer.createTerm( sLable_Concept ), m_moduleContainer.createTerm( m_moduleId ) );

			conceptControl.createRootConcept(sLable_Concept, m_moduleId, m_prjName);
		
			instanceViewControl.addInstance(sLable_Inst, sLable_Concept, m_moduleId, m_prjName);	
		}
		 
	}
	

	
	private void showMessage(String message) {
		MessageDialog.openInformation(
				null,
			"Information",
			message);
	}
	
	private void init() throws KAON2Exception {	
		
		OWLClass elementClass = m_factory.owlClass( m_sLogicalURI +"#Element" );
		OWLClass entityClass = m_factory.owlClass( m_sLogicalURI +"#Entity" );

		
		SubClassOf referenceThing = m_factory.subClassOf( m_referenceClass, m_factory.thing() );
		SubClassOf elementThing = m_factory.subClassOf( elementClass, m_factory.thing() );
		SubClassOf entityElement = m_factory.subClassOf( entityClass, elementClass );
		SubClassOf conceptEntity = m_factory.subClassOf( m_conceptClass, entityClass );
		SubClassOf instanceEntity = m_factory.subClassOf( m_instanceClass, entityClass );
		SubClassOf subclassOfElement = m_factory.subClassOf( m_subclassOfClass, elementClass );
		SubClassOf instanceOfElement = m_factory.subClassOf( m_instanceOfClass, elementClass );
		SubClassOf relationElement = m_factory.subClassOf( m_relationClass, elementClass );
		SubClassOf disjointElement = m_factory.subClassOf( m_disjointClass, elementClass );
		
		
		m_domainProperty = m_factory.objectProperty( m_sLogicalURI +"#Domain" );
		m_rangeProperty = m_factory.objectProperty( m_sLogicalURI +"#Range" );
		
		m_pointsToProperty = m_factory.dataProperty( m_sLogicalURI +"#PointsTo" );
		m_refersToProperty = m_factory.objectProperty( m_sLogicalURI +"#RefersTo" );
		
		//m_nameProperty = m_factory.dataProperty( m_sLogicalURI +"#Name" );
		
		//List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		//changes.add( new OntologyChangeEvent( referenceThing, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( elementThing, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( entityElement, OntologyChangeEvent.ChangeType.ADD ) ); 
		//changes.add( new OntologyChangeEvent( conceptEntity, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( instanceEntity, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( subclassOfElement, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( instanceOfElement, OntologyChangeEvent.ChangeType.ADD ) ); 
		//changes.add( new OntologyChangeEvent( relationElement, OntologyChangeEvent.ChangeType.ADD ) );
		//changes.add( new OntologyChangeEvent( disjointElement, OntologyChangeEvent.ChangeType.ADD ) );
		
		//m_ontology.applyChanges( changes );  
		
	}

	private void addInstances( List instances ) throws KAON2Exception {
		Collections.sort( instances, m_comparator );
		Iterator iter = instances.iterator();
		while( iter.hasNext() )
		{ 
			POMInstance instance = (POMInstance)iter.next(); 
			createIndividual(instance);
		}
	}
	
	private void addConcepts( List concepts ) throws KAON2Exception {
		//Collections.sort( concepts, m_comparator );
		Iterator iter = concepts.iterator();
		while( iter.hasNext() )
		{ 
			POMConcept concept = (POMConcept)iter.next(); 
			createClass(concept);
		} 
	}
	
	private String checkForInvalidChars(String uri) {
		// returns filtered uri... 
		return uri.replaceAll("[()\\[\\]\\^\\%\\>\\<\\&\\;]", "");
	}
	
	private String checkString( String s ){
		if( s.contains( "[" ) || s.contains( "]" ) || s.contains( "%" ) 
			|| s.contains( ">" ) || s.contains( "<" ) || s.contains( "^" ) 
			|| s.contains( "&lt;" ) || s.contains( "&gt;" ) )
		{
			s = s.replace( "[", "" ); // "sq_brackets_open" );
			s = s.replace( "]", "" ); // "sq_brackets_close" );
			s = s.replace( "%", "" ); // "percent" );	
			s = s.replace( ">", "" ); // "greater_than" );	
			s = s.replace( "<", "" ); // "less_than" );
			s = s.replace( "^", "" ); // "caret" );
			s = s.replace( "&gt;", "" ); // "greater_than" );	
			s = s.replace( "&lt;", "" ); // "less_than" );
		}
		if( s.length() == 0 ){
			return null;
		}
		return s;
	}

	private OWLClass createClass( POMConcept concept ){
		String uri = checkForInvalidChars(concept.getLabel().replaceAll( " ", "_" ));
		OWLClass myClass = null;
		// check if uri still valid or 'empty'
		if (uri.length() < 1) {
			return myClass;
		}
		uri = m_sLogicalURI +"#"+ uri +"_c";


		try {
			myClass = m_factory.owlClass(uri );
		   Declaration member = m_factory.declaration( myClass );
		   List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		   addAxiom( member, changes );
		   
		   m_ontology.applyChanges( changes );
		}
		catch( Exception e ){ 
			System.out.println( e.toString() ); 
		}
		return myClass;
	}
	
	private Individual createIndividual( POMInstance instance ){
		String uri = checkForInvalidChars(instance.getLabel().replaceAll( " ", "_" ));
		// check if uri still valid or 'empty'
		if (uri.length() < 1) {
			return null;
		}
		uri = m_sLogicalURI +"#"+ uri +"_i";
		if( individuals.containsKey( uri ) ){ 
			return (Individual)individuals.get( uri );
		}
		Individual c = m_factory.individual( uri );
		individuals.put( uri, c );
		try {
		   ClassMember member = m_factory.classMember( m_instanceClass, c);
		   //Annotation instanceAnn = createAnnotation( c, instance.getProbability() );
		   //Annotation instanceLabel = createAnnotation( c, instance.getLabel() );
		   List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		   //addAxiom( instanceAnn, changes );
		   //addAxiom( instanceLabel, changes );
		   addAxiom( member, changes );
		   m_ontology.applyChanges(changes);
		}
		catch( Exception e ){
			System.out.println( e.toString() ); 
		}
		return c;
	}
	
	private void addSubclassOf( List relations ) throws KAON2Exception {
		Collections.sort( relations, m_comparator );
		Iterator iter = relations.iterator();
		while( iter.hasNext() )
		{
			POMSubclassOfRelation rel = (POMSubclassOfRelation)iter.next();
			POMConcept subConcept = (POMConcept)rel.getDomain(); //returns subclass
			POMConcept superConcept = (POMConcept)rel.getRange();  // return superclass
			 
			String sRel = rel.getLabel().replaceAll( " ", "_" );

			try {
				OWLClass subClass = createClass(subConcept);
				OWLClass superClass = createClass(superConcept);
				SubClassOf myAxiom = m_factory.subClassOf(subClass, superClass);
				List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();

				addAxiom( myAxiom, changes ); 


			    m_ontology.applyChanges( changes );  


			}
			catch( Exception e ){
				//System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				e.printStackTrace();
			}
		} 
	}
		
//	private void addInstanceOf( List relations ) throws KAON2Exception {
//		Collections.sort( relations, m_comparator );
//		Iterator iter = relations.iterator();
//		while( iter.hasNext() )
//		{
//			POMInstanceOfRelation rel = (POMInstanceOfRelation)iter.next();
//			POMInstance domain = (POMInstance)rel.getDomain();
//			POMConcept range = (POMConcept)rel.getRange();
//			 
//			String sRel = rel.getLabel().replaceAll( " ", "_" );
//			
//			try {
//				Individual domainIndividual = createIndividual( domain );
//				Individual rangeIndividual = createClass(range);
//				if ( domainIndividual == null | rangeIndividual == null ){
//					System.out.println( "OWLWriter: abandoned instance: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
//				}
//				else {
//					Individual relationIndividual = m_factory.individual( m_sLogicalURI +"#"+ sRel +"_"+ (m_objId++) + System.currentTimeMillis()/1000 ); 
//
//					ClassMember relationMember = m_factory.classMember( m_instanceOfClass, relationIndividual );
//
//					//Annotation relationAnn = createAnnotation( relationIndividual, rel.getProbability() );
//					//Annotation relationLabel = createAnnotation( relationIndividual, rel.getLabel() );
//
//					// DataPropertyMember domainName = m_factory.dataPropertyMember( m_nameProperty, domainIndividual, sDomain );
//					// DataPropertyMember rangeName = m_factory.dataPropertyMember( m_nameProperty, rangeIndividual, sRange );
//					// DataPropertyMember relationName = m_factory.dataPropertyMember( m_nameProperty, relationIndividual, sRel );
//
//					ObjectPropertyMember propertyDomain = m_factory.objectPropertyMember( m_domainProperty, relationIndividual, domainIndividual ); 
//					ObjectPropertyMember propertyRange = m_factory.objectPropertyMember( m_rangeProperty, relationIndividual, rangeIndividual );  			
//
//					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
//
//					addAxiom( relationMember, changes ); 
//
//					//addAxiom( relationAnn, changes );
//					//addAxiom( relationLabel, changes );
//
//					// addAxiom( domainName, changes );
//					// addAxiom( rangeName, changes );
//					// addAxiom( relationName, changes );
//
//					addAxiom( propertyDomain, changes ); 
//					addAxiom( propertyRange, changes ); 
//
//					m_ontology.applyChanges( changes ); 
//
//					/*
//					if( m_REFS ){
//						addReferences( domainIndividual, getReferences( domain ) );
//						addReferences( rangeIndividual, getReferences( range ) ); 
//						addReferences( relationIndividual, getReferences( rel ) );
//					}
//					*/
//				}
//			}
//			catch( Exception e ){
//				System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
//				e.printStackTrace();
//			}
//		} 
//	}
	
	private void addRelations( List relations ) throws KAON2Exception {
		//Collections.sort( relations, m_comparator );
		Iterator iter = relations.iterator();
		while( iter.hasNext() )
		{
			POMRelation rel = (POMRelation)iter.next();
			POMConcept domain = (POMConcept)rel.getDomain(); //returns subclass
			POMConcept range = (POMConcept)rel.getRange();  // return superclass
			 
			String sRel = rel.getLabel().replaceAll( " ", "_" );

			try {
				
				OWLClass domainClass = createClass( domain );
				OWLClass rangeClass = createClass( range );
				ObjectProperty relation = createProperty( rel );
				if( domainClass == null || rangeClass == null ){
					System.out.println( "OWLWriter: incomplete relation: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )");
				}
				else {
					ObjectPropertyDomain propertyDomain = m_factory.objectPropertyDomain( relation, domainClass ); 
					ObjectPropertyRange propertyRange = m_factory.objectPropertyRange( relation, rangeClass ); 
					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
					addAxiom( propertyDomain, changes ); 
					addAxiom( propertyRange, changes ); 
					m_ontology.applyChanges( changes );  
				}
				/*
				OWLClass domainClass = createClass( domain );
				OWLClass rangeClass = createClass( range );
				if ( domainClass == null || rangeClass == null ){
					System.out.println( "OWLWriter: abandoned relation: " + sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )");
				}
				else {
					Individual relationIndividual = m_factory.individual( m_sLogicalURI +"#"+ sRel +"_"+ (m_objId++) + System.currentTimeMillis()/1000 ); 


					ObjectProperty myProperty = m_factory.objectProperty( m_sLogicalURI +"#"+ sRel);
					ObjectPropertyDomain propertyDomain= m_factory.objectPropertyDomain(myProperty, domainClass);
					ObjectPropertyRange propertyRange = m_factory.objectPropertyRange(myProperty, rangeClass);

					List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();

					addAxiom( propertyDomain, changes ); 
					addAxiom( propertyRange, changes ); 

					m_ontology.applyChanges( changes );  

					
				}
				*/
			}
			catch( Exception e ){
				System.out.println( "OWLWriter: cannot create relation "+ sRel +"( "+ domain.getLabel() +", "+ range.getLabel() +" )" );
				e.printStackTrace();
			}
		} 
	}
	
	/* private void addDisjointClasses( List<POMDisjointClasses> disjoints ) throws KAON2Exception {
		Collections.sort( disjoints, m_comparator );
		Iterator iter = disjoints.iterator();
		while( iter.hasNext() )
		{
			POMDisjointClasses disjoint = (POMDisjointClasses)iter.next(); 
			List<POMConcept> concepts = new ArrayList( disjoint.getConcepts() );
			if( concepts.size() == 2 ){
				addDisjointClasses( disjoint, (POMConcept)concepts.get(0), (POMConcept)concepts.get(1) );
			}
			else {
				for( int i=0; i<concepts.size(); i++ )
				{
					POMConcept concept1 = (POMConcept)concepts.get(i);
					for( int j=i+1; j<concepts.size(); j++ )
					{
						POMConcept concept2 = (POMConcept)concepts.get(j); 
						addDisjointClasses( disjoint, concept1, concept2 );
					}
				} 
			}
		}
	} */
	
	/* DEBUG */
	private void addDisjointClasses( List<POMDisjointClasses> disjoints ) throws KAON2Exception {
		// Collections.sort( disjoints, m_comparator );
		Iterator iter = disjoints.iterator();
		while( iter.hasNext() )
		{
			POMDisjointClasses disjoint = (POMDisjointClasses)iter.next();
			List<POMConcept> concepts = new ArrayList( disjoint.getConcepts() );
			if( concepts.size() == 2 )
			{
				POMConcept concept1 = concepts.get(0);
				POMConcept concept2 = concepts.get(1);

				if( !( concept1 != null && concept1.equals( concept2 ) )
					&& !( concept2 != null && concept2.equals( concept1 ) ) )
				{
					addDisjointClasses( concept1, concept2 );
				}
			} 
/*			else {
				for( int i=0; i<concepts.size(); i++ )
				{
					POMConcept concept1 = (POMConcept)concepts.get(i);
					for( int j=i+1; j<concepts.size(); j++ )
					{
						POMConcept concept2 = (POMConcept)concepts.get(j); 
						addDisjointClasses( disjoint, concept1, concept2 );
					}
				} 
			} */
		}
	}
	
	private void addDisjointClasses( POMConcept concept1, POMConcept concept2 ){
		// check relevance

		try {
			OWLClass c1 = createClass(concept1);
			OWLClass c2 = createClass(concept2);
			
			List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
			DisjointClasses disjointClasses = m_factory.disjointClasses(c1, c2);
				addAxiom( disjointClasses, changes ); 
				m_ontology.applyChanges( changes );  
		}
		catch( Exception e ){
			System.out.println( "OWLWriter: cannot create axiom ( "+ concept1 +", "+ concept2 +" )" );
			e.printStackTrace();
		} 
	}
 
	private void addReferences( Individual object, List<DocumentReference> references ) throws KAON2Exception {  
		for( DocumentReference reference: references )
		{
			String sURI = reference.getDocument().getURI().toString();
			String sName = null;
			if (sURI.contains("."))
				sName = sURI.substring( sURI.lastIndexOf( "/" )+1, sURI.lastIndexOf( "." ) );
			else
				sName = sURI.substring( sURI.lastIndexOf( "/" )+1 );

			Individual referenceIndividual = m_factory.individual( m_sLogicalURI +"#Reference_"+ (m_refId++) + "_doc" + sName );
			ClassMember referenceMember = m_factory.classMember( m_referenceClass, referenceIndividual );
			DataPropertyMember pointsToMember = m_factory.dataPropertyMember( m_pointsToProperty, referenceIndividual, m_factory.constant( sName ) );
			ObjectPropertyMember refersToMember = m_factory.objectPropertyMember( m_refersToProperty, referenceIndividual, object );

			List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
			
			addAxiom( referenceMember, changes );
			addAxiom( pointsToMember, changes );
			addAxiom( refersToMember, changes );
			
			// changes.add( new OntologyChangeEvent( referenceMember, OntologyChangeEvent.ChangeType.ADD ) ); 
			// changes.add( new OntologyChangeEvent( pointsToMember, OntologyChangeEvent.ChangeType.ADD ) ); 
			// changes.add( new OntologyChangeEvent( refersToMember, OntologyChangeEvent.ChangeType.ADD ) ); 
			
			m_ontology.applyChanges( changes );
		}
	}
	
	private void addAxiom( Axiom a, List <OntologyChangeEvent> changes ) throws KAON2Exception {
	   if( !m_ontology.containsAxiom( a, false ) ){
	   	changes.add( new OntologyChangeEvent( a, OntologyChangeEvent.ChangeType.ADD ) ); 
		}
	}
	
	private ObjectProperty createProperty( POMRelation relation ){
		String uri = checkForInvalidChars( relation.getLabel().replaceAll( " ", "_" ) );
		// check if uri still valid or 'empty'
		if( uri.length() < 1 ){
			return null;
		}
		uri = m_sLogicalURI +"#"+ uri +"_r";
		if( m_relations.containsKey( uri ) ){
			return (ObjectProperty)m_relations.get( uri );
		}
		ObjectProperty r = m_factory.objectProperty( uri );
		m_relations.put( uri, r );
		try {
			EntityAnnotation relationLabel = createAnnotation( r, relation.getLabel() );
			List<OntologyChangeEvent> changes = new ArrayList<OntologyChangeEvent>();
		    addAxiom( relationLabel, changes );
		    m_ontology.applyChanges( changes );
		}
		catch( Exception e ){ 
			e.printStackTrace(); 
		}
		return r;
	}
	
	private EntityAnnotation createAnnotation( OWLEntity entity, String sLabel ) throws KAON2Exception { 	 
		AnnotationProperty annProp = m_factory.annotationProperty( "http://www.w3.org/2003/05/owl-xml#Label" );
		EntityAnnotation ann = m_factory.entityAnnotation( annProp, entity, m_factory.constant( sLabel ) );
		return ann;
	}
	
	private void saveRDF( File file ) throws Exception {	
		file.createNewFile();
		// OWL2RDFExporter.export( file, "ISO-8859-1", m_ontology );
		m_ontology.saveOntology( OntologyFileFormat.OWL_RDF, file, "ISO-8859-1" );
	}
}

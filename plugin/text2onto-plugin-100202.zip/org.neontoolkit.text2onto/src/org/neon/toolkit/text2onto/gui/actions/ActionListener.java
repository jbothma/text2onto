package org.neon.toolkit.text2onto.gui.actions;

public interface ActionListener {
	public final static int LOAD = 0;

	public final static int SAVE = 1;

	public final static int NEW = 2;

	public final static int RUN = 3;

	public final static int IMPORT = 4;

	public final static int EXPORT = 5;

	public static final int NEWPROJECT = 6;
	
	public static final int TOFLOGIC = 7;
	
	public static final int TOOWL = 8;
	
	public static final int ABOUT = 9;

	public void buttonPressed(int iMessage);

}

// This file is changed and committed by build system!
package org.neontoolkit.plugin;
public class RegisterTypeData {
    public static final String BUILD_ID        = "191"; //$NON-NLS-1$
    public static final String BUILD_TIMESTAMP = "2009-12-08 19:01:14"; //$NON-NLS-1$
}
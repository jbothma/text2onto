How to get the SWT programs to run:

There are platform dependent jar/libraries provided for the Win32/x86 and
Linux/x86 in the 3rdparty/eclipse directory. You have to add the
corresponding jar-File to your classpath; besides, you have to tell the
java runtime where to find the library files for your platform.
Note that under Linux you will need Java 5 (jre1.5) to run this. Under windows,
jde1.4 is enough.


To do this, add the following runtime parameter:

Linux:
-Djava.library.path=${system:ECLIPSE_HOME}/plugins/org.eclipse.swt.gtk_3.0.1/os/linux/x86

Win32:
-Djava.library.path=${system:ECLIPSE_HOME}/plugins/org.eclipse.swt.gtk_3.0.1/os/win32/x86

Under Eclipse, you may do this under "Run"->"arguments"->"vm arguments". Just
paste this into the text field.

It should be well possible to get this to run under other platforms as
well, assuming there are jars provided by the Eclipse/SWT project. These
may be found in the corresponding platform SDKs.

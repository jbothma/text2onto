package org.ontoware.text2onto.gui.jgraph;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.jgraph.*;
import org.jgraph.graph.EdgeView;
import org.jgraph.graph.VertexView;
import org.jgraph.graph.CellMapper;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMFactory;

/**
 * @author stephan
 * 
 */
public class POMGraphTest {

	public static void main( String[] args ){
		POMGraph graph;
		
		JFrame frame = new JFrame( "testGraph" );
		frame.setBounds( 0, 0, 400, 400 );

		POM testPOM = null;
		try {
			// testPOM = POMFactory.newPOM( "file:/home/stephan/texttoonto/software/testontology.kaon" );
			testPOM = POMFactory.newPOM( args[0] );
		
			graph = POMGraph.createGraphfromPOM( testPOM );
			
			graph.setFrame( frame );
	
			// frame.pack();
			frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			frame.setVisible( true );
			
			//for(int i=1;i<30;i++)
				//graph.updateLayout();
			
		} 
		catch( Exception e ){ 
			System.out.println( "GT: " + e );
			e.printStackTrace();
		}				
	}
}
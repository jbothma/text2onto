package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Graphics;

import org.jgraph.JGraph;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.EdgeRenderer;
import org.jgraph.graph.EdgeView;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationView.POMRelationRenderer;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMSubclassOfRelationView extends POMRelationView {
	public POMSubclassOfRelationView( Object cell ){
		super( cell );
	}
    
	protected static POMRelationRenderer renderer = new POMRelationRenderer();
    
	public CellViewRenderer getRenderer() {
		return renderer;
	}
    
	public static class POMRelationRenderer extends EdgeRenderer {
		public void paint( Graphics g ){
			super.paint(g);
			//if( !preview ) System.out.println( "paint" );
			//System.out.flush();
		}
	}

}

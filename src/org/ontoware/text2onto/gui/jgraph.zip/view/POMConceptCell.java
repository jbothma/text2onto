package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Map;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.GraphConstants;

/**
 * @author stephan
 *
 */
public class POMConceptCell extends POMEntityCell implements POMCell {

	public POMConceptCell( Map attributes, DefaultGraphModel model, String label, double dProb ){
		super( attributes, model, label, dProb );
		
		// Border border = new LineBorder( Color.RED );
		// GraphConstants.setBorder( cellAttrib , border );
		GraphConstants.setBorderColor( m_cellAttrib, Color.BLACK );
		
		// GraphConstants.setSizeable( cellAttrib, false );
		
		Rectangle2D cellBounds = m_cellAttrib.createRect( 0, 0, 90, 20 );
		GraphConstants.setBounds( m_cellAttrib, cellBounds );
		
		
		attributes.put( this, m_cellAttrib );
	}
}

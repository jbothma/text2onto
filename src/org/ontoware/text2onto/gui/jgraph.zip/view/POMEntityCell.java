package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.GraphConstants;

/**
 * @author stephan
 *
 */
public class POMEntityCell extends DefaultGraphCell implements POMCell {

	protected AttributeMap m_cellAttrib;

	protected DefaultGraphModel m_model; 

	
	public POMEntityCell( Map attributes, DefaultGraphModel model, String label, double dProb ){
		super( label + " " 
			+ Double.toString( dProb ).substring( 0, Math.min( Double.toString( dProb ).indexOf( "." ) + 3, Double.toString( dProb ).length() ) ) );		
		m_model = model;
		m_cellAttrib = new AttributeMap();
		
		GraphConstants.setAutoSize( m_cellAttrib, true );
		//GraphConstants.setResize( m_cellAttrib, true );
		
		attributes.put( this, m_cellAttrib );
	}
	
	public void setEvidence( boolean value )
	{
		m_cellAttrib = new AttributeMap();
		if( value ){
			GraphConstants.setBorderColor( m_cellAttrib, Color.GREEN );
		}
		else {
			GraphConstants.setBorderColor( m_cellAttrib, Color.RED );
		}
		m_cellAttrib.put( "evidence", new Boolean( value ));
		
		HashMap map = new HashMap();		
		map.put( this, m_cellAttrib );
		m_model.edit( map, null, null, null );
	}	
}

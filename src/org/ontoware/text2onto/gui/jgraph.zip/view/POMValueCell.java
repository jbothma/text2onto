package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Map;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.GraphConstants;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMValueCell extends POMEntityCell {
	public POMValueCell( Map attributes, DefaultGraphModel model, String label, double dProb ) {
		super( attributes, model, label, dProb );
		
		//Border border = new LineBorder(Color.RED);
		//GraphConstants.setBorder( cellAttrib , border);
		GraphConstants.setBorderColor( m_cellAttrib, Color.BLACK );
		
		//GraphConstants.setSizeable( cellAttrib, false );
		
		Rectangle2D cellBounds = m_cellAttrib.createRect(20, 20, 60, 60);
		GraphConstants.setBounds( m_cellAttrib, cellBounds );
		
		GraphConstants.setAutoSize( m_cellAttrib, false ); //workaround for auto size bug
		
		attributes.put( this, m_cellAttrib );
	}
	public Dimension getPreferredSize() {
		return new Dimension(300,300);
	}
	
}

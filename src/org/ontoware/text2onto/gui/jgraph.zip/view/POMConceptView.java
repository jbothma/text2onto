package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.jgraph.JGraph;
import org.jgraph.cellview.JGraphEllipseView;
import org.jgraph.cellview.JGraphMultilineView;
import org.jgraph.cellview.JGraphRoundRectView;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.GraphModel;
import org.jgraph.graph.VertexRenderer;
import org.jgraph.graph.VertexView;

public class POMConceptView extends JGraphRoundRectView {

	public POMConceptView( Object cell ){
		super( cell );
		// super( cell, model, cm );
	}

	protected static POMConceptRenderer renderer = new POMConceptRenderer();

	public CellViewRenderer getRenderer(){
		return renderer;
	}

	public static class POMConceptRenderer extends JGraphRoundRectView.ActivityRenderer {

		public static String convertLabelToHtml( String label ){
			/*
			String output = "";
			if( label != null ) 
			{
				StringTokenizer st = new StringTokenizer( label );
				while( st.hasMoreTokens() ) {
					String token = st.nextToken();
					output += token;
					if( st.hasMoreTokens() )
						output += "<br>";
				}  
				output = "<html>" + output + "</html>";
			}
			return output; 
			*/
			
			return "<html>"+ label + "</html>";
		}

		public void paint( Graphics g )
		{
			// Dimension d = getSize();
			setText( convertLabelToHtml( getText() ) );
			super.paint( g );
		}
	}
}
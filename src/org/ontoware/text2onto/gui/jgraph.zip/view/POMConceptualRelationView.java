package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Graphics;
import java.awt.geom.Point2D;

import org.jgraph.JGraph;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.EdgeRenderer;
import org.jgraph.graph.EdgeView;


public class POMConceptualRelationView extends POMRelationView {

	public POMConceptualRelationView( Object cell ){
		super( cell );
		//System.out.println("cell is a POMRelationEdge, num " + ((POMRelationEdge)cell).getNumOfParallelConnection());		
	}
    
	protected static POMRelationRenderer renderer = new POMRelationRenderer();
    
	public  CellViewRenderer getRenderer() {
		return renderer;
	}
    
	public static class POMRelationRenderer extends EdgeRenderer {
		public void paint( Graphics g ){
			super.paint(g);
			//if( !preview ) System.out.println( "paint" );
			//System.out.flush();
		}
		
		/*protected void paintLabel(Graphics g, String label, Point2D p,
				boolean mainLabel) {
			
		}*/
	}
}

package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.io.Serializable;
import java.util.StringTokenizer;

import javax.swing.SwingUtilities;

import org.jgraph.JGraph;
import org.jgraph.cellview.JGraphMultilineView;
import org.jgraph.cellview.JGraphRoundRectView;
import org.jgraph.graph.CellHandle;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.EdgeRenderer;
import org.jgraph.graph.EdgeView;
import org.jgraph.graph.GraphContext;
import org.jgraph.graph.EdgeView.EdgeHandle;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptView.POMConceptRenderer;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMRelationView extends EdgeView {

	public POMRelationView( Object cell ){
		//super( cell, graph, cm );
		super( cell );
	}
	
	public CellHandle getHandle( GraphContext context ) {
		return new POMEdgeHandle( this, context );
	}
	
	public static class POMEdgeHandle extends EdgeHandle {
		
		public POMEdgeHandle( EdgeView edge, GraphContext ctx ) {
			super( edge, ctx );
		}
		
		/**
		 * Returning true signifies a mouse event adds a new point to an edge.
		 */
		public boolean isAddPointEvent( MouseEvent event ) {
			return SwingUtilities.isRightMouseButton( event ) && event.isShiftDown();
		}
		
		/**
		 * override in order to make editing labels impossible 
		 */
		public void mousePressed(MouseEvent event) {
			super.mousePressed( event );
			
			label = false;
			
		}
		
		
	}
	
	
}

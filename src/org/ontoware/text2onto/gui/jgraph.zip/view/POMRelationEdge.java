package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Map;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.Edge;
import org.jgraph.graph.EdgeView;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.PortView;
import org.jgraph.util.JGraphParallelEdgeRouter;
import org.jgraph.util.JGraphUtilities;

/**
 * @author stephan
 */
public class POMRelationEdge extends DefaultEdge implements POMCell {
	protected int m_numOfParallelConnection;
	protected int m_totalNumOfParallelConnections;
	
	protected AttributeMap m_edgeAttrib;
	protected DefaultGraphModel m_model;
	
	public POMRelationEdge( Map attributes, DefaultGraphModel model, String label ) {
		super( label );
		m_model = model;
		m_edgeAttrib = new AttributeMap();
		
		GraphConstants.setLineStyle( m_edgeAttrib, GraphConstants.STYLE_BEZIER );
		
		//GraphConstants.setMoveable( m_edgeAttrib, new Point(30,3));
		
		//GraphConstants.set( m_edgeAttrib, false);
		
		GraphConstants.setRouting( m_edgeAttrib, JGraphParallelEdgeRouter.getSharedInstance() );
		
		attributes.put( this, m_edgeAttrib );
		
	}
	
	
	
	public void setEvidence( boolean value )
	{
		m_edgeAttrib = new AttributeMap();
		if( value )
			GraphConstants.setLineColor( m_edgeAttrib, Color.GREEN );
		else
			GraphConstants.setLineColor( m_edgeAttrib, Color.RED );
		
		GraphConstants.setBendable( m_edgeAttrib, false);
		HashMap map = new HashMap();
		map.put( this, m_edgeAttrib );		
		m_model.edit( map, null, null, null );
	}
	
	/*public int getNumOfParallelConnection()
	{
		return m_numOfParallelConnection;
	}
	public int getTotalNumOfParallelConnections()
	{
		return m_totalNumOfParallelConnections;
	}
	
	public void setNumOfParallelConnection( int num, int totalNum ) {
		m_numOfParallelConnection = num;
		m_totalNumOfParallelConnections = totalNum;
		//System.out.println("Now: " + num + " " + totalNum );
	}*/
	
	
}

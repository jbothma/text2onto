package org.ontoware.text2onto.gui.jgraph.view;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public interface POMCell {
	public void setEvidence( boolean value );
}
package org.ontoware.text2onto.gui.jgraph.view;

import java.util.Map;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.GraphConstants;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMConceptualRelationInstanceEdge extends POMRelationEdge {
	public POMConceptualRelationInstanceEdge( Map attributes, DefaultGraphModel model, String label ) {
		super( attributes, model, label );
		// create edge attributes
		AttributeMap edgeAttrib = new AttributeMap();//model.createAttributes();
		attributes.put( this, edgeAttrib );
		// set arrow
		int arrow = GraphConstants.ARROW_DOUBLELINE;
		GraphConstants.setLineEnd( edgeAttrib , arrow );
		GraphConstants.setEndFill( edgeAttrib, true );
		
	} 

}

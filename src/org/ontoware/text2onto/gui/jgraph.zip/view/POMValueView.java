package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.util.StringTokenizer;

import org.jgraph.JGraph;
import org.jgraph.cellview.JGraphDiamondView;
import org.jgraph.cellview.JGraphEllipseView;
import org.jgraph.cellview.JGraphEllipseView.JGraphEllipseRenderer;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.GraphConstants;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMValueView extends MyJGraphDiamondView {
	public POMValueView( Object cell ) {
		super( cell );
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(300,300);
	}

	protected static POMValueRenderer renderer = new POMValueRenderer();

	public CellViewRenderer getRenderer()
	{
		return renderer;
	}

	public static class POMValueRenderer extends JGraphDiamondRenderer {

		public static String convertLabelToHtml( String label )
		{
			String output = "";

			if( label != null ) {
				StringTokenizer st = new StringTokenizer( label );
				while( st.hasMoreTokens() ) {
					String token = st.nextToken();
					output += token;
					if( st.hasMoreTokens() )
						output += "<br>";
				}
				output = "<html>" + output + "</html>";
			}
			return output;
		}

		public void paint( Graphics g )
		{
			Dimension d = getSize();
			setText( convertLabelToHtml( getText() ) );
			super.paint( g );
		}
		
		public Dimension getPreferredSize() {
			return new Dimension(300,300);
		}
	}
}
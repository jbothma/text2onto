package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import org.jgraph.JGraph;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;
import org.jgraph.graph.EdgeRenderer;
import org.jgraph.graph.PortRenderer;
import org.jgraph.graph.PortView;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationView.POMRelationRenderer;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMPortView extends PortView {
	public POMPortView( java.lang.Object cell ) {
		//super( cell, graph, mapper );
		super(cell);
	}

	protected static POMPortRenderer renderer = new POMPortRenderer();

	public CellViewRenderer getRenderer()
	{
		return renderer;
	}

	public static class POMPortRenderer extends PortRenderer {
		public POMPortRenderer() {
			super();
			//setForeground( Color.BLUE );
			//System.out.println( "new PR" );
			//setp
		}

		public void paint( Graphics g )
		{
			//g.setColor(graph.getBackground());
			//g.setXORMode(graph.getBackground());
			//if (preview) {
//				Dimension d = getSize();
//				g.setColor(Color.red);
//				g.drawRect(1, 1, d.width - 3, d.height - 3);
//				g.drawRect(2, 2, d.width - 5, d.height - 5);
			//}
			/* if( !preview ) System.out.println( "paint" );*/
		}
	}
}
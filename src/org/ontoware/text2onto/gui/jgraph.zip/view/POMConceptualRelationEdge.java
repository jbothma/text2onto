package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.geom.Point2D;
import java.util.Map;

import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.Edge;
import org.jgraph.graph.EdgeView;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.PortView;
import org.jgraph.util.JGraphUtilities;

public class POMConceptualRelationEdge extends POMRelationEdge {

	public POMConceptualRelationEdge( Map attributes, DefaultGraphModel model,
			String label ) {
		super( attributes, model, label );
		
		// set arrow
		int arrow = GraphConstants.ARROW_SIMPLE;
		GraphConstants.setLineEnd( m_edgeAttrib, arrow );
		GraphConstants.setEndFill( m_edgeAttrib, true );
				
	}
}
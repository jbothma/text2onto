package org.ontoware.text2onto.gui.jgraph.view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.util.StringTokenizer;

import org.jgraph.JGraph;
import org.jgraph.cellview.JGraphDiamondView;
import org.jgraph.cellview.JGraphEllipseView;
import org.jgraph.cellview.JGraphEllipseView.JGraphEllipseRenderer;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewRenderer;


/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMInstanceView extends JGraphEllipseView {

	public POMInstanceView( Object cell ) {
		// super( cell, model, cm );
		super(cell);
	}

	protected static POMConceptRenderer renderer = new POMConceptRenderer();
	// protected static JGraphDiamondRenderer rendere = new JGraphDiamondRenderer();
	
	public CellViewRenderer getRenderer(){
		return renderer;
	}

	public static class POMConceptRenderer extends JGraphEllipseRenderer {// JGraphDiamondRenderer {
	
		public static String convertLabelToHtml( String label ){
			/*
			String output = "";
			if( label != null )
			{
				StringTokenizer st = new StringTokenizer( label );
				while( st.hasMoreTokens() ) {
					String token = st.nextToken();
					output += token;
					if( st.hasMoreTokens() )
						output += "<br>";
				}
				output = "<html>" + output + "</html>";
			}
			return output;
			*/
			
			return "<html>"+ label +"</html>";
		}

		public void paint( Graphics g )
		{
			Dimension d = getSize();
			setText( convertLabelToHtml( getText() ) );
			super.paint( g );
		}
	}
}

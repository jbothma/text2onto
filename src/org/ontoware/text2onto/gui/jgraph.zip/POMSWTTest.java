package org.ontoware.text2onto.gui.jgraph;

import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.undo.UndoableEdit;

import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.*;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationEdge;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMFactory;
import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMRelation;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMSWTTest {

	private static Combo m_relationSelector;
	
	private static HashMap m_relationLabelsToRelations;
	
	private static POMGraph m_graph;

	private Text m_thresholdField;

	public static void main( String[] args )
	{
		POM pom = null;
		try {
			pom = POMFactory.newPOM( args[0] );	
		} 
		catch( Exception e ){
			e.printStackTrace();
			return;
		}
		POMSWTTest test = new POMSWTTest( pom );
	}
	
	public POMSWTTest( POM pom )
	{
		final Display display = new Display();
		final Shell shell = new Shell( display );
		shell.setText( "SWT-Swing-JGraph Example" );

		Listener exitListener = new Listener() {
			public void handleEvent( Event e )
			{
				MessageBox dialog = new MessageBox( shell, SWT.OK | SWT.CANCEL | SWT.ICON_QUESTION );
				dialog.setText( "Question" );
				dialog.setMessage( "Exit?" );
				if( e.type == SWT.Close ){
					e.doit = false;
				}
				if( dialog.open() != SWT.OK ){
					return;
				}
				shell.dispose();
			}
		};

		// shell.addListener( SWT.Close, exitListener );

		Menu mb = new Menu( shell, SWT.BAR );
		MenuItem fileItem = new MenuItem( mb, SWT.CASCADE );
		fileItem.setText( "&File" );
		Menu fileMenu = new Menu( shell, SWT.DROP_DOWN );
		fileItem.setMenu( fileMenu );
		MenuItem exitItem = new MenuItem( fileMenu, SWT.PUSH );
		exitItem.setText( "&Exit\tCtrl+X" );
		exitItem.setAccelerator( SWT.CONTROL + 'X' );
		exitItem.addListener( SWT.Selection, exitListener );

		shell.setMenuBar( mb );

		//----------------------------------------------------

		Composite tools = new Composite( shell, SWT.NONE );

		Label relationLabel = new Label( tools, SWT.NONE );
		relationLabel.setText( "Conceptual Relation:" );
		m_relationSelector = new Combo( tools, SWT.DROP_DOWN );
		
		Label thresholdLabel = new Label( tools, SWT.NONE );
		thresholdLabel.setText( "Probability Threshold:" );
		m_thresholdField = new Text( tools, SWT.BORDER );
		m_thresholdField.setText( "0.0" );
		Button apply = new Button( tools, SWT.NONE );
		apply.setText( "Apply Threshold" );
		//Button undo = new Button( tools, SWT.NONE );
		//undo.setText( "Undo" );

		
		Label separator2 = new Label( shell, SWT.SEPARATOR | SWT.HORIZONTAL );

		Composite graphComp = new Composite( shell, SWT.EMBEDDED );

		Label separator3 = new Label( shell, SWT.SEPARATOR | SWT.HORIZONTAL );

		m_relationSelector.addSelectionListener( new SelectionAdapter() {
			public void widgetSelected( SelectionEvent e )
			{
				Combo src = (Combo)e.getSource();
				// System.out.println( "Selection:" + src.getText() );
				applyConceptualRelationSelection( src.getText() );
			}
		} );
		
		apply.addSelectionListener( new SelectionAdapter() {
			public void widgetSelected( SelectionEvent e ) {
				System.out.println( "Applying new threshold..." );
				double threshold = Double.parseDouble( m_thresholdField.getText() );
				applyThreshold( threshold );
			}			
		});
		
		/*undo.addSelectionListener( new SelectionAdapter() {
			public void widgetSelected( SelectionEvent e ) {
				System.out.println( "Undo last change..." );
//				if( m_graph.m_undoManager.canUndo() ) {
//					//UndoableEdit edit = m_graph.m_undoManager.
//					m_graph.m_undoManager.undo();
//				
//				}
				
				m_graph.undoChange();
			}			
		});*/
		
		java.awt.Frame graphFrame = SWT_AWT.new_Frame( graphComp );

		//-----------------------------------------------------

		GridLayout layout = new GridLayout();
		layout.numColumns = 1;
		//layout.marginWidth = layout.marginHeight = 0;
		//layout.horizontalSpacing = layout.verticalSpacing = 1;
		shell.setLayout( layout );

		GridData data;
		data = new GridData( GridData.FILL_HORIZONTAL );
		separator2.setLayoutData( data );

		data = new GridData( GridData.FILL_BOTH );
		graphComp.setLayoutData( data );

		data = new GridData( GridData.FILL_HORIZONTAL );
		tools.setLayoutData( data );

		data = new GridData( GridData.FILL_HORIZONTAL );
		separator3.setLayoutData( data );

		RowLayout selectorLayout = new RowLayout();
		selectorLayout.spacing = 20;
		tools.setLayout( selectorLayout );
 
		m_relationLabelsToRelations = new HashMap();
		try {
			m_graph = POMGraph.createGraphfromPOM( pom );
			
			graphFrame.add( new JScrollPane( m_graph ) );
			
			//for(int i=1;i<30;i++)
			System.out.println("Entering layout...");
			
			
			System.out.println("Layout done");
			
			//now fill the relation selector
			m_relationSelector.add( "none" );
			m_relationSelector.add( "all" );
			ArrayList tempList = m_graph.getConceptualRelationEdges();
			for( int i = 0; i < tempList.size(); i++ ) 
			{
				POMObject relation = m_graph.getObjectForCell( (POMConceptualRelationEdge)tempList.get( i ) );
				m_relationSelector.add( relation.getLabel() );
				m_relationLabelsToRelations.put( relation.getLabel(), relation );
			}
			m_relationSelector.select(0);
			
			applyConceptualRelationSelection( "none" );
			//m_graph.m_undoManager.discardAllEdits();
			
		} 
		catch( Exception e ) {
			System.out.println( "GT: " + e );
			e.printStackTrace();
		}
		//----------------------------------------------------------------------

		shell.open();
		while( !shell.isDisposed() ) {
			if( !display.readAndDispatch() ){
				display.sleep();
			}
		}
		display.dispose();

	}
	
	private static void applyConceptualRelationSelection( String relationLabel ) {
		if( relationLabel.equals( "none" ) ){
			m_graph.setConceptualRelationsVisibility( false );
		}
		else if( relationLabel.equals( "all" ) ){
			m_graph.setConceptualRelationsVisibility( true );
		}
		else {
			m_graph.showConceptualRelations( new String[]{relationLabel}, true );
		}
	}
	private static void applyThreshold( double value ) {
		m_graph.setObjectThreshold( value );			
	}
}
package org.ontoware.text2onto.gui.jgraph;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import org.jgraph.JGraph;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphModel;
import org.ontoware.text2onto.gui.jgraph.view.POMCell;
import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMRelation;

/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 */
public class POMGraphPopupMenu implements ActionListener {
	private POMGraph m_graph;

	private JPopupMenu popup;

	private PopupListener popupListener;

	public POMGraphPopupMenu( POMGraph graph ) {
		m_graph = graph;
		popupListener = new PopupListener( this );
	}

	public MouseListener getPopupListener()
	{
		return popupListener;
	}

	public void actionPerformed( ActionEvent e )
	{
		//System.out.println( "Menu item hit. Selected: " + e.getActionCommand() );

		if( e.getActionCommand().equals( "confirm cell" ) ) {
			POMCell o = popupListener.getSelectedCell();
			m_graph.setCellConfirmation( o, true );
			
		} else if( e.getActionCommand().equals( "deny cell" ) ) {			
			POMCell o = popupListener.getSelectedCell();
			m_graph.setCellConfirmation( o, false );
			
		} else if( e.getActionCommand().equals( "remove this cell" ) ) {
			POMCell o = popupListener.getSelectedCell();
			m_graph.removeCell( o );					
		}

	}

	/**
	 * This class provides different popup menus according to the context
	 * 
	 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
	 */
	class PopupListener extends MouseAdapter {
		POMGraphPopupMenu m_menu;

		public POMCell m_selectedCell = null;

		public PopupListener( POMGraphPopupMenu menu ) {
			m_menu = menu;
		}

		public void mousePressed( MouseEvent e )
		{
			//System.out.println("mouse event");
			maybeShowPopup( e );
		}

		public void mouseReleased( MouseEvent e )
		{
			maybeShowPopup( e );
		}

		private void maybeShowPopup( MouseEvent e )
		{
			if( e.isPopupTrigger() ) {
				//get component below pointer, then create and show menu
				int x = e.getX(), y = e.getY();
				POMCell cell = (POMCell)m_graph.getFirstCellForLocation( x, y );

				//print cell Label
				if( cell != null ) {
					m_selectedCell = cell;
					String lab = m_graph.convertValueToString( cell );
					System.out.println( lab );
				}

				//create menu
				JMenuItem menuItem;

				popup = new JPopupMenu();

				if( cell instanceof POMCell ) {
					menuItem = new JMenuItem( "confirm cell" );
					menuItem.addActionListener( m_menu );
					popup.add( menuItem );
					menuItem = new JMenuItem( "deny cell" );
					menuItem.addActionListener( m_menu );
					popup.add( menuItem );
					menuItem = new JMenuItem( "remove this cell" );
					menuItem.addActionListener( m_menu );
					popup.add( menuItem );
				}

				/*if( cell instanceof DefaultEdge ) {
					
				}*/

				//show menu
				popup.show( e.getComponent(), e.getX(), e.getY() );
			}
		}

		public POMCell getSelectedCell()
		{
			return m_selectedCell;
		}
	}

}
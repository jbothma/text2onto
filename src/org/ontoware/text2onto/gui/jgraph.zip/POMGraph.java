package org.ontoware.text2onto.gui.jgraph;

import java.util.*;

import java.awt.Canvas;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.ToolTipManager;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.undo.UndoManager;

import org.jgraph.graph.AttributeMap;
import org.jgraph.JGraph;
import org.jgraph.graph.CellMapper;
import org.jgraph.graph.CellViewFactory;
import org.jgraph.graph.ConnectionSet;
import org.jgraph.graph.DefaultCellViewFactory;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.DefaultPort;
import org.jgraph.graph.EdgeView;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphLayoutCache;
import org.jgraph.graph.GraphUndoManager;
import org.jgraph.graph.ParentMap;
import org.jgraph.graph.PortView;
import org.jgraph.graph.VertexView;
import org.jgraph.layout.AnnealingLayoutAlgorithm;
import org.jgraph.layout.CircleGraphLayout;
import org.jgraph.layout.JGraphLayoutAlgorithm;
import org.jgraph.layout.SpringEmbeddedLayoutAlgorithm;
import org.jgraph.util.JGraphUtilities;
import org.ontoware.text2onto.change.Add;
import org.ontoware.text2onto.change.Change;
import org.ontoware.text2onto.change.ChangeObserver;
import org.ontoware.text2onto.change.Changeable;
import org.ontoware.text2onto.change.Modify;
import org.ontoware.text2onto.change.Remove;
import org.ontoware.text2onto.gui.jgraph.view.POMCell;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptCell;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptView;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationEdge;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationInstanceEdge;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationInstanceView;
import org.ontoware.text2onto.gui.jgraph.view.POMConceptualRelationView;
import org.ontoware.text2onto.gui.jgraph.view.POMEntityCell;
import org.ontoware.text2onto.gui.jgraph.view.POMInstanceCell;
import org.ontoware.text2onto.gui.jgraph.view.POMInstanceOfRelationEdge;
import org.ontoware.text2onto.gui.jgraph.view.POMInstanceOfRelationView;
import org.ontoware.text2onto.gui.jgraph.view.POMInstanceView;
import org.ontoware.text2onto.gui.jgraph.view.POMPortView;
import org.ontoware.text2onto.gui.jgraph.view.POMRelationEdge;
import org.ontoware.text2onto.gui.jgraph.view.POMSubclassOfRelationEdge;
import org.ontoware.text2onto.gui.jgraph.view.POMSubclassOfRelationView;
import org.ontoware.text2onto.gui.jgraph.view.POMValueCell;
import org.ontoware.text2onto.gui.jgraph.view.POMValueView;
import org.ontoware.text2onto.gui.jgraph.view.TestSpringEmbeddedLayoutAlgorithm;
import org.ontoware.text2onto.pom.POM;
import org.ontoware.text2onto.pom.POMConcept;
import org.ontoware.text2onto.pom.POMConceptualRelation;
import org.ontoware.text2onto.pom.POMConceptualRelationInstance;
import org.ontoware.text2onto.pom.POMEntity;
import org.ontoware.text2onto.pom.POMInstance;
import org.ontoware.text2onto.pom.POMInstanceOfRelation;
import org.ontoware.text2onto.pom.POMObject;
import org.ontoware.text2onto.pom.POMRelation;
import org.ontoware.text2onto.pom.POMSubclassOfRelation;
import org.ontoware.text2onto.pom.POMValue;


/**
 * @author Stephan Oehlert (stephan.oehlert@gmx.net)
 * 
 */
public class POMGraph extends JGraph implements ChangeObserver{

	private Canvas m_canvas;

	private JFrame m_frame;

	// private JGraph m_graph;

	private DefaultGraphModel m_model;

	private ArrayList m_relations;

	private ArrayList m_conceptualRelations; // for selection speedup

	private ArrayList m_cells;

	private ArrayList m_edges;

	private ArrayList m_visibleCells;

	private ArrayList m_visibleRelations;

	private POM m_pom;

	private JGraphLayoutAlgorithm m_layout;

	private HashMap m_CellToObjectMap;

	private HashMap m_ObjectToCellMap;

	private double m_threshold;
	
	private ParentMap pm;

	// undo:
	protected UndoManager m_undoManager;

	/*
	 * public void doLayout() { // layout.run( graph, cells.toArray() );
	 * JGraphUtilities.applyLayout( this, m_layout ); }
	 */

	public void updateLayout()
	{
		JGraphUtilities.applyLayout( this, m_layout );
	}

	/**
	 * This method creates a new POMGraph and loads the given POM
	 * 
	 * @param pom
	 *           the POM to load
	 * @return the new POMGraph
	 */
	public static POMGraph createGraphfromPOM( POM pom )
	{
		POMGraph pomgraph = new POMGraph( pom );
		return pomgraph;
	}

	class CellViewFactory extends DefaultCellViewFactory {
		protected EdgeView createEdgeView( Object cell )
		{
			if( cell instanceof POMConceptualRelationEdge ) {
				return new POMConceptualRelationView( cell );
			} else if( cell instanceof POMInstanceOfRelationEdge ) {
				return new POMInstanceOfRelationView( cell );
			} else if( cell instanceof POMSubclassOfRelationEdge ) {
				return new POMSubclassOfRelationView( cell );
			} else if( cell instanceof POMConceptualRelationInstanceEdge ) {
				return new POMConceptualRelationInstanceView( cell );
			} else {
				return null;
			}
		}

		protected PortView createPortView( Object cell )
		{
			return new POMPortView( cell );
		}

		protected VertexView createVertexView( Object o )
		{
			if( o instanceof POMConceptCell ) {
				return new POMConceptView( o );
			} else if( o instanceof POMInstanceCell ) {
				return new POMInstanceView( o );
			} else if( o instanceof POMValueCell ) {
				return new POMValueView( o );
			} else {
				return null;
			}
			// return super.createVertexView( arg0 );
		}
	}

	private POMGraph( POM pom ) {
		super( new DefaultGraphModel() );

		m_canvas = null;
		m_visibleRelations = new ArrayList();

		// now load the POM and point the JGraph at it
		m_model = new DefaultGraphModel();
		setModel( m_model );

		CellViewFactory viewFactory = new CellViewFactory();

		getGraphLayoutCache().setFactory( viewFactory );
		setGraphLayoutCache( new GraphLayoutCache( getModel(), viewFactory, true ) );
		
		getGraphLayoutCache().setSelectsAllInsertedCells( false );

		//loadPOM( pom );
		initPOMAttributes( pom );
		
		// add popup menu to pom graph
		POMGraphPopupMenu popupMenu = new POMGraphPopupMenu( this );
		addMouseListener( popupMenu.getPopupListener() );

		setPortsVisible( true );

		setBounds( new Rectangle( 0, 0, 1024, 722 ) );
		
		setConnectable( false );
		setDisconnectable( false );

		m_threshold = 1.0;

		ToolTipManager.sharedInstance().registerComponent( this );

		System.out.println( "number of root objects: "
				+ DefaultGraphModel.getRoots( m_model ).length );

		//m_undoManager = new GraphUndoManager();
		//m_model.addUndoableEditListener( new POMGraphUndoableEditListener() );
		//m_undoManager.discardAllEdits();
		loadPOM( m_pom );
		m_pom.addChangeObserver( this );
		m_pom.resetChangesFor( this );
		applyPOMChanges();
		
		// m_layout = new CircleGraphLayout();
		m_layout = new AnnealingLayoutAlgorithm();
		//m_layout = new SpringEmbeddedLayoutAlgorithm();

		updateLayout();
		
		//m_layout = null;
	}

	private void initPOMAttributes( POM pom ) {
		m_pom = pom;
		m_CellToObjectMap = new HashMap();
		m_ObjectToCellMap = new HashMap();

		m_relations = new ArrayList();
		m_conceptualRelations = new ArrayList();
		m_cells = new ArrayList();
		m_edges = new ArrayList();

		m_visibleCells = new ArrayList();
				
		pm = new ParentMap();
	}
	
	private void loadPOM( POM pom )
	{
		List entities = pom.getEntities( 0.0 );
		List relations = pom.getRelations( 0.0 );
		
		/*
		 * create cells for entities
		 */
		Iterator iter = entities.iterator();
		while( iter.hasNext() ) {
			POMObject object = (POMEntity)iter.next();

			insertCellForObject( (POMEntity)object );			
		}

		//ArrayList portList = new ArrayList();

		/*
		 * create edges for relations
		 */
		iter = relations.iterator();
		while( iter.hasNext() ) {
			POMRelation relation = (POMRelation)iter.next();

			insertEdgeForObject( relation );
		}
	}
	
	private POMEntityCell insertCellForObject( POMEntity object ) {
		POMEntityCell cell = null;
		
		Map attributes = new Hashtable();
		
		if( object instanceof POMConcept ) {
			System.out.println( "Creating cell for concept "
					+ object.getLabel() );
			cell = new POMConceptCell( attributes, m_model, object.getLabel(),
					object.getProbability() );
		} else if( object instanceof POMInstance ) {
			System.out.println( "Creating cell for instance "
					+ object.getLabel() );
			cell = new POMInstanceCell( attributes, m_model, object.getLabel(),
					object.getProbability() );
		} else if( object instanceof POMValue ) {
			System.out.println( "Creating cell for value " + object.getLabel() );
			cell = new POMValueCell( attributes, m_model, object.getLabel(),
					object.getProbability() );
		} else {
			System.out.println( "Unknown cell: " + object.toString() + "!!");
			return null;
		}
		
		assert cell != null;
		
		DefaultPort port = new DefaultPort( cell + "Port" );
		cell.add( port );
		
		System.out.println("port: " + port);
		
		ParentMap pm = new ParentMap();
		pm.addEntry( port, cell );

		m_cells.add( cell );

		m_CellToObjectMap.put( cell, object );
		m_ObjectToCellMap.put( object, cell );
		
		Object[] insert = new Object[] { cell }; 
			//m_cells.toArray();

		m_model.insert( insert, attributes, null, pm, null );
		
		return cell;
	}
	
	private void insertEdgeForObject( POMRelation relation ) {		
		Map attributes = new Hashtable();
		System.out.println( "adding relation: " + relation.getLabel() );

		POMEntity domain = relation.getDomain();
		System.out.print( "domain: " + domain + " " );
		POMEntity range = relation.getRange();
		System.out.println( "range:" + range );

		POMEntityCell domainCell = (POMEntityCell)m_ObjectToCellMap
				.get( domain );
		POMEntityCell rangeCell = (POMEntityCell)m_ObjectToCellMap.get( range );

		if( rangeCell != null && domainCell != null ) {
			DefaultPort domainPort = (DefaultPort)domainCell.getFirstChild();
			DefaultPort rangePort = (DefaultPort)rangeCell.getFirstChild();

			boolean connectionExists = false;
			POMRelationEdge existingEdge = null;
			if( domainPort.getEdges().size() > 0 ) {
				// now check whether an edge at this connection already exists
				Iterator edgeIter = domainPort.getEdges().iterator();
				while( edgeIter.hasNext() ) {
					POMRelationEdge edge = (POMRelationEdge)edgeIter.next();
					if( edge.getSource().equals( domainPort )
							&& edge.getTarget().equals( rangePort )
							|| edge.getSource().equals( rangePort )
							&& edge.getTarget().equals( domainPort ) ) {
						connectionExists = true;
						existingEdge = edge;
						break;
					}
				}
			}

			// create edge
			String sProb = Double.toString( relation.getProbability() );
			String label = sProb.substring( 0, Math.min(
					sProb.indexOf( "." ) + 3, sProb.length() ) );
			POMRelationEdge edge = null;
			if( relation instanceof POMConceptualRelation ) {
				edge = new POMConceptualRelationEdge( attributes, m_model,
						relation.getLabel() + " | " + label );
				m_conceptualRelations.add( relation );
			} else if( relation instanceof POMInstanceOfRelation ) {
				edge = new POMInstanceOfRelationEdge( attributes, m_model,
						relation.getLabel() + " | " + label );
				//edge = new POMInstanceOfRelationEdge( attributes, m_model, label );
			} else if( relation instanceof POMSubclassOfRelation ) {
				edge = new POMSubclassOfRelationEdge( attributes, m_model,
						relation.getLabel() + " | " + label );
				//edge = new POMSubclassOfRelationEdge( attributes, m_model, label );
			} else if( relation instanceof POMConceptualRelationInstance ) {
				edge = new POMConceptualRelationInstanceEdge( attributes, m_model,
						relation.getLabel() + " | " + label );
				//edge = new POMConceptualRelationInstanceEdge( attributes,
					//	m_model, label );
			} 
			
			assert edge != null;
			
			// connect edge to ports
			ConnectionSet cs = new ConnectionSet( edge, domainPort, rangePort );

			m_relations.add( relation );
			m_edges.add( edge );

			m_CellToObjectMap.put( edge, relation );
			m_ObjectToCellMap.put( relation, edge );
			
			Object[] insert = new Object[] { edge };

			// insert into model
			m_model.insert( insert, attributes, cs, null, null );
		}

	}
	
	
	
	/**
	 * returns the type of the cell under the mouse pointer
	 */
	public String getToolTipText( MouseEvent e )
	{
		if( e != null ) {
			// Fetch Cell under Mousepointer
			Object c = getFirstCellForLocation( e.getX(), e.getY() );
			if( c != null )
				// Convert Cell to String and Return
				// return convertValueToString( c );
				return c.getClass().getName();
		}
		return null;
	}

	public void setCanvas( Canvas canvas )
	{
		this.m_canvas = canvas;
	}

	public void setFrame( JFrame frame )
	{
		this.m_frame = frame;
		frame.getContentPane().add( new JScrollPane( this ) );
	}

	public POMCell getCellForObject( POMObject o )
	{
		return (POMCell)m_ObjectToCellMap.get( o );
	}

	public POMObject getObjectForCell( POMCell c )
	{
		return (POMObject)m_CellToObjectMap.get( c );
	}

	/*
	 * public void setCellVisibility( POMCell[] cells ) {
	 * getGraphLayoutCache().setVisible(
	 * m_CellToObjectMap.keySet().iterator().next(), false ); }
	 */

	public ArrayList getConceptualRelationEdges()
	{
		ArrayList tempList = new ArrayList();
		for( int i = 0; i < m_edges.size(); i++ ) {
			if( m_edges.get( i ) instanceof POMConceptualRelationEdge ) {
				tempList.add( m_edges.get( i ) );
			}
		}
		return tempList;
	}

	/**
	 * show conceptual relations in the graph
	 * 
	 * @param name
	 *           the label of the relation
	 * @param value
	 *           visibility flag
	 */
	public void showConceptualRelations( String[] name, boolean visible )
	{
		m_visibleRelations = new ArrayList();
		for( int i = 0; i < m_conceptualRelations.size(); i++ ) {
			POMConceptualRelation relation = (POMConceptualRelation)m_conceptualRelations
					.get( i );
			boolean showRelation = false;
			for( int k = 0; k < name.length; k++ ) {
				if( relation.getLabel().equals( name[k] ) ) {
					m_visibleRelations.add( relation );
					if( relation.getProbability() >= m_threshold ) {
						showRelation = true;
						break;
					}
				}
			}
			setCellVisibility( relation, showRelation );
		}
	}

	/**
	 * show conceptual relations in the graph
	 * 
	 * @param name
	 *           the label of the relation
	 * @param value
	 *           visibility flag
	 */
	public void updateConceptualRelationsVisibility()
	{
		for( int i = 0; i < m_conceptualRelations.size(); i++ ) {
			POMConceptualRelation relation = (POMConceptualRelation)m_conceptualRelations
					.get( i );
			if( m_visibleRelations.contains( relation ) ) {
				setCellVisibility( relation,
						relation.getProbability() >= m_threshold );
			} else
				setCellVisibility( relation, false );
		}
	}

	/**
	 * shows/hides all conceptual relations in the graph
	 */
	public void setConceptualRelationsVisibility( boolean visible )
	{
		for( int i = 0; i < m_conceptualRelations.size(); i++ ) {
			POMConceptualRelation relation = (POMConceptualRelation)m_conceptualRelations
					.get( i );
			if( relation.getProbability() >= m_threshold )
				setCellVisibility( relation, visible );
			else
				setCellVisibility( relation, false );
		}
	}

	/**
	 * set the threshold, above which the cells should be shown
	 * 
	 * @param dProb
	 */
	public void setObjectThreshold( double dProb )
	{
		System.out.println( "POMG: setting new threshold to " + dProb );
		m_threshold = dProb;

		Iterator iter = m_pom.getObjects().iterator();
		while( iter.hasNext() ) {
			POMObject o = (POMObject)iter.next();

			if( o.getProbability() >= dProb ) {
				if( o instanceof POMConceptualRelation
						&& !m_visibleRelations.contains( o ) )
					setCellVisibility( o, false );
				else
					setCellVisibility( o, true );
			} else {
				setCellVisibility( o, false );
			}
		}
	}

	/**
	 * updates visible flag for one cell; checks whether flag is already set in
	 * order to avoid flicker
	 * 
	 * @param o
	 * @param visible
	 */
	private void setCellVisibility( POMObject o, boolean visible )
	{
		DefaultGraphCell cell = (DefaultGraphCell)m_ObjectToCellMap.get( o );
		if( getGraphLayoutCache().isVisible( cell ) != visible )
			getGraphLayoutCache().setVisible( cell, visible );
	}
	
	
	
	void setCellConfirmation( POMCell cell, boolean value ) {
		POMObject o = getObjectForCell( cell );
		/*System.out.println( "setting cell status to :" + value + " " 
				+ cell + ", object: " + o );*/
		
		//cell.setEvidence( value );
		
		Change modifyRequest = new Modify( cell, o, new Boolean(value) );
		
		applyChange( modifyRequest );		
	}
	
	void removeCell( POMCell cell ) {
		POMObject o = getObjectForCell( cell );
		
		if( cell instanceof POMEntityCell ) {
			POMEntityCell entity = (POMEntityCell)cell;
			DefaultPort port = (DefaultPort)entity.getFirstChild();
			
			Set children = new HashSet();
			children = port.getEdges();
			
			Iterator iter = children.iterator();
			while( iter.hasNext() ) {
				POMRelationEdge e = (POMRelationEdge)iter.next();
				POMObject eo = getObjectForCell( e );
				Change removeRequest = new Remove( e, eo );
				applyChange( removeRequest );
			}
		}
		
		/*System.out.println( "removing cell: " + cell
				+ ", object: " + o );*/
		
		Change removeRequest = new Remove( cell, o );
		applyChange( removeRequest );
	}
	
	public void undoChange() {
		/*Change undoneChange = m_pom.undo();
		
		if( undoneChange != null ) {
			
			if( undoneChange instanceof Remove ){
				
				if( undoneChange.getObject() instanceof POMEntity )
					insertCellForObject( (POMEntity)undoneChange.getObject() );
				if( undoneChange.getObject() instanceof POMRelation )
					insertEdgeForObject( (POMRelation)undoneChange.getObject() );
				
				
			}
			if( undoneChange instanceof Modify ){
				if( undoneChange.getObject() instanceof Boolean )
			}			
		}*/
	}
	
	private void applyChange( Change c ) {
		m_pom.apply( c );
		applyPOMChange( c );
	}
	
	private void applyPOMChange( Change change ) {
		if( change instanceof Add ){
			if( change.getObject() instanceof POMEntity )
				insertCellForObject( (POMEntity)change.getObject() );
			if( change.getObject() instanceof POMRelation )
				insertEdgeForObject( (POMRelation)change.getObject() );
		} 
		else if( change instanceof Remove ){
			POMCell cell = getCellForObject( (POMObject)change.getObject() ); 
			getModel().remove( new Object[]{cell});
			
			m_cells.remove( cell );

			m_CellToObjectMap.remove( cell );
			m_ObjectToCellMap.remove( change.getObject() );
		}
		else if( change instanceof Modify ){
			POMCell cell = getCellForObject( (POMObject)change.getObject() );
			if( change.getValue() instanceof Boolean )
				cell.setEvidence( ((Boolean)change.getValue()).booleanValue() );				
		}
	}
	
	void applyPOMChanges() {
		List changes = m_pom.getChangesFor( this );
		System.out.println("Applying Changes: " + changes );
		
		Iterator iter = changes.iterator();
		
		while( iter.hasNext() ) {
			Change change = (Change) iter.next();
			
			System.out.println( change.toString() );
			
			if( change instanceof Add ){
				if( change.getObject() instanceof POMEntity )
					insertCellForObject( (POMEntity)change.getObject() );
				if( change.getObject() instanceof POMRelation )
					insertEdgeForObject( (POMRelation)change.getObject() );
			} 
			else if( change instanceof Remove ){
				POMCell cell = getCellForObject( (POMObject)change.getObject() ); 
				getModel().remove( new Object[]{cell});				
			}
			else if( change instanceof Modify ){
				POMCell cell = getCellForObject( (POMObject)change.getObject() );
				if( change.getValue() instanceof Boolean )
					cell.setEvidence( ((Boolean)change.getValue()).booleanValue() );				
			}
			 
		}
		
		m_pom.resetChangesFor( this );		
	}
	
//	protected class newCacheListener implements GraphLayoutCacheListener {
//		
//			public void graphLayoutCacheChanged( GraphLayoutCacheEvent arg0 )
//		{
//			// TODO Auto-generated method stub
//				System.out.println("new event caught..");
//		}
//}

	protected class POMGraphUndoableEditListener implements UndoableEditListener {

		public POMGraphUndoableEditListener() {
		}

		public void undoableEditHappened( UndoableEditEvent e )
		{
			//System.out.println( e.getEdit().getClass() );

			if( e.getEdit() instanceof DefaultGraphModel.GraphModelEdit ) {
				DefaultGraphModel.GraphModelEdit o = (DefaultGraphModel.GraphModelEdit)e
						.getEdit();
				
				Object[] c = o.getChanged();
				if( c != null ) {
					for(int i=0; i<c.length;i++) {
						System.out.println( "got: " +	c[i]);
						if(c[i] instanceof POMEntityCell ) {
							Object[] removed = o.getRemoved();
							Object[] inserted = o.getInserted();
							
							int k;
							if( removed != null )
								for( k=0; k<removed.length; k++ ) {
									if( removed[k] == c[i] )
										System.out.println("object removed");
								}
							if( inserted != null )
								for( k=0; k<inserted.length; k++ ) {
									if( removed[k] == c[i] )
										System.out.println("object inserted");
								}
							
							Map gAttrB = o.getPreviousAttributes();
							System.out.println("previous attributes: " + gAttrB);
							gAttrB = o.getAttributes();
							System.out.println("attributes: " + gAttrB);
							
							//Map attB = (Map)gAttrB.get(c[i]);
							
//							Map gAtt = o.getAttributes();
//							System.out.println("attributes: " + gAttrB);
//							Map att = (Map)gAtt.get(c[i]);
							
							POMObject p = getObjectForCell( (POMCell)c[i] );
							//Boolean evidenceBefore = (Boolean)attB.get("evidence");
							Boolean evidenceBefore = p.getEvidence();
							
							System.out.println( "evidence: " + evidenceBefore );
														
						}
						
					}
				}
				//System.out.println( c[0].getClass() + " l: " + c.length );
				/*
				 * for(int i=0; i <c.length;i++) { System.out.println( "got: " +
				 * c[i]); }
				 */

			}
			// System.out.println("Event happened: " + e.getSource());
			m_undoManager.addEdit( e.getEdit() );

		}
		
		
	}
}